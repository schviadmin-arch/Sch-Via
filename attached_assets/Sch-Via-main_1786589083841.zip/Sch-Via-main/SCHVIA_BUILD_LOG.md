# SchVIA build log and decision record

This file records verified progress and durable decisions so another engineer can continue without relying on conversation history.

## 2026-08-09 — post-audit planning baseline

### Evidence reviewed

- `attached_assets/Pasted-SCHVIA-CURRENT-BUILD-AUDIT-Do-NOT-modify-rebuild-refact_1786247185137.txt`
- `SCHVIA_CURRENT_BUILD_AUDIT.md`
- `replit.md`
- `index.html`
- `app.js`
- `serve.mjs`
- `data/schvia.json`
- `.replit`

### Verified current state

- The app runs with `node serve.mjs`.
- The current workflow is `Start application`.
- The application is dependency-free and uses a native Node HTTP server.
- The current school workspace is a narrow demo/pilot slice backed by local JSON.
- Principal/Teacher authorization boundaries are present for the current routes.
- The Founder dashboard is static and publicly reachable through the frontend hash route.
- There is no database, real identity system, tenant-aware schema, or automated test suite.
- Attendance has an online save path and a limited localStorage retry queue, but not a complete offline-first application.

### Decision recorded

The post-audit directive is being treated as the current build authority. The next engineering step is a dependency-aware implementation plan, not an unbounded rewrite and not cosmetic polishing of the prototype.

**Why:** The audit explicitly identifies authentication, persistence, tenant isolation, attendance synchronization, and Founder access as architectural prerequisites. Building screens before those foundations would create more prototype debt.

### No-code-change boundary

No application behavior was changed while recording this baseline. The plan and this log are documentation only.

### Next gate

Before database/auth implementation, select the infrastructure approach and attach any required services through the environment integration flow. Do not invent credentials or put secrets in repository files.

## 2026-08-09 — pilot safety hardening and school settings

### Implemented

- Added production startup protection when `SESSION_SECRET` is missing.
- Added request IDs and baseline security response headers.
- Added `/health` and `/ready` endpoints.
- Added strict JSON/content-type and request-size error handling.
- Added server validation for email, active teacher assignment, duplicate classes, duplicate student IDs, attendance dates, attendance class membership, supported statuses, and duplicate records in one batch.
- Changed browser attendance queuing so only offline/retryable transport/server failures enter the queue; authorization, validation, and conflict failures remain visible.
- Added a read-only `tests/smoke.mjs` process that verifies health, readiness, authentication, role filtering, authorization, and validation.
- Exposed the existing audited school settings API through a Principal-only workspace panel.
- Added explicit server-side session expiry, expired-session cleanup, and a bounded per-address sign-in throttle.

### Verification

- `node --check serve.mjs`
- `node --check app.js`
- `node tests/smoke.mjs`
- `git diff --check`
- Restarted `Start application`; workflow is running.
- Verified `/health` and `/ready` return HTTP 200 with security headers.
- Captured a fresh public-page preview with no browser console errors.
- Verified the production process refuses to start without `SESSION_SECRET`.
- Verified isolated real-user E2E: workspace creation, password sign-in, invitation acceptance, teacher scope, same-school class assignment, and second-school isolation.

### Boundary retained

The app now supports real local school accounts, invitation acceptance, and server-side multi-school isolation over JSON. It is still not production-ready: relational persistence, password recovery/email verification, and a separately authenticated Founder control plane remain outstanding. The seeded role selector is retained only as explicitly labeled demo compatibility access.
