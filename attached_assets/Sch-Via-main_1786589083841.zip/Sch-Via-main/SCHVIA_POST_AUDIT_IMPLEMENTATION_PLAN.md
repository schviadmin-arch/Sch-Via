# SchVIA post-audit implementation plan

**Document status:** Ready for implementation  
**Prepared from:** `attached_assets/Pasted-SCHVIA-CURRENT-BUILD-AUDIT-Do-NOT-modify-rebuild-refact_1786247185137.txt`, `SCHVIA_CURRENT_BUILD_AUDIT.md`, the current source tree, and the existing project handoff.  
**Scope:** Convert the current single-school prototype into a credible, portable MVP foundation without building unrelated future modules.  
**This document is not an implementation claim.** It records what should be built, why it is needed, what should be preserved, what must be replaced, and how each stage will be verified.

---

## 1. Current baseline

The current application is a dependency-free Node.js HTTP server with a plain HTML/CSS/browser-JavaScript frontend.

### Verified existing behavior

- `node serve.mjs` starts the application on the configured port.
- `/` serves a public SchVIA marketing page.
- `#dashboard` renders a Founder command-center concept using hardcoded sample data.
- `#pilot` opens a demo school workspace.
- Demo Principal and Teacher sign-in requests create signed, HTTP-only in-memory sessions.
- Principal state contains the seeded school, all seeded classes/students/users, and pilot audit records.
- Teacher state is filtered to assigned classes and students.
- Principal-only mutations reject a Teacher with HTTP `403`.
- Teacher attendance for an unassigned class is rejected with HTTP `403`.
- Principal can create students, classes, and invitation records.
- Principal or assigned Teacher can record four attendance states.
- Attendance is persisted to `data/schvia.json`.
- The browser has a localStorage attendance retry queue.
- The app has no database, no real identity system, no multi-tenant model, no automated test suite, and no secure Founder control plane.

### Current data boundary

The JSON file is a temporary prototype bridge. It must not be treated as a production persistence layer or as a multi-school data model.

### Current product boundary

The first MVP should focus on:

1. School/workspace creation and onboarding.
2. Real identity and invitations.
3. Tenant-safe staff, classes, students, and attendance.
4. Fast, reliable offline attendance.
5. Principal oversight generated from real data.
6. A separately authenticated Founder control plane.
7. Auditability, tests, observability, backup/recovery documentation, and deployment portability.

Payroll, transport, library, hostel, inventory, marketplace, full LMS, biometrics, complex AI, payments, and a full grading/report-card system are intentionally outside the first implementation slice.

---

## 2. Non-negotiable engineering rules

1. **Verify before claiming.** A rendered screen is not evidence that a workflow works.
2. **Server-side authorization is authoritative.** Frontend filtering is only presentation.
3. **Every school-owned record is tenant-scoped.** No global arrays or implicit school ownership in the new model.
4. **Real data only for operational metrics.** Seed/demo data must be explicitly isolated and labeled.
5. **Attendance must never silently lose or falsely mark data as synced.**
6. **Invitations must have a complete lifecycle** if they are exposed as a real feature.
7. **Founder access is separate from school access** and defaults to read-only oversight where possible.
8. **Archive instead of destructive deletion** for canonical school records unless deletion is explicitly required by a privacy policy.
9. **Prefer one simple deployable application** over premature microservices, queues, Redis, or Kubernetes.
10. **Keep the business logic portable.** Replit-specific configuration may live at the edge; domain logic must not depend on Replit.
11. **Document each decision and migration assumption** in the repository so another engineer can continue without oral context.
12. **Do not use a development fallback secret in production.**

---

## 3. Proposed target architecture

### 3.1 Application shape

Use a conventional, portable Node.js application with:

- A small HTTP API layer.
- A browser client that can remain framework-light if the interface stays maintainable, or a component-based frontend if the migration proves necessary for accessibility and state complexity.
- A domain/service layer for school operations and event creation.
- A PostgreSQL-compatible persistence layer behind a repository boundary.
- A migration runner and seed strategy.
- Browser offline storage using IndexedDB, with a service worker for the attendance shell and static assets.

The architecture should remain a modular monolith. There is no demonstrated requirement for separately deployed services.

### 3.2 Proposed bounded modules

These are logical modules, not separate services:

- `auth`: sign-up/sign-in, sessions, recovery, invitation acceptance.
- `founder`: internal platform control-plane access and oversight.
- `schools`: workspace creation, configuration, lifecycle.
- `memberships`: users, roles, capabilities, school membership.
- `academics`: academic years/terms, classes, subjects, assignments.
- `students`: canonical student records and enrollment lifecycle.
- `attendance`: attendance entry, history, summaries, sync/conflict rules.
- `notifications`: in-app notifications and provider abstraction.
- `audit`: append-oriented audit events.
- `observability`: request IDs, structured logs, health/readiness.
- `access-requests`: public request intake with server persistence and rate limiting.

### 3.3 Request flow

1. Parse and validate the request at the API boundary.
2. Resolve the authenticated identity.
3. Resolve the active school membership or explicitly authorized Founder context.
4. Authorize the capability against the requested resource.
5. Execute domain logic in a transaction when multiple records change.
6. Persist the domain change and audit event together where applicable.
7. Derive the response from authorized data.
8. Emit structured logs without secrets or unnecessary sensitive fields.

### 3.4 Error model

The API should use a consistent JSON error shape containing a stable machine-readable code, safe user-facing message, request ID, and optional field errors. It should distinguish:

- unauthenticated;
- authenticated but forbidden;
- invalid input;
- missing resource;
- conflict;
- connectivity/retryable failure;
- unexpected server failure.

The browser must only queue attendance for a genuine connectivity or retryable transport failure. A `401`, `403`, validation error, or conflict must remain visible and must not be mislabeled as offline.

---

## 4. Data model direction

The final schema should use stable IDs, foreign keys, constraints, indexes, and migrations. Exact table names may change during implementation, but the relationships below are required.

### 4.1 Platform and identity

- `users`: global identity record; no school-specific role stored as the only authorization source.
- `schools`: tenant/workspace record and lifecycle status.
- `school_memberships`: user-to-school relationship, status, role/capability grants, timestamps.
- `sessions` or an equivalent durable session mechanism: revocable, expiring, secure.
- `invitations`: school-scoped, hashed/one-time acceptance token, intended role/capabilities, expiry, revocation, acceptance metadata.
- `founder_memberships`: separate platform-level authorization; never infer from a school role.

### 4.2 School operations

- `academic_years` and `terms`: school-scoped period structure.
- `classes`: school-scoped class records with lifecycle status.
- `subjects`: school-scoped subject records when required for attendance context.
- `class_staff_assignments`: explicit teacher/staff assignments with effective dates/status.
- `students`: canonical school-scoped student record.
- `student_enrollments`: class placement and lifecycle history rather than overwriting history without trace.
- `guardians` and `student_guardians`: only if parent access is included in the implemented slice.

### 4.3 Attendance

- `attendance_records`: unique constraint on the chosen attendance grain, at minimum school + date + class + student, with actor and update metadata.
- `attendance_changes` or equivalent correction history if the product needs a durable record of changes.
- Optional sync metadata should not be trusted as proof of server synchronization; server acceptance and client sync state are separate concepts.

### 4.4 Events and oversight

- `audit_events`: school ID where applicable, actor identity, action, resource type/ID, timestamp, request ID, safe context.
- `notifications`: in-app events with recipient and read state.
- `access_requests`: server-owned public request records with abuse controls and processing state.
- Platform health/error/usage records should be introduced only with a concrete retention and privacy policy.

### 4.5 Required constraints and indexes

At minimum:

- Foreign keys for every school-owned relationship.
- Unique school slug or equivalent workspace identifier.
- Unique membership per user/school.
- Unique active invitation token digest.
- Unique student identifier within a school where the school uses one.
- Unique attendance record at its actual business grain.
- Indexes on school ID, active membership, class assignment, student enrollment, attendance date/class, audit timestamp, and invitation status/expiry.
- Check constraints or application validation for lifecycle/status values.

---

## 5. Authentication and authorization decisions

### 5.1 Authentication

The demo role selector must be removed from the production path. The implementation must support:

- account creation during school onboarding;
- secure sign-in;
- secure session expiration and revocation;
- invitation acceptance and identity linking;
- password recovery or a passwordless flow;
- inactive/revoked membership enforcement;
- safe logout;
- rate limiting and failed-attempt observability.

The final provider choice is an infrastructure decision and must not be invented in code. If an external managed identity service is selected, its connection must be explicitly added and its operational boundary documented. If credentials are implemented in-app, use a reviewed password-hashing library and durable sessions, not ad hoc cryptography.

### 5.2 School capabilities

Roles are useful defaults but are not the entire permission model. Start with a small capability vocabulary, such as:

- manage school settings;
- manage staff and invitations;
- manage classes and assignments;
- manage students;
- record attendance;
- correct attendance;
- view attendance history;
- view school activity;
- manage notifications.

Membership authorization must answer:

> Who can perform what, on which school/resource, under which conditions?

Teacher access must be assignment-scoped. A principal or administrator may have broader school capabilities without automatically gaining every platform capability.

### 5.3 Founder control plane

The Founder UI must not be reachable as a public hash route. It needs:

- separate authentication and platform-level authorization;
- an explicit route and API boundary;
- default read-only access;
- deliberate, logged privileged access when viewing a school;
- no automatic unrestricted access to student-sensitive data;
- access review/revocation;
- Founder audit events;
- clear environment separation between platform and school operations.

---

## 6. Implementation sequence

The stages are ordered by dependency. Do not start a later stage by faking an earlier prerequisite.

### Stage 0 — Baseline, documentation, and safety

**Priority:** P0  
**Goal:** Make the current state reproducible before changing architecture.

Deliverables:

- Keep the existing audit and this plan in the repository.
- Add a build log/decision log updated at each implementation stage.
- Capture current API behavior as smoke tests before changing routes.
- Define development, test, and production configuration names.
- Decide how the current JSON demo data will be imported or preserved as an explicit demo seed.
- Define a backup of the current JSON file before any migration.

Exit checks:

- Baseline smoke checks pass.
- Existing demo behavior is recorded as a compatibility reference.
- No production data is treated as disposable without an explicit migration/backup step.

### Stage 1 — Database and tenant foundation

**Priority:** P0  
**Depends on:** Stage 0 and an explicit database connection decision.  
**Goal:** Replace implicit single-school ownership with relational, tenant-aware storage.

Deliverables:

- PostgreSQL-compatible database connection using environment configuration.
- Migration runner and repeatable migration process.
- Core platform, identity, school, membership, academic, student, attendance, invitation, and audit tables.
- Foreign keys, unique constraints, indexes, and transaction boundaries.
- Explicit school context in every school-owned query.
- Import script for the current JSON demo data that creates one clearly marked seed/demo school.
- Backup and recovery runbook appropriate to the chosen free-tier database.

Exit checks:

- A second school can be created in test data without code changes.
- Queries for one school cannot return another school’s records.
- Restarting the application does not lose data or sessions unexpectedly.
- Migration and seed commands are documented and repeatable.

### Stage 2 — Real identity and invitation lifecycle

**Priority:** P0  
**Depends on:** Stage 1.  
**Goal:** Replace role selection with real user identity and school membership.

Deliverables:

- School creator onboarding.
- First administrator/principal membership creation.
- Sign-in, logout, expiration, revocation, and recovery.
- Invitation creation, expiry, revocation, one-time acceptance, and account linking.
- Role/capability checks on every protected route.
- Secure session secret requirement with no known fallback in production.
- Rate limits and safe failed-authentication logging.

Exit checks:

- An unauthenticated user cannot access school state.
- A user cannot select a role to gain access.
- An invited user can join only the intended school.
- An inactive/revoked user loses access.
- Password/session material is never logged or returned.

### Stage 3 — School onboarding and administration

**Priority:** P1  
**Depends on:** Stages 1–2.  
**Goal:** Ensure a new school is guided into a usable state rather than dropped into an empty dashboard.

Deliverables:

- School/workspace creation.
- School settings UI backed by the existing conceptual `/api/school` capability.
- Academic year and term setup.
- Class creation/edit/archive.
- Staff list and invitation status.
- Teacher assignment and reassignment.
- Student create/edit/archive.
- Stable student identifiers and validation.
- Activity events for important mutations.
- Empty states and next-step guidance.

Exit checks:

- A school can complete setup without database edits.
- A staff member can be invited and linked.
- Assignments are represented by one authoritative relationship.
- Archived records are not offered as active choices.
- Every mutation refreshes or invalidates related summaries.

### Stage 4 — Attendance as the hero workflow

**Priority:** P0/P1  
**Depends on:** Stages 1–3.  
**Goal:** Make attendance fast, safe, mobile-first, and honest about synchronization.

Deliverables:

- Context-aware teacher attendance entry for assigned classes and current date.
- Present, absent, late, and excused states.
- Sensible bulk actions with reversible changes.
- Server validation of date, class, student, assignment, and attendance grain.
- Duplicate-safe upsert/correction semantics with conflict rules.
- Attendance history and principal visibility.
- Real status model: saved locally, pending sync, syncing, synced, failed, conflict.
- IndexedDB queue with durable records and retry metadata.
- Cached attendance application shell/service worker where supported.
- Retry classification that does not queue auth, permission, or validation failures.
- Clear recovery UI and a user-visible failed-sync state.

Exit checks:

- Attendance can be completed with minimal mobile interaction.
- A browser reload does not erase pending records.
- Connectivity loss does not cause silent loss.
- A successful write with a lost response is idempotent and does not create duplicate attendance.
- A conflicting update is surfaced rather than silently overwritten.
- The user is never told “synced” before server acceptance is known.

### Stage 5 — Principal oversight from real data

**Priority:** P1  
**Depends on:** Stages 1–4.  
**Goal:** Answer “What is happening in my school?” using actual school records.

Deliverables:

- Today’s attendance completion and absences.
- Late students.
- Classes missing attendance.
- Teacher completion state.
- Recent activity.
- Actionable alerts/signals derived from documented rules.
- Attendance history and basic trend summaries.
- Search limited by school membership and capability.

Exit checks:

- No hardcoded operational metrics remain in school views.
- A new attendance record changes the relevant school summary.
- Missing attendance is discoverable.
- Every metric has a documented source query and definition.

### Stage 6 — Founder/system control plane

**Priority:** P0/P1  
**Depends on:** Stages 1–2 and enough real school data from Stage 3.  
**Goal:** Replace the public static Founder concept with a secure internal oversight layer.

Deliverables:

- Protected Founder routes and APIs.
- Founder membership/capabilities separate from school roles.
- Real school directory and lifecycle status.
- Safe, read-only-by-default tenant overview.
- Platform activity and audit views with redaction.
- Health/readiness signals based on real checks.
- Error/security event visibility at an appropriate privacy level.
- Explicit privileged access workflow with reason and audit record.

Exit checks:

- A school user cannot access Founder APIs.
- A Founder without the required capability cannot perform privileged actions.
- Founder views do not expose an entire school roster by default.
- Static sample metrics are removed or isolated to a clearly labeled demo environment.

### Stage 7 — Public access requests and lightweight notifications

**Priority:** P1/P2  
**Depends on:** Stage 1 and operational logging.  
**Goal:** Make public interest and in-app follow-up real without adding expensive channels.

Deliverables:

- Server-backed access request intake.
- Server-side validation and abuse/rate controls.
- Processing status and audit history.
- In-app notification abstraction.
- Optional email provider behind a provider interface; email is not a launch dependency.

Exit checks:

- Browser localStorage is not the source of truth.
- Duplicate/spam behavior is controlled.
- Operators can see and process requests safely.

### Stage 8 — Observability, testing, and deployment hardening

**Priority:** P0/P1  
**Depends on all implemented production paths.  
**Goal:** Make failures diagnosable and protect critical business behavior.

Deliverables:

- `/health` and `/ready` behavior with documented semantics.
- Request IDs and structured logs.
- Safe unexpected-error handling.
- Automated API/integration tests for auth, authorization, tenant isolation, students, assignments, attendance, duplicate safety, and persistence.
- Offline synchronization unit tests.
- Browser smoke coverage for onboarding, attendance, logout, and key responsive states.
- Deployment smoke command.
- Graceful shutdown and connection cleanup.
- Production configuration checklist.
- Backup/recovery test record.

Exit checks:

- Critical permission tests fail if tenant scoping regresses.
- Tests run from a clean checkout with documented setup.
- A deployment can be checked without manually inspecting the UI.
- Logs are useful without containing secrets or unnecessary student data.

---

## 7. What to preserve

Preserve the following concepts and useful work where they remain compatible:

- SchVIA’s product language and calm visual direction.
- Public marketing copy and brand assets, subject to a later design-system pass.
- The four attendance states.
- The current teacher-assignment restriction as a business rule.
- The existing audit intent: important mutations create activity records.
- Responsive/mobile priorities.
- The current school demo data as an importable, explicitly labeled seed.
- The product boundary against premature finance, AI, and unrelated modules.
- The simple single-process operational shape until a real scale requirement appears.

Preservation does not mean preserving the current file layout or JSON model.

## 8. What to replace

Replace, rather than cosmetically patch:

- Demo role selection as production authentication.
- In-memory sessions.
- The hardcoded session-secret fallback.
- Global JSON arrays as the operational source of truth.
- Implicit one-school ownership.
- Duplicated class/user assignment relationships.
- localStorage as the durable attendance queue.
- Public `#dashboard` Founder access.
- Hardcoded Founder metrics and health values.
- Browser-only access-request storage.
- Broad offline error swallowing.
- Inert controls that appear functional but do not perform an action.
- Any UI that claims live operational state without a real source.

## 9. Infrastructure decision record

This plan intentionally does not invent a provider or credential.

Before Stage 1 implementation, select:

1. A free-tier PostgreSQL-compatible database that exposes a portable connection string and supports backups/export.
2. An authentication approach that supports real identity, invitation linking, session lifecycle, and the Founder boundary.
3. Whether email is required for the first pilot or can remain an in-app/manual provider.

Selection criteria:

- Free or affordable at pilot scale.
- Portable APIs and schema.
- Clear failure behavior.
- No unnecessary vendor lock-in.
- Suitable data protection and backup story.
- No credentials committed to the repository.

The chosen services and non-secret configuration names must be recorded in `replit.md` and the deployment runbook. Secrets must be supplied through the environment/secrets mechanism, never placed in documentation.

## 10. Migration strategy and risks

### Migration approach

1. Snapshot the current JSON file.
2. Create the relational schema through migrations.
3. Import the single current school as a named demo/seed school.
4. Map seeded users to memberships.
5. Map class assignments into the authoritative assignment table.
6. Map students and attendance by stable IDs.
7. Map invitations and audit records with an explicit source marker.
8. Run count/referential-integrity checks.
9. Switch read paths to the database.
10. Keep the JSON file read-only as a rollback reference until the migration is accepted.
11. Remove JSON writes only after a verified cutover.

### Main risks

- Existing data has implicit school ownership, so importing without a tenant wrapper would preserve the core flaw.
- Existing user `classIds` and class `teacherIds` can disagree; the migration must choose one authoritative source and record discrepancies.
- The current audit is capped and may not be a complete production history.
- Attendance retry semantics could duplicate activity if idempotency is not designed before the client migration.
- Introducing a framework or provider too early could obscure domain boundaries rather than improve them.
- A managed authentication/database choice may require environment setup outside the codebase; implementation must stop at that boundary rather than inventing credentials.
- Parent access adds privacy, consent, and relationship requirements; it should not be enabled by name lookup.

## 11. Validation matrix

Every stage must be validated with evidence.

### API and data

- Unauthenticated protected request is rejected.
- Wrong school membership cannot read or mutate another school.
- Wrong capability is rejected.
- Invalid foreign keys are rejected.
- Duplicate attendance is idempotent.
- Database transaction rollback leaves related records consistent.
- Persistence survives application restart.

### Identity

- New account/workspace creation works.
- Invitation can be accepted once, expires, and can be revoked.
- Inactive membership cannot authenticate into school operations.
- Logout/revocation invalidates the session.
- Founder and school sessions cannot cross boundaries.

### Attendance

- Assigned teacher can record attendance.
- Unassigned teacher cannot record attendance.
- All supported statuses persist.
- Invalid date/class/student/status fails safely.
- Offline records survive reload.
- Connectivity retry distinguishes retryable and permanent failures.
- Conflict states are visible.

### UI and accessibility

- Core flows are usable on mobile, tablet, and desktop.
- Attendance is reachable with minimal navigation.
- Buttons state their action clearly.
- Empty/loading/error/success/pending states are explicit.
- Keyboard navigation and labels are present for forms and status controls.
- Sensitive data is not exposed in unauthorized screens.

### Operations

- Health and readiness endpoints are meaningful.
- Logs include request IDs and safe event context.
- No secrets, tokens, or unnecessary student data appear in logs.
- Database migration and backup/recovery commands are documented and tested.

## 12. Documentation deliverables

The implementation is not complete until these are maintained:

- `replit.md`: project overview, local run, environment names, deployment entry points, and current product boundary.
- This plan: target architecture and sequence; update only when a durable decision changes.
- A build/decision log: dated implementation milestones, decisions, verification evidence, and unresolved risks.
- Database README/runbook: migration, seed, backup, restore, and production safety.
- Authentication/access README: identity flows, roles, capabilities, invitation lifecycle, and Founder boundary.
- Offline attendance README: state machine, IndexedDB records, retry rules, and conflict behavior.
- API reference: routes, authorization, request/response/error shapes.
- Test README: commands, required services, and coverage boundaries.
- Deployment runbook: development, test, production, environment variables, startup, health checks, and rollback.

Documentation must describe actual behavior, not intended behavior. Every incomplete feature must be labeled as incomplete.

## 13. Definition of done for the first real pilot

The first pilot foundation is ready only when:

- A real school can create an isolated workspace.
- The first administrator has a real identity.
- Staff can be invited and accept invitations.
- School membership and capabilities are enforced server-side.
- Classes, assignments, and students can be managed without direct database edits.
- Teachers see only assigned responsibilities.
- Attendance works online and offline.
- Pending, synced, failed, and conflict states are honest and recoverable.
- Attendance persists reliably and duplicate saves are safe.
- Principals see real school activity and actionable attendance status.
- Important changes are auditable.
- Founder access is protected and separate.
- No critical workflow depends on hardcoded operational metrics.
- Backups, migrations, health checks, and tests are documented and runnable.
- The application remains deployable outside Replit.

---

## 14. Immediate next action

Before implementing Stage 1, make one explicit infrastructure decision for:

- the PostgreSQL-compatible database;
- the authentication/session approach;
- whether pilot invitations require email at launch.

No secret value belongs in this document. Once those choices are confirmed and connected, implementation should begin at Stage 0 and proceed in dependency order. Do not start by polishing the static Founder dashboard or adding more CRUD screens to the JSON prototype.
