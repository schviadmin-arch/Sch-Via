# SCHVIA IMPLEMENTATION ROADMAP

## Mission 001 — Repository audit
Objective: Establish an accurate engineering understanding of the current repository without making product changes.
Why: The repository is the source of truth and must be mapped before work proceeds.
Dependencies: None.
Files/systems likely affected: Documentation only.
Acceptance criteria:
- Current architecture and implementation are documented.
- Existing tests are run and results are recorded.
- Risks, missing functionality, and preservation needs are identified.
Tests required: `node tests/smoke.mjs`, `node tests/real-user-e2e.mjs`.
Risk level: Low.

## Mission 002 — Add package manifest and runtime metadata
Objective: Introduce explicit Node.js package metadata, scripts, and reproducible runtime configuration.
Why: The repository currently has no `package.json`, making dependency and runtime management fragile.
Dependencies: Mission 001.
Files/systems likely affected: `package.json`, `.replit`, `serve.mjs`, documentation.
Acceptance criteria:
- A valid `package.json` exists with node version, scripts, and dependency declarations.
- Startup scripts use `npm start` or equivalent.
- Tests can be run through `npm test`.
- Existing behavior is unchanged.
Tests required: `npm test` wrappers around existing smoke and E2E tests.
Risk level: Low.

## Mission 003 — Harden session and secret management
Objective: Remove development secret fallback, secure session cookie settings, and centralize config.
Why: The app currently allows production startup with an insecure fallback secret and uses in-memory sessions without durable config.
Dependencies: Mission 002.
Files/systems likely affected: `serve.mjs`, `README`, environment documentation.
Acceptance criteria:
- `SESSION_SECRET` must be defined in all non-test environments.
- `NODE_ENV=production` disables fallback secrets.
- Session cookie settings include `Secure` in production and clear expiration.
- Existing tests pass.
Tests required: existing smoke tests, plus a production-start check.
Risk level: Low.

## Mission 004 — Stabilize tenant-aware persistence
Objective: Replace the prototype JSON store with a relational data layer and migration scaffold.
Why: The current persistence approach is not durable, not scalable, and lacks transactional integrity.
Dependencies: Mission 003.
Files/systems likely affected: data access layer, `serve.mjs`, schema/migrations, tests.
Acceptance criteria:
- A database schema exists for schools, users, memberships, classes, students, attendance, invitations, audit.
- Data access is abstracted away from raw JSON file operations.
- Seed/demo data is preserved as explicit migration or seed data.
- Existing tests are updated to use the new datastore and pass.
Tests required: smoke tests, E2E tests against new persistence.
Risk level: High.

## Mission 005 — Build core auth and registration flows
Objective: Implement robust principal registration, login, staff invitation, and invitation acceptance with email/password flows.
Why: The current auth flow mixes demo role login with real account registration and lacks recovery or invitation lifecycle.
Dependencies: Mission 004.
Files/systems likely affected: `serve.mjs`, auth helpers, tests, frontend auth forms.
Acceptance criteria:
- New school registration creates a school, user, and membership.
- Email/password login authenticates against stored credentials.
- Invitation acceptance creates a staff user and membership.
- Demo role login is deprecated or clearly separated.
- Existing tests pass and new auth tests cover lifecycle.
Tests required: registration, login, invitation creation, invitation acceptance, invalid credentials.
Risk level: High.

## Mission 006 — Introduce explicit capability-based authorization
Objective: Move from coarse roles to a capability model and enforce it on school mutations.
Why: Roles alone are too broad; permissions should be explicit and extensible.
Dependencies: Mission 005.
Files/systems likely affected: authorization helpers, membership data model, route guards.
Acceptance criteria:
- Capabilities are stored as part of school membership.
- Routes check capabilities rather than only role names.
- Teachers can only perform attendance and view allowed school data.
- Principals/admins retain the necessary broader capabilities.
Tests required: permission matrix tests for each route.
Risk level: Medium.

## Mission 007 — Add student/class editing and lifecycle management
Objective: Introduce editing, archival, and class assignment workflows for students and classes.
Why: Current data creation is one-way; real operations need edit and lifecycle controls.
Dependencies: Mission 006.
Files/systems likely affected: `serve.mjs`, frontend forms, data model.
Acceptance criteria:
- Students can be updated and archived.
- Classes can be updated and teacher assignments changed.
- Assigned teachers see updated class/student state immediately.
- Existing tests pass.
Tests required: edit/update flows and permission enforcement.
Risk level: Medium.

## Mission 008 — Harden attendance sync and offline behavior
Objective: Implement durable offline attendance storage, correct sync state, and conflict handling.
Why: The current offline queue is localStorage-only and lacks a proper sync model.
Dependencies: Mission 006, Mission 007.
Files/systems likely affected: `app.js`, browser storage layer, attendance API.
Acceptance criteria:
- Attendance queue persists in IndexedDB or equivalent.
- Offline save states are distinct from validation/authorization failures.
- Sync retry is deterministic and recoverable.
- Existing tests pass and offline sync tests are added.
Tests required: offline persistence and sync, conflict resolution, validation.
Risk level: High.

## Mission 009 — Build a real Founder control plane
Objective: Replace the static founder dashboard with an authenticated oversight interface.
Why: The current founder UI is mock data and does not represent actual platform access control.
Dependencies: Mission 004, Mission 005.
Files/systems likely affected: frontend dashboard, API, platform auth.
Acceptance criteria:
- Founder login is separate from school login.
- Founder workspace reads real school data with explicit access controls.
- Founder actions are audited and read-only by default.
- Existing tests pass.
Tests required: founder auth, data isolation, oversight access.
Risk level: High.

## Mission 010 — Add deployment, backup, and observability
Objective: Add CI scripts, deployments, backup guidance, and operational observability.
Why: The repo lacks deployment automation and no backup strategy exists for persisted data.
Dependencies: Mission 004, Mission 005, Mission 009.
Files/systems likely affected: CI config, deployment docs, health checks, backup scripts.
Acceptance criteria:
- Repository has a testable CI pipeline.
- Health/readiness checks are documented and used in deploy scripts.
- Persistence backup recommendations are documented.
- Existing tests pass in CI.
Tests required: CI verification of smoke and E2E tests.
Risk level: Medium.
