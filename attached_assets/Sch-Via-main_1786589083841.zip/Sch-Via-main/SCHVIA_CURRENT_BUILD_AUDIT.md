# SchVIA Current Build Audit

**Audit scope:** Existing code and configuration only. No application files, data, dependencies, or workflows were modified during the audit.

**Runtime verification performed:**

- `node serve.mjs` is running successfully on port `5000`.
- Public `/` returned HTTP `200`.
- Unauthenticated `/api/state` returned HTTP `401`.
- Principal login and state loading returned HTTP `200`.
- Teacher login and state loading returned HTTP `200`.
- Teacher access to Principal-only endpoints returned HTTP `403`.
- Teacher attendance access to an unassigned class returned HTTP `403`.
- `node --check serve.mjs` and `node --check app.js` passed.
- No automated test suite exists.
- Current persisted state contains:
  - 1 school
  - 2 users
  - 2 classes
  - 5 students
  - 0 attendance records
  - 0 invitations
  - 0 audit records

---

# 1. CURRENT PRODUCT

## What has actually been built

SchVIA is currently a dependency-free school operations MVP consisting of:

1. A public marketing website.
2. A static Founder command-center preview.
3. A working school workspace backed by a local JSON file.
4. Demo role selection for Principal and Teacher.
5. Principal workflows for:
   - Viewing school overview
   - Viewing students
   - Adding students
   - Viewing staff
   - Creating staff invitations
   - Creating classes
   - Viewing activity records
6. Teacher workflows for:
   - Viewing assigned classes and students
   - Taking attendance
   - Saving attendance online
   - Queuing attendance while offline
   - Retrying queued attendance when the browser reconnects
7. Server-side role checks and basic school/class visibility filtering.
8. Basic server-side audit events for selected mutations.

The project is not a full production school management platform. It is a narrow functional pilot/demo slice.

## Existing pages and screens

### A. Public marketing site

Served from `/`.

Sections include:

- Hero section
- Platform explanation
- “How it works” / reasoning section
- “For schools” section
- Request-a-school-pilot call-to-action
- Sign-in/workspace chooser
- Footer

Evidence: `index.html:44-161`, `index.html:200`

The marketing page is functional as a static interface, but its content is hardcoded.

### B. Early-access request modal

Opened by buttons such as:

- “Talk to SchVIA”
- “Request a school pilot”

The modal collects:

- Name
- Work email
- Institution type

The submission is stored in browser `localStorage` under:

```text
schvia_access_request
```

It does not send the request to a server, email provider, CRM, or database.

Evidence: `index.html:203-204`, `app.js:51-63`, `app.js:115-121`

**Status: UI works, but backend routing is not built.**

### C. Workspace chooser

The chooser offers:

1. Founder command center
2. School workspace

Evidence: `index.html:206-224`

The Founder option does not authenticate the user. The School option opens the demo role-selection screen.

### D. Founder command center

Opened through `#dashboard`.

It contains these visual panels:

- Command center
- Institutions
- Signals
- Activity log
- Access & roles
- Workspace settings button
- Founder profile display

Evidence: `index.html:163-196`

The Founder dashboard explicitly identifies itself as:

> “Sample network view · not connected to school data”

That statement is accurate.

The visible values are hardcoded sample content, including:

- 12 active institutions
- 1,846 people
- 94.2% attendance
- 3 open signals
- 98.6 operational health score
- Northbridge, Maji Primary, Arborfield Academy, Eastgate Community
- Sample activity and audit records

There are no Founder API routes or Founder database queries.

**Status: static UI/mock data.**

### E. School workspace login

Opened through `#pilot`.

The user can choose:

- Principal
- Teacher

No email, password, invitation code, or identity verification is required.

Evidence: `app.js:189-191`

The selected role is submitted to:

```text
POST /api/auth/login
```

Evidence: `app.js:270`, `serve.mjs:142-149`

### F. Principal workspace

The Principal can access:

- Overview
- Attendance
- Students
- Staff & classes
- Activity log

Evidence: `app.js:169-186`

The Principal can:

- View the school
- View all classes
- View all students
- View all users
- Add students
- Create classes
- Create staff invitations
- Save attendance for any class
- View audit activity

### G. Teacher workspace

The Teacher can access:

- Overview
- Attendance
- Students

The Teacher only receives assigned classes and students.

The currently seeded Teacher, Kofi Owusu, is assigned to Primary 5. Runtime verification confirmed that:

- The Teacher sees Primary 5.
- The Teacher sees 4 students.
- The Teacher does not see Primary 6.
- Principal-only mutations return HTTP `403`.

### H. Attendance screen

Attendance supports:

- Class selection
- Date selection
- Four statuses:
  - Present
  - Absent
  - Late
  - Excused
- Online save
- Offline queue
- Reconnect retry

Evidence: `app.js:221-229`, `app.js:244-259`, `app.js:292`

This is the most complete working workflow in the application.

## What is only UI/mock data

The following Founder functionality is visual only:

- Institution directory
- Add institution
- System health
- Signals
- Connected signal review
- Founder activity log
- Access model review
- Search
- Notifications
- Workspace settings
- Date filters
- “See all institutions”
- “View system health”
- “Open activity log”

The public marketing content is also static.

The access-request form is UI plus browser-local storage, but not a real access-request workflow.

## What is incomplete

Incomplete or intentionally absent:

- Real identity management
- Password or passwordless authentication
- Invitation acceptance
- Password recovery
- Account creation
- User editing
- User deactivation
- Teacher assignment editing
- Class editing
- Class deletion
- Student editing
- Student deletion
- Parent access
- Communications
- Grading
- Fees or payments
- Email delivery
- Founder authentication
- Founder operational oversight
- Institution creation
- Institution management
- System health collection
- Usage analytics
- Error monitoring
- Security event monitoring
- Database-backed multi-tenancy
- Automated tests
- Production-grade deployment hardening

---

# 2. ARCHITECTURE

## Framework and version

There is no frontend framework.

The project uses:

- Plain HTML
- Plain CSS
- Browser JavaScript
- Native Node.js HTTP server
- Node.js 20 Replit module

Evidence: `.replit`, `index.html`, `styles.css`, `app.js`, `serve.mjs`

No package manifest exists:

- No `package.json`
- No lockfile
- No frontend build tool
- No dependency installation step
- No compiled build output

## Frontend structure

The frontend is a single-page static interface.

Primary files:

```text
index.html
styles.css
app.js
favicon.svg
```

The frontend uses:

- DOM manipulation
- HTML templates generated through string interpolation
- `fetch()` for API calls
- `localStorage` for access requests and offline attendance
- URL hash navigation:
  - `#home`
  - `#dashboard`
  - `#pilot`

There is no:

- React
- Vue
- Svelte
- Angular
- Router library
- Component system
- State-management library
- TypeScript
- Frontend build pipeline

## Backend/API structure

The backend is implemented in one file:

```text
serve.mjs
```

It creates a native Node HTTP server using `createServer`.

It serves static files and handles API routes manually.

API endpoints currently implemented:

```text
POST /api/auth/login
POST /api/auth/logout
GET  /api/state
POST /api/school
POST /api/users
POST /api/classes
POST /api/students
POST /api/attendance
```

Evidence: `serve.mjs:141-231`

There is no:

- Express
- Fastify
- Hono
- ORM
- Request schema library
- API versioning
- OpenAPI specification
- Health endpoint
- Background worker
- Job queue

## Database and schema

There is no database.

Operational data is stored in:

```text
data/schvia.json
```

The JSON structure contains:

```text
school
users
classes
students
attendance
invitations
audit
```

Evidence: `serve.mjs:20-46`, `data/schvia.json`

The file is loaded at server startup and rewritten after mutations:

```js
data = JSON.parse(await readFile(dataPath, "utf8"))
await writeFile(dataPath, JSON.stringify(data, null, 2))
```

Evidence: `serve.mjs:48-59`

`data/` is ignored by Git:

```text
.gitignore:8
```

This means the runtime data file is not part of the tracked repository.

## Authentication

Authentication is demo role selection.

The user submits either:

```json
{ "role": "principal" }
```

or:

```json
{ "role": "teacher" }
```

The server selects the first active seeded user with that role.

Evidence: `serve.mjs:142-149`

There is no actual identity verification.

The server creates an in-memory session ID and signs it with HMAC-SHA256.

The session is stored in:

```js
const sessions = new Map();
```

The session cookie is:

- HTTP-only
- SameSite=Lax
- Path `/`
- Max-Age 28,800 seconds

Evidence: `serve.mjs:80-95`

## Authorization and roles

Implemented roles:

- Principal
- Teacher

There is also a stored invitation option for Administrator. However, the Administrator role is not a working authenticated role.

Role protection is implemented using:

```js
requireRole(request, response, roles)
```

Evidence: `serve.mjs:98-109`

Principal-only actions:

- School settings
- Staff invitations
- Class creation
- Student enrollment

Principal and Teacher actions:

- Read state
- Save attendance

Teacher class visibility is filtered through class `teacherIds`.

Evidence: `serve.mjs:123-138`, `serve.mjs:216-217`

Runtime verification confirmed the intended Principal/Teacher boundaries.

## State management

Frontend state is held in module-level variables:

```js
pilotState
pilotRole
pilotPanel
pendingAttendance
pilotLastUpdated
```

Evidence: `app.js:1-12`

There is no centralized state library.

The server state is fetched through:

```text
GET /api/state
```

The frontend refreshes state:

- On school workspace entry
- On browser focus
- On reconnect
- On manual refresh

Evidence: `app.js:149-167`, `app.js:292-297`

## Storage

### Server storage

Local JSON file:

```text
data/schvia.json
```

### Browser storage

The browser uses `localStorage` for:

```text
schvia_access_request
schvia_attendance_queue
```

There is no IndexedDB.

There is no object storage.

## Integrations

No integrations are configured or used.

The only external browser dependency is Google Fonts:

```html
fonts.googleapis.com
fonts.gstatic.com
```

Evidence: `index.html:13-17`

There is no:

- Email provider
- CRM
- Payment provider
- Authentication provider
- Analytics provider
- Monitoring provider
- Database integration
- Messaging service

## Environment variables and configuration

The server reads:

```text
PORT
SESSION_SECRET
```

Evidence: `serve.mjs:8-10`

Behavior:

```js
process.env.PORT || 5000
```

and:

```js
process.env.SESSION_SECRET || "schvia-local-development-secret"
```

The Replit environment includes `SESSION_SECRET`, but the hardcoded fallback remains a production risk.

## PWA/offline capabilities

This is not a PWA.

There is no:

- `manifest.webmanifest`
- Service worker
- Cache storage
- Install prompt
- Offline application shell
- Background Sync API
- IndexedDB

There is a limited attendance offline queue:

1. Attendance is stored in `localStorage`.
2. The browser displays an offline state.
3. The queue retries on the `online` event.
4. The server is updated when connectivity returns.

Evidence: `app.js:11`, `app.js:145-167`, `app.js:249-259`, `app.js:292`

The app itself cannot reliably be opened from a cold start without network access because there is no service-worker cache.

---

# 3. FUNCTIONALITY STATUS

| Feature | Status | Evidence / explanation |
|---|---|---|
| Public marketing page | **WORKING** | Static page served from `/`; verified HTTP `200` |
| Responsive styling | **WORKING** | Responsive CSS media rules exist |
| Mobile navigation | **WORKING** | Menu toggling exists in `app.js:95-99` |
| Workspace chooser | **WORKING** | Modal routes to Founder or School workspace |
| Founder dashboard display | **UI ONLY** | Static HTML with hardcoded network data |
| Founder authentication | **NOT BUILT** | `#dashboard` opens without a server session |
| Founder institution management | **UI ONLY** | “Add institution” has no handler/API |
| Founder signals | **UI ONLY** | Static sample signals |
| Founder system health | **UI ONLY** | Hardcoded health score and rows |
| Founder activity log | **UI ONLY** | Hardcoded activity records |
| Founder access governance | **UI ONLY** | Static explanatory panel |
| Early-access request form | **PARTIALLY WORKING** | Saves locally to browser `localStorage`; does not submit externally |
| Demo Principal login | **WORKING** | Verified HTTP `200` and Principal state |
| Demo Teacher login | **WORKING** | Verified HTTP `200` and Teacher state |
| Real user authentication | **NOT BUILT** | No identity verification, credentials, or account creation |
| Logout | **WORKING** | Deletes in-memory session and clears cookie |
| School state loading | **WORKING** | Verified authenticated state response |
| Principal school overview | **WORKING** | Renders persisted school state |
| Teacher school overview | **WORKING** | Renders assigned school data |
| Student list | **WORKING** | Reads persisted students |
| Add student | **WORKING** | Principal API and UI exist |
| Edit student | **NOT BUILT** | No edit route or UI |
| Delete student | **NOT BUILT** | No delete route or UI |
| Class list | **WORKING** | Reads persisted classes |
| Add class | **WORKING** | Principal API and UI exist |
| Edit class | **NOT BUILT** | No edit route or UI |
| Delete class | **NOT BUILT** | No delete route or UI |
| Teacher assignment at class creation | **PARTIALLY WORKING** | Can choose a teacher while creating a class |
| Teacher reassignment | **NOT BUILT** | No update route or UI |
| Staff list | **WORKING** | Principal can view seeded staff |
| Staff invitations | **PARTIALLY WORKING** | Invitation record and code are created; no delivery or acceptance |
| Invitation expiration/revocation | **NOT BUILT** | No routes or logic |
| Administrator role | **NOT BUILT** | Stored as an invitation option but not an operational role |
| Attendance class selection | **WORKING** | UI and server validation exist |
| Attendance date selection | **WORKING** | UI accepts a date and server stores it |
| Present/absent/late/excused statuses | **WORKING** | Supported in UI and server |
| Online attendance save | **WORKING** | Persists to JSON and returns updated state |
| Duplicate-safe attendance key | **WORKING/PARTIAL** | Composite key prevents duplicate record storage |
| Attendance audit event | **WORKING** | Server adds audit record on save |
| Offline attendance queue | **PARTIALLY WORKING** | Local queue/retry exists; no offline app shell |
| Automatic retry on reconnect | **PARTIALLY WORKING** | Retries queued batches, but errors are broadly swallowed |
| Activity log | **WORKING** for pilot | Principal can view persisted audit events |
| School settings API | **PARTIALLY WORKING** | Endpoint exists, but no UI invokes it |
| School settings UI | **NOT BUILT** | Founder settings button is inert; pilot has no settings form |
| Parent access | **NOT BUILT** | No parent role or routes |
| Communications | **NOT BUILT** | No messaging or notifications |
| Grading | **NOT BUILT** | No grading entities or routes |
| Finance/payments | **NOT BUILT** | No financial data or payment integration |
| Email delivery | **NOT BUILT** | Invitations and access requests do not send email |
| Analytics | **NOT BUILT** | Founder metrics are static |
| Error monitoring | **NOT BUILT** | Only console logging exists |
| Automated tests | **NOT BUILT** | No test files or test runner |
| PWA installation | **NOT BUILT** | No manifest or service worker |

---

# 4. DATA & LOGIC

## Real versus mocked data

### Real/persisted data

The following is persisted to `data/schvia.json`:

- School settings
- Users
- Classes
- Students
- Attendance
- Invitations
- Audit events

Mutating routes call `writeData()`.

Evidence: `serve.mjs:57-59`, `serve.mjs:163-229`

### Mocked/static data

The following is not connected to server state:

- Founder dashboard data
- Founder institutions
- Founder metrics
- Founder health score
- Founder signals
- Founder activity
- Founder access governance
- Founder identity/profile
- Founder date labels
- Founder notification count

These values are embedded directly in `index.html`.

## Entity relationships

### School

There is one global school object:

```text
school-northbridge
```

All operational data implicitly belongs to this single school.

There is no `schoolId` on:

- Users
- Classes
- Students
- Attendance
- Invitations
- Audit events

This is not true multi-tenant modeling.

### Users

Users contain:

- ID
- Name
- Email
- Role
- Status
- `classIds`

Teacher assignment is actually determined from the class-side `teacherIds` array, not the user-side `classIds` field.

This creates a duplicated relationship model.

### Classes

Classes contain:

- ID
- Name
- Academic year
- `teacherIds`

A class may point to one or more teacher IDs, although the UI currently creates at most one assignment.

### Students

Students contain:

- ID
- Student ID
- Name
- Gender
- Class ID
- Guardian
- Status

Each student belongs to one class through `classId`.

### Attendance

Attendance is stored as an object keyed by:

```text
date:classId:studentId
```

Each attendance record contains:

- ID
- Date
- Class ID
- Student ID
- Status
- Recorded by
- Recorded at
- Updated at
- Synced flag

This supports replacement of the same student’s attendance for the same date and class.

### Invitations

Invitations contain:

- ID
- Name
- Email
- Role
- Status
- Invited timestamp
- Random code

There is no acceptance path, expiration, revocation, or conversion from invitation to user.

### Audit events

Audit records contain:

- ID
- Actor ID
- Actor name
- Action
- Detail
- Timestamp

The audit list is capped at 100 entries.

Evidence: `serve.mjs:111-120`

## What happens when important actions occur

### Principal adds a student

1. Principal session is checked.
2. Name and class are required.
3. Class existence is checked.
4. Student is appended to `data.students`.
5. Audit event is created.
6. Entire JSON file is rewritten.
7. Updated visible state is returned.

Evidence: `serve.mjs:199-209`

### Principal creates a class

1. Principal session is checked.
2. Class name is required.
3. New class is appended.
4. Optional teacher ID is copied into `teacherIds`.
5. Audit event is created.
6. JSON is rewritten.
7. Updated state is returned.

Evidence: `serve.mjs:188-197`

The supplied teacher ID is not verified against an existing teacher before being stored.

### Principal creates an invitation

1. Principal session is checked.
2. Name and email are required.
3. Duplicate email checks are performed.
4. Invitation is added with a random code.
5. Audit event is created.
6. JSON is rewritten.
7. Invitation is displayed in the Principal UI.

Evidence: `serve.mjs:173-186`

The code is displayed to the Principal, but no invitee can use it.

### Teacher or Principal saves attendance

1. Session and role are checked.
2. Date, class, and records are required.
3. Teacher class assignment is checked.
4. Student IDs are limited to students in that class.
5. Unsupported statuses are ignored.
6. Valid records are written using a composite key.
7. Audit event is created.
8. JSON is rewritten.
9. Updated state is returned.

Evidence: `serve.mjs:211-229`

## Do related workflows automatically update?

### Yes, in limited cases

- Adding a student affects student counts and class enrollment counts.
- Creating a class affects the class list.
- Creating an invitation affects pending invitation counts.
- Saving attendance affects attendance counts and recent activity.
- Attendance updates appear in the pilot audit log.

### No, in important cases

- Creating an invitation does not create or link a user.
- Invitation codes do not trigger email delivery.
- Adding a teacher assignment does not update the user’s `classIds`.
- Founder metrics do not update from school activity.
- Founder activity does not reflect pilot audit records.
- Signals are not generated from attendance.
- System health is not calculated.
- No workflows notify users of missing or late attendance.
- No parent or guardian workflow reacts to attendance.
- No enrollment lifecycle exists beyond `status: "enrolled"`.

## Missing logic and validations

Missing or weak areas include:

- Email format validation on the server
- Date format validation
- Class existence validation for Principal attendance submissions
- Teacher ID validation when creating a class
- Duplicate student ID validation
- Duplicate class validation
- Guardian data validation
- Invitation expiry
- Invitation revocation
- Account linking
- User status enforcement beyond login lookup
- Audit event integrity protections
- Transactional writes
- Concurrent update handling
- Data backup
- Recovery
- Cross-school tenant enforcement
- Consistent error classification between offline failures and application failures

---

# 5. SECURITY

## Authentication

Current strengths:

- Sessions use random IDs.
- Session IDs are HMAC-signed.
- Cookie is HTTP-only.
- Cookie uses SameSite=Lax.
- Unauthenticated API access is rejected.

Limitations:

- No actual identity verification.
- Anyone can choose Principal.
- Anyone can choose Teacher.
- No account ownership.
- No password or passwordless challenge.
- No invitation acceptance.
- No password recovery.
- Sessions are stored only in server memory.
- Sessions disappear whenever the server restarts.
- Server-side session expiry is not explicitly enforced.
- No session cleanup process is present.
- Missing `SESSION_SECRET` falls back to a known hardcoded secret.

## Permissions

Current strengths:

- Principal-only endpoints enforce Principal role.
- Teacher cannot call Principal-only mutation endpoints.
- Teacher attendance is limited to assigned classes.
- Teacher state is filtered to assigned classes.
- Runtime tests confirmed HTTP `403` responses.

Limitations:

- The Founder dashboard bypasses authentication entirely.
- There is no Founder role in the API.
- There is no multi-school permission model.
- Administrator is not fully implemented.
- There is no permission management UI.
- There is no resource-level policy engine.
- No explicit permission checks exist for future capabilities because those capabilities do not exist.

## Tenant isolation

Tenant isolation is not implemented as a real data model.

There is only one school object and one global data file.

Missing:

- `schoolId` on school-owned records
- School membership table
- Cross-school query constraints
- School-scoped foreign keys
- Tenant-aware session context
- Tenant-aware audit records
- Tenant-aware database policies

The current class/student filtering is assignment filtering, not tenant isolation.

## Database security

There is no database.

The JSON data file is:

- Plaintext
- Local filesystem storage
- Not encrypted
- Not backed up by application logic
- Not transactionally written
- Not safe for multiple server processes
- Vulnerable to data loss if the runtime filesystem is replaced

## API protection

Current protections:

- Session check on protected routes
- Role check on protected routes
- JSON parsing
- 1 MB request-body limit
- Basic input presence checks
- Class assignment check for teachers
- Valid-student filtering for attendance

Missing protections:

- Rate limiting
- Brute-force controls
- CSRF tokens
- Request correlation IDs
- API versioning
- Security headers
- Structured validation schemas
- Audit logging for failed access attempts
- IP/device/session monitoring
- Centralized error handling
- Production request logging
- Content security policy
- Explicit HTTPS enforcement
- Secure cookie flag

The absence of CSRF tokens is partly mitigated by `SameSite=Lax`, but it is not a complete production CSRF strategy.

## Sensitive-data handling

The app stores and returns:

- Names
- Work emails
- Guardian names
- Student identity information
- Attendance records

These are stored in plaintext JSON.

The app does escape rendered values in most dynamic HTML through `escapeHtml()`.

Evidence: `app.js:133-135`

However:

- There is no encryption at rest.
- There is no retention policy.
- There is no deletion workflow.
- There is no export or access-request workflow.
- There is no privacy consent system.
- There is no data access monitoring.
- There is no field-level sensitivity model.

## Founder/admin access

The Founder layer is not secure.

It is a public static route activated by:

```text
#dashboard
```

No server request is made. No session is required.

It cannot currently oversee live:

- Schools
- Users
- Activity
- System health
- Workflows
- Permissions
- Financial activity
- Errors
- Security events
- Product usage

The UI describes these concepts but does not implement the underlying capabilities.

---

# 6. FOUNDER OVERSIGHT

## Current Founder capability

The current Founder command center provides a visual concept of:

- Institution monitoring
- Signals
- Activity
- Health
- Access governance

But it is sample data only.

The UI itself clearly says:

> “Sample network view · not connected to school data”

This is verified by the code: the Founder dashboard is rendered entirely in `index.html` and has no data-fetching code.

## Capability assessment

| Oversight area | Status |
|---|---|
| View schools | **UI ONLY** |
| Create schools | **UI ONLY** |
| View users | **UI ONLY** |
| View live school activity | **NOT BUILT** |
| View system health | **UI ONLY** |
| View workflows | **NOT BUILT** |
| Manage permissions | **UI ONLY** |
| View financial activity | **NOT BUILT** |
| View errors | **NOT BUILT** |
| View security events | **NOT BUILT** |
| View product usage | **NOT BUILT** |
| Secure Founder authentication | **NOT BUILT** |
| Founder audit trail | **NOT BUILT** |
| Founder-to-school separation | **CONCEPTUAL ONLY** |

The Founder dashboard should not be treated as a secure administrative layer.

---

# 7. DEPLOYMENT

## How it currently runs

The Replit workflow runs:

```bash
node serve.mjs
```

The server listens on:

```text
process.env.PORT || 5000
```

and binds to:

```text
0.0.0.0
```

Evidence: `.replit`, `serve.mjs:7-10`, `serve.mjs:282-284`

## Build/start commands

There is no build step.

Start command:

```bash
node serve.mjs
```

No package installation is required.

## Required environment variables

Expected:

```text
PORT
SESSION_SECRET
```

`PORT` is supplied by the runtime when applicable.

`SESSION_SECRET` is expected for proper session signing, but the code has a fallback value:

```text
schvia-local-development-secret
```

That fallback should not be acceptable in production.

## Deployment configuration

`.replit` configures:

- Node.js 20
- Web module
- Workflow named `Start application`
- Port 5000 mapped to external port 80

There is no:

- Production build command
- Database migration command
- Deployment health check
- Backup process
- Seed/migration strategy
- Process manager configuration
- Graceful shutdown logic
- Production observability setup

## Known deployment risks

1. **Local JSON persistence:** Data may be lost or diverge across deployments or instances.
2. **In-memory sessions:** Sessions disappear on restart and cannot be shared between instances.
3. **Fallback session secret:** A known hardcoded secret is used if the environment variable is missing.
4. **No production database:** The app cannot safely support concurrent school operations at scale.
5. **No health endpoint:** There is no `/health` or readiness endpoint.
6. **No migration process:** Schema changes require manual JSON compatibility handling.
7. **No backup/recovery mechanism:** The server does not automatically back up `data/schvia.json`.
8. **External font dependency:** The visual design depends on Google Fonts being reachable.
9. **No security headers:** Responses do not include common security headers.
10. **Single-process assumptions:** The JSON store and in-memory sessions assume one process and one filesystem.

---

# 8. CODEBASE

## Important structure

```text
.
├── .replit
├── .gitignore
├── replit.md
├── index.html
├── styles.css
├── app.js
├── serve.mjs
├── favicon.svg
├── data/
│   └── schvia.json
├── screenshots/
│   ├── schvia-founder-dashboard.jpg
│   └── schvia-mobile-home.jpg
├── attached_assets/
│   └── Pasted--SCHVIA-CTO-LEVEL-MASTER-BUILD-PROMPT-...
└── .agents/
    └── memory/
```

## Most important files

### `index.html`

Contains:

- Public marketing page
- Founder dashboard markup
- Static Founder metrics
- Workspace modals
- Request-access form
- Pilot root container

### `styles.css`

Contains all styling for:

- Public site
- Founder dashboard
- Pilot workspace
- Modals
- Responsive behavior

### `app.js`

Contains:

- View switching
- Founder panel navigation
- Workspace login UI
- Pilot rendering
- Student/staff/class forms
- Attendance UI
- Offline queue
- API calls
- Browser event handling

### `serve.mjs`

Contains:

- Static file server
- API routes
- Session handling
- Role checks
- JSON persistence
- Audit event creation
- Attendance logic

### `data/schvia.json`

Contains current operational demo data.

This file is ignored by Git through `.gitignore`.

### `.replit`

Contains:

- Node.js 20 configuration
- Workflow setup
- Port mapping

### `replit.md`

Contains the current project handoff, product boundary, run instructions, and recommended future sequence.

---

# 9. KNOWN PROBLEMS

## Product problems

1. Founder dashboard is not connected to live school data.
2. Founder dashboard is publicly accessible without authentication.
3. Access request form does not send or persist to the server.
4. No real account onboarding exists.
5. No invitation acceptance exists.
6. No parent workflow exists.
7. No communication workflow exists.
8. No finance or payment workflow exists.
9. No grades or academic records exist.
10. No institution creation workflow exists.
11. No institution lifecycle exists.
12. No production request-routing workflow exists.

## Authentication and authorization problems

1. Anyone can select Principal.
2. Anyone can select Teacher.
3. There is no identity verification.
4. There is no password recovery.
5. There is no invitation-based account linking.
6. The Administrator option is not a working role.
7. Founder access is not protected.
8. Server-side session expiration is not explicitly enforced.
9. Sessions are lost on restart.
10. The hardcoded session-secret fallback is unsafe.
11. No rate limiting exists.
12. No failed-login monitoring exists.

## Data and persistence problems

1. No database exists.
2. All records are held in one JSON file.
3. There are no explicit tenant IDs.
4. The data file is ignored by Git.
5. There is no backup process.
6. There is no recovery process.
7. Writes are not transactional.
8. Concurrent writes can overwrite each other.
9. Multiple application instances would not share reliable state.
10. There are no migrations.
11. There is no schema validation on startup.
12. There is no data retention policy.
13. There is no data deletion workflow.
14. There is no data export workflow.
15. Student/user/class foreign keys are not consistently validated.

## Attendance problems

1. Offline queue uses `localStorage`, not durable structured storage.
2. The whole application is not offline-capable.
3. Any save failure is treated as an offline condition.
4. Authentication failures could be queued as if they were offline.
5. Validation failures could be queued as if they were offline.
6. A successful server write followed by a lost response can result in a retry audit event.
7. Attendance date format is not validated server-side.
8. Principal attendance submissions with an invalid class can return success with zero saved records.
9. Duplicate records in a single submitted batch are not explicitly rejected.
10. There is no attendance correction history beyond the last updated record.
11. There is no attendance reporting or trend analysis.
12. There are no automated attendance notifications.

## Invitation and staff problems

1. Invitations are not delivered.
2. Invitations cannot be accepted.
3. Invitations do not create users.
4. Invitation codes do not expire.
5. Invitation codes cannot be revoked.
6. There is no invite acceptance audit event.
7. The generated code is displayed directly in the Principal workspace.
8. The requested role is not connected to a real account.
9. Teacher assignment updates do not exist.
10. The user-side `classIds` field is not kept synchronized with class-side `teacherIds`.

## Founder dashboard problems

1. Metrics are hardcoded.
2. Date labels are hardcoded.
3. Health score is hardcoded.
4. Signal count is hardcoded.
5. Institution count is hardcoded.
6. Activity records are hardcoded.
7. Search button has no behavior.
8. Notification button has no behavior.
9. Add institution button has no behavior.
10. Review signal buttons have no behavior.
11. Date filters have no behavior.
12. System health button has no behavior.
13. Access model button has no behavior.
14. Workspace settings button has no behavior.
15. Founder refresh only changes a text label.
16. No Founder API or persistence layer exists.

## API and validation problems

1. No shared request schemas.
2. No consistent API error model.
3. No API versioning.
4. No health endpoint.
5. No rate limiting.
6. No request IDs.
7. No structured logging.
8. No audit events for failed authorization attempts.
9. Server email validation is minimal.
10. Teacher IDs are not verified when creating classes.
11. Student IDs are not checked for uniqueness.
12. Class names are not checked for duplicates.
13. Date values are not validated.
14. The server uses a broad catch around API handling and returns HTTP `400` for unexpected errors.
15. `Content-Type` is not explicitly enforced before parsing all request bodies.

## Testing and quality problems

1. No unit tests.
2. No integration tests.
3. No browser end-to-end tests.
4. No permission regression tests.
5. No offline behavior tests.
6. No persistence/restart tests.
7. No concurrent-write tests.
8. No deployment smoke test script.
9. No schema validation test.
10. No security scanning evidence.
11. No linting or formatting configuration.
12. No CI pipeline.

---

# 10. RECOMMENDED NEXT STEPS

## P0 — Blocks the product

### P0.1 Replace demo role selection with real authentication

Required before real schools use the system.

Includes:

- Real account identity
- Secure sign-in
- Password recovery or passwordless authentication
- Invitation acceptance
- Session expiration
- Secure session storage
- No hardcoded secret fallback

### P0.2 Protect the Founder layer

The Founder command center must not be publicly accessible.

Includes:

- Founder authentication
- Founder-specific authorization
- Founder audit logging
- Clear separation between live school operations and Founder oversight
- Access review and revocation

### P0.3 Replace JSON persistence before multi-school use

The current JSON file is acceptable only as a demo bridge.

Required:

- Relational database
- Migrations
- Explicit tenant IDs
- Foreign keys
- Transaction-safe writes
- Concurrent-write handling
- Backups and recovery

### P0.4 Prevent silent data loss in attendance

Attendance failure modes must distinguish:

- Offline connectivity
- Authentication failure
- Permission failure
- Validation failure
- Server failure

Only genuine connectivity failures should enter the offline queue.

## P1 — Required for MVP

### P1.1 Complete staff and invitation lifecycle

Build:

- Invitation delivery
- Acceptance
- Expiry
- Revocation
- User creation
- Role assignment
- Teacher assignment editing
- User activation/deactivation

### P1.2 Complete core school record management

Add:

- Edit student
- Delete/archive student
- Edit class
- Archive class
- Reassign teachers
- Validate identifiers
- Maintain relationships consistently

### P1.3 Add automated coverage for critical workflows

Test:

- Authentication
- Principal permissions
- Teacher permissions
- Assigned-class isolation
- Attendance saves
- Attendance updates
- Offline queue
- Reconnect retry
- Logout
- Session expiration
- Invalid inputs
- Persistence across restart

### P1.4 Add operational monitoring

Add:

- Health endpoint
- Structured logs
- Error tracking
- Security-event logging
- Request IDs
- Deployment smoke checks

### P1.5 Connect access requests to a real workflow

The request form should:

- Send to a secure backend
- Validate and rate-limit submissions
- Store requests
- Notify an approved team
- Avoid treating browser-local storage as the source of truth

## P2 — Important improvement

### P2.1 Connect Founder metrics to real data

Replace hardcoded metrics with live queries for:

- Institutions
- Users
- Attendance
- Invitations
- System health
- Activity
- Usage

### P2.2 Add parent and guardian access

Only after tenant boundaries, data ownership, privacy rules, retention policies, consent requirements, and access controls are defined.

### P2.3 Add school configuration

Implement the existing `/api/school` capability in the UI:

- School name
- Location
- Academic term
- Configuration history
- Permission checks
- Audit events

### P2.4 Improve offline support

Consider:

- IndexedDB
- Cached application shell
- Service worker
- Conflict resolution
- Explicit sync state
- Retry classification
- Recovery UI

### P2.5 Add attendance reporting

Useful additions:

- Daily summaries
- Class trends
- Absence patterns
- Late-arrival trends
- Export
- Principal review workflow
- Connected signals based on real thresholds

## P3 — Future

### P3.1 Communications

- Staff announcements
- Parent notifications
- Attendance alerts
- Message history

### P3.2 Academic workflows

- Grades
- Assessments
- Assignments
- Progress tracking

### P3.3 Financial workflows

- Fees
- Payments
- Receipts
- Financial reporting

### P3.4 Multi-region and operational scale

- Queue-based processing
- Horizontal scaling
- Regional storage considerations
- Disaster recovery
- Advanced observability
- Audit retention policies

### P3.5 Full PWA support

- Installable app
- Cached shell
- Offline-first navigation
- Background synchronization
- Push notifications

---

# A. WHAT ACTUALLY EXISTS

- A working dependency-free Node web application.
- A polished public SchVIA marketing page.
- A static Founder dashboard concept.
- A working Principal/Teacher school workspace.
- Demo role-based sessions.
- Server-side Principal/Teacher permission checks.
- One locally persisted school.
- Two seeded users.
- Two classes.
- Five students.
- Student enrollment.
- Class creation.
- Staff invitation record creation.
- Attendance recording.
- Four attendance statuses.
- Local offline attendance queue.
- Basic audit events.
- Responsive desktop/mobile styling.
- Replit workflow running `node serve.mjs`.

# B. WHAT IS MISSING

- Real authentication.
- Secure Founder access.
- Invitation acceptance.
- Account lifecycle.
- Password recovery.
- Administrator role.
- Parent access.
- Communications.
- Grading.
- Payments and finance.
- Email delivery.
- Real access-request routing.
- Live Founder oversight.
- Database.
- Multi-tenant schema.
- Backups.
- Monitoring.
- Health checks.
- Automated tests.
- Full PWA/offline support.
- Student/class/user editing and deletion.
- Teacher reassignment.
- Attendance reporting.

# C. WHAT IS BROKEN OR UNSAFE

- Founder command center is publicly accessible.
- Anyone can enter as Principal or Teacher.
- The hardcoded session-secret fallback is unsafe.
- Sessions are in-memory and disappear on restart.
- JSON persistence is not safe for production or concurrent use.
- There is no tenant isolation.
- Invitations cannot be accepted.
- The Administrator role is not operational.
- Founder metrics do not represent live data.
- Most Founder controls are inert.
- Access requests never leave the browser.
- Any attendance save error can be misclassified as offline.
- Offline support does not include the application shell.
- Class teacher IDs are not fully validated or synchronized.
- There is no test suite to protect critical permissions and attendance behavior.

# D. WHAT SHOULD BE BUILT NEXT

1. Real authentication and invitation/account lifecycle.
2. Secure Founder authentication and live oversight authorization.
3. Relational, tenant-aware persistence with migrations and backups.
4. Correct attendance error handling and robust offline synchronization.
5. Automated tests for authorization, attendance, persistence, and offline behavior.
6. Complete school administration workflows.
7. Live Founder metrics, activity, signals, health, and security monitoring.
8. Parent, communication, grading, and finance modules only after the core security/data foundation is production-ready.
