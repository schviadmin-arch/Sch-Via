const marketingView = document.querySelector("#marketing-view");
const dashboardView = document.querySelector("#dashboard-view");
const requestModal = document.querySelector("#request-modal");
const workspaceModal = document.querySelector("#workspace-modal");
const requestForm = document.querySelector("#access-form");
const formSuccess = document.querySelector("#form-success");
const pilotView = document.querySelector("#pilot-view");
let pilotState = null;
let pilotRole = "principal";
let pilotPanel = "overview";
let authMode = "signin";
let pendingAttendance = JSON.parse(localStorage.getItem("schvia_attendance_queue") || "[]");
let pilotLastUpdated = null;

function showDashboard() {
  closeWorkspace();
  pilotView.classList.add("hidden");
  marketingView.classList.add("hidden");
  dashboardView.classList.remove("hidden");
  document.body.classList.add("dashboard-mode");
  window.scrollTo({ top: 0, behavior: "smooth" });
  history.replaceState(null, "", "#dashboard");
  updateFounderRefreshLabel();
}

function showMarketing() {
  pilotView.classList.add("hidden");
  dashboardView.classList.add("hidden");
  marketingView.classList.remove("hidden");
  document.body.classList.remove("dashboard-mode");
  window.scrollTo({ top: 0, behavior: "smooth" });
  history.replaceState(null, "", "#home");
}

async function showPilot() {
  closeWorkspace();
  marketingView.classList.add("hidden");
  dashboardView.classList.add("hidden");
  pilotView.classList.remove("hidden");
  document.body.classList.add("dashboard-mode");
  history.replaceState(null, "", "#pilot");
  renderPilot();
  try {
    await loadPilotState();
    pilotLastUpdated = new Date();
    renderPilot();
  } catch {
    // A signed-out visitor should see the login screen, not an error page.
  }
}

function openRequest() {
  requestForm.reset();
  requestForm.classList.remove("hidden");
  formSuccess.classList.add("hidden");
  requestModal.classList.remove("hidden");
  document.body.style.overflow = "hidden";
  window.setTimeout(() => requestModal.querySelector("input")?.focus(), 50);
}

function closeRequest() {
  requestModal.classList.add("hidden");
  document.body.style.overflow = "";
}

function openWorkspace() {
  workspaceModal.classList.remove("hidden");
  document.body.style.overflow = "hidden";
  window.setTimeout(() => workspaceModal.querySelector(".workspace-option")?.focus(), 50);
}

function closeWorkspace() {
  workspaceModal.classList.add("hidden");
  if (requestModal.classList.contains("hidden")) document.body.style.overflow = "";
}

function updateFounderRefreshLabel() {
  const refresh = document.querySelector('[data-action="refresh-founder"]');
  if (!refresh) return;
  const now = new Intl.DateTimeFormat("en-GB", { hour: "2-digit", minute: "2-digit" }).format(new Date());
  refresh.textContent = `Preview refreshed ${now}`;
}

document.addEventListener("click", (event) => {
  const actionTarget = event.target.closest("[data-action]");
  if (actionTarget) {
    const action = actionTarget.dataset.action;
    if (action === "show-dashboard") showDashboard();
    if (action === "open-pilot") showPilot();
    if (action === "back-home") showMarketing();
    if (action === "open-workspace") openWorkspace();
    if (action === "close-workspace") closeWorkspace();
    if (action === "refresh-founder") updateFounderRefreshLabel();
    if (action === "open-request") { closeWorkspace(); openRequest(); }
    if (action === "close-request") closeRequest();
    if (action === "toggle-menu") {
      const nav = document.querySelector(".desktop-nav");
      const isOpen = nav.classList.toggle("mobile-open");
      actionTarget.setAttribute("aria-expanded", String(isOpen));
    }
  }

  const navItem = event.target.closest(".dash-nav-item[data-panel]");
  if (navItem) {
    document.querySelectorAll(".dash-nav-item[data-panel]").forEach((item) => item.classList.remove("active"));
    document.querySelectorAll("[data-content]").forEach((panel) => panel.classList.add("hidden"));
    navItem.classList.add("active");
    document.querySelector(`[data-content="${navItem.dataset.panel}"]`)?.classList.remove("hidden");
    document.querySelector(".dashboard-content")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  if (event.target === requestModal) closeRequest();
  if (event.target === workspaceModal) closeWorkspace();
});

requestForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const formData = new FormData(requestForm);
  localStorage.setItem("schvia_access_request", JSON.stringify(Object.fromEntries(formData)));
  requestForm.classList.add("hidden");
  formSuccess.classList.remove("hidden");
});

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, {
      ...options,
      headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    });
  } catch (error) {
    error.retryable = true;
    throw error;
  }
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(payload.error || "Something went wrong");
    error.status = response.status;
    error.requestId = payload.requestId || response.headers.get("X-Request-Id");
    error.retryable = response.status >= 500 || response.status === 408 || response.status === 429;
    throw error;
  }
  return payload;
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" }[character]));
}

function className(id) {
  return pilotState.classes.find((item) => item.id === id)?.name || "Unassigned";
}

function formatDate(value) {
  return new Intl.DateTimeFormat("en-GB", { day: "numeric", month: "short", year: "numeric" }).format(new Date(`${value}T12:00:00`));
}

function persistQueue() {
  localStorage.setItem("schvia_attendance_queue", JSON.stringify(pendingAttendance));
}

async function loadPilotState() {
  pilotState = await api("/api/state");
  await syncPendingAttendance();
}

async function syncPendingAttendance() {
  if (!pendingAttendance.length || !navigator.onLine) return;
  const remaining = [];
  for (const item of pendingAttendance) {
    try {
      await api("/api/attendance", { method: "POST", body: JSON.stringify(item) });
    } catch (error) {
      if (error.retryable) {
        remaining.push(item);
      } else if (pilotState) {
        pilotState.syncError = error.message;
      }
    }
  }
  pendingAttendance = remaining;
  persistQueue();
  if (pilotState && remaining.length === 0) pilotState = await api("/api/state");
}

function pilotShell(content, active = pilotPanel) {
  const user = pilotState?.currentUser;
  const isPrincipal = ["principal", "admin"].includes(user?.role);
  const nav = [
    ["overview", "Overview", "⌂"],
    ["attendance", "Attendance", "◷"],
    ["students", "Students", "◌"],
    ...(isPrincipal ? [["staff", "Staff & classes", "⊙"], ["audit", "Activity log", "↝"], ["settings", "School settings", "⚙"]] : []),
  ];
  const updatedLabel = pilotLastUpdated ? `Updated ${new Intl.DateTimeFormat("en-GB", { hour: "2-digit", minute: "2-digit" }).format(pilotLastUpdated)}` : "Live school workspace";
  return `<div class="pilot-notice"><span class="pulse-dot"></span> Working school workspace <span class="notice-divider"></span> ${navigator.onLine ? `${updatedLabel} · connected` : "Offline — attendance changes stay on this device"} <button data-pilot-action="refresh">Refresh</button><button data-pilot-action="logout">Sign out</button></div>
    <div class="pilot-layout">
      <aside class="pilot-sidebar"><div class="pilot-brand"><span class="brand-mark"><span></span><span></span><span></span></span><strong>Sch<span>VIA</span></strong></div>
        <div class="pilot-school"><span class="workspace-avatar">${escapeHtml((pilotState.school.name || "S")[0])}</span><div><small>School workspace</small><strong>${escapeHtml(pilotState.school.name)}</strong></div></div>
        <nav class="pilot-nav">${nav.map(([id, label, icon]) => `<button class="${active === id ? "active" : ""}" data-pilot-panel="${id}"><span>${icon}</span>${label}</button>`).join("")}</nav>
        <div class="pilot-user"><span class="profile-avatar">${escapeHtml(user.name.split(" ").map((part) => part[0]).join("").slice(0, 2))}</span><div><strong>${escapeHtml(user.name)}</strong><small>${escapeHtml(user.role)}</small></div></div>
      </aside><section class="pilot-main">${content}</section>
    </div>`;
}

function renderLogin(error = "") {
  const form = authMode === "register"
    ? `<form class="auth-form" id="register-form"><label>Your name<input name="name" placeholder="Amara Mensah" autocomplete="name" required /></label><label>School name<input name="schoolName" placeholder="Northbridge School" required /></label><label>Work email<input name="email" type="email" placeholder="you@school.org" autocomplete="email" required /></label><label>Create password<input name="password" type="password" minlength="8" placeholder="At least 8 characters" autocomplete="new-password" required /></label><label>Location <span class="optional-label">optional</span><input name="location" placeholder="City, country" /></label><button class="button button-primary auth-submit" type="submit">Create school workspace <span>→</span></button></form>`
    : authMode === "invite"
      ? `<form class="auth-form" id="invite-accept-form"><label>Invitation code<input name="code" placeholder="AB12CD34" autocomplete="one-time-code" required /></label><label>Your name<input name="name" placeholder="Kofi Owusu" autocomplete="name" required /></label><label>Your email<input name="email" type="email" placeholder="you@school.org" autocomplete="email" required /></label><label>Create password<input name="password" type="password" minlength="8" placeholder="At least 8 characters" autocomplete="new-password" required /></label><button class="button button-primary auth-submit" type="submit">Join school workspace <span>→</span></button></form>`
      : `<form class="auth-form" id="login-email-form"><label>Work email<input name="email" type="email" placeholder="you@school.org" autocomplete="email" required /></label><label>Password<input name="password" type="password" placeholder="Your password" autocomplete="current-password" required /></label><button class="button button-primary auth-submit" type="submit">Sign in to workspace <span>→</span></button></form>`;
  pilotView.innerHTML = `<div class="pilot-login"><div class="pilot-login-card"><div class="pilot-brand centered-brand"><span class="brand-mark"><span></span><span></span><span></span></span><strong>Sch<span>VIA</span></strong></div><span class="eyebrow">School workspace</span><h1>${authMode === "register" ? "Set up your<br /><em>school workspace.</em>" : authMode === "invite" ? "Join your<br /><em>school team.</em>" : "Welcome back<br /><em>to the work.</em>"}</h1><p>${authMode === "register" ? "Create the school workspace and become its first administrator." : authMode === "invite" ? "Use the code from your school administrator to create your staff account." : "Sign in with your school account, or use the preview access below."}</p><div class="auth-tabs"><button class="${authMode === "signin" ? "active" : ""}" data-auth-mode="signin">Sign in</button><button class="${authMode === "register" ? "active" : ""}" data-auth-mode="register">Create workspace</button><button class="${authMode === "invite" ? "active" : ""}" data-auth-mode="invite">Accept invite</button></div>${error ? `<div class="pilot-error">${escapeHtml(error)}</div>` : ""}${form}<div class="demo-access"><span>Preview only</span><div class="role-choice"><button class="${pilotRole === "principal" ? "selected" : ""}" data-login-role="principal"><strong>Principal demo</strong><small>Explore the seeded school workspace</small></button><button class="${pilotRole === "teacher" ? "selected" : ""}" data-login-role="teacher"><strong>Teacher demo</strong><small>Try assigned-class attendance</small></button></div><button class="button button-quiet demo-button" data-pilot-action="login">Enter demo workspace <span>→</span></button></div><button class="button button-quiet" data-action="back-home">Return to public site</button></div></div>`;
}

function renderPilot() {
  if (!pilotState) return renderLogin();
  const panels = { overview: renderOverview, attendance: renderAttendance, students: renderStudents, staff: renderStaff, audit: renderAudit, settings: renderSettings };
  pilotView.innerHTML = pilotShell((panels[pilotPanel] || renderOverview)(), pilotPanel);
}

function renderOverview() {
  const total = pilotState.students.length;
  const todayRecords = pilotState.attendance.filter((item) => item.date === new Date().toISOString().slice(0, 10));
  const present = todayRecords.filter((item) => item.status === "present").length;
  const pending = pendingAttendance.length;
  return `<header class="pilot-header"><div><span class="status-label">SCHOOL OVERVIEW</span><h1>Good morning, ${escapeHtml(pilotState.currentUser.name.split(" ")[0])}.</h1><p>One clear view of what is happening at ${escapeHtml(pilotState.school.name)}.</p></div><span class="pilot-state-chip ${pending ? "pending" : "good"}">${pending ? `${pending} attendance batch pending` : "All records synced"}</span></header>
    <div class="pilot-grid pilot-metrics"><div class="pilot-metric"><span>Enrolled students</span><strong>${total}</strong><small>Across ${pilotState.classes.length} classes</small></div><div class="pilot-metric"><span>Today's records</span><strong>${todayRecords.length}</strong><small>${present} present so far</small></div><div class="pilot-metric"><span>Staff members</span><strong>${pilotState.users.length}</strong><small>${pilotState.invitations.length} invitation(s) pending</small></div></div>
    <div class="pilot-grid pilot-two-col"><article class="pilot-card"><div class="pilot-card-title"><div><span class="status-label">QUICK START</span><h2>Keep the school moving</h2></div></div><div class="quick-actions"><button data-pilot-panel="attendance"><span>◷</span><strong>Take attendance<small>Record today’s class presence</small></strong>→</button><button data-pilot-panel="students"><span>◌</span><strong>Manage students<small>View the authoritative student list</small></strong>→</button>${pilotState.currentUser.role === "principal" ? `<button data-pilot-panel="staff"><span>⊙</span><strong>Invite staff<small>Assign responsibility with boundaries</small></strong>→</button>` : ""}</div></article><article class="pilot-card"><div class="pilot-card-title"><div><span class="status-label">RECENT ACTIVITY</span><h2>A record you can trust</h2></div></div><div class="pilot-activity">${(pilotState.audit.slice(0, 4).map((item) => `<div><i></i><p><strong>${escapeHtml(item.action)}</strong><small>${escapeHtml(item.detail)} · ${new Intl.DateTimeFormat("en-GB", { hour: "2-digit", minute: "2-digit" }).format(new Date(item.at))}</small></p></div>`).join("") || "<p class='pilot-empty'>Activity will appear here as your team works.</p>")}</div></article></div>`;
}

function renderStudents() {
  const canManage = ["principal", "admin"].includes(pilotState.currentUser.role);
  return `<header class="pilot-header"><div><span class="status-label">STUDENT RECORDS</span><h1>One authoritative list.</h1><p>Students, classes, and guardian context in one place.</p></div>${canManage ? `<button class="button button-primary" data-pilot-action="open-student">Add student <span>+</span></button>` : ""}</header><div class="pilot-card"><div class="pilot-table-head"><span>Student</span><span>Student ID</span><span>Class</span><span>Guardian</span><span>Status</span></div>${pilotState.students.map((student) => `<div class="pilot-table-row"><span><b class="student-avatar">${escapeHtml(student.name.split(" ").map((part) => part[0]).join("").slice(0, 2))}</b><strong>${escapeHtml(student.name)}<small>${escapeHtml(student.gender)}</small></strong></span><span>${escapeHtml(student.studentId)}</span><span>${escapeHtml(className(student.classId))}</span><span>${escapeHtml(student.guardian)}</span><span class="pilot-good">${escapeHtml(student.status)}</span></div>`).join("")}</div>${canManage ? `<div id="student-form-slot"></div>` : ""}`;
}

function renderStaff() {
  return `<header class="pilot-header"><div><span class="status-label">PEOPLE & RESPONSIBILITIES</span><h1>Authority with boundaries.</h1><p>Invite the people who keep the school moving.</p></div><button class="button button-primary" data-pilot-action="open-invite">Invite staff <span>+</span></button></header><div class="pilot-grid pilot-two-col"><article class="pilot-card"><div class="pilot-card-title"><div><span class="status-label">STAFF</span><h2>${pilotState.users.length} active people</h2></div></div>${pilotState.users.map((user) => `<div class="staff-row"><span class="profile-avatar">${escapeHtml(user.name.split(" ").map((part) => part[0]).join("").slice(0, 2))}</span><div><strong>${escapeHtml(user.name)}</strong><small>${escapeHtml(user.email)}</small></div><span class="role-badge">${escapeHtml(user.role)}</span></div>`).join("")}${pilotState.invitations.map((invite) => `<div class="staff-row pending-row"><span class="profile-avatar">?</span><div><strong>${escapeHtml(invite.name)}</strong><small>${escapeHtml(invite.email)} · code ${escapeHtml(invite.code)}</small></div><span class="role-badge pending-role">invited</span></div>`).join("")}</article><article class="pilot-card"><div class="pilot-card-title"><div><span class="status-label">CLASSES</span><h2>Assigned learning groups</h2></div><button class="icon-button" data-pilot-action="open-class" aria-label="Add class">+</button></div>${pilotState.classes.map((item) => `<div class="staff-row"><span class="class-icon">▦</span><div><strong>${escapeHtml(item.name)}</strong><small>${pilotState.students.filter((student) => student.classId === item.id).length} enrolled · ${item.teacherIds.length ? escapeHtml(pilotState.users.find((user) => user.id === item.teacherIds[0])?.name || "Assigned") : "No teacher assigned"}</small></div></div>`).join("")}</article></div><div id="staff-form-slot"></div>`;
}

function renderAudit() {
  return `<header class="pilot-header"><div><span class="status-label">AUDITABILITY</span><h1>A record you can trust.</h1><p>Important actions carry who, what, when, and why.</p></div></header><div class="pilot-card pilot-audit-list">${pilotState.audit.length ? pilotState.audit.map((item) => `<div class="pilot-audit-row"><time>${new Intl.DateTimeFormat("en-GB", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }).format(new Date(item.at))}</time><i></i><div><strong>${escapeHtml(item.action)}</strong><small>${escapeHtml(item.detail)} · ${escapeHtml(item.actorName)}</small></div></div>`).join("") : "<p class='pilot-empty'>No activity yet.</p>"}</div>`;
}

function renderSettings() {
  if (!["principal", "admin"].includes(pilotState.currentUser.role)) return renderOverview();
  return `<header class="pilot-header"><div><span class="status-label">SCHOOL CONFIGURATION</span><h1>Make the workspace yours.</h1><p>Keep the school identity and academic context current for everyone working here.</p></div></header>
    <form class="pilot-card pilot-settings-form" id="school-settings-form">
      <div class="pilot-card-title"><div><span class="status-label">WORKSPACE DETAILS</span><h2>School information</h2></div></div>
      <label>School name<input name="name" value="${escapeHtml(pilotState.school.name)}" required maxlength="120" /></label>
      <label>Location<input name="location" value="${escapeHtml(pilotState.school.location)}" maxlength="120" placeholder="City, country" /></label>
      <label>Academic term<input name="term" value="${escapeHtml(pilotState.school.term)}" maxlength="80" placeholder="2026 / 27 academic year" /></label>
      <div class="settings-form-actions"><p id="settings-feedback" class="form-feedback" role="status"></p><button class="button button-primary" type="submit">Save school settings <span>→</span></button></div>
    </form>`;
}

function renderAttendance() {
  const teacherClasses = pilotState.classes;
  const selectedClass = pilotState.selectedClassId && teacherClasses.some((item) => item.id === pilotState.selectedClassId) ? pilotState.selectedClassId : teacherClasses[0]?.id;
  pilotState.selectedClassId = selectedClass;
  const date = pilotState.attendanceDate || new Date().toISOString().slice(0, 10);
  const students = pilotState.students.filter((item) => item.classId === selectedClass);
  const existing = Object.fromEntries(pilotState.attendance.filter((item) => item.date === date && item.classId === selectedClass).map((item) => [item.studentId, item.status]));
  return `<header class="pilot-header"><div><span class="status-label">TEACHER WORKSPACE</span><h1>Attendance, without friction.</h1><p>Mark the room once. SchVIA keeps the record safe, even when the connection drops.</p></div><span class="pilot-state-chip ${navigator.onLine ? "good" : "pending"}">${navigator.onLine ? "Connected" : "Offline mode"}</span></header><div class="attendance-toolbar"><label>Class<select id="attendance-class">${teacherClasses.map((item) => `<option value="${item.id}" ${item.id === selectedClass ? "selected" : ""}>${escapeHtml(item.name)}</option>`).join("")}</select></label><label>Date<input id="attendance-date" type="date" value="${date}" /></label><span class="attendance-count" id="attendance-count">${students.length} students</span></div><div class="pilot-card attendance-card"><div class="attendance-head"><span>Student</span><span>Status</span></div>${students.map((student) => { const status = existing[student.id] || "present"; return `<div class="attendance-row" data-student="${student.id}"><div><b class="student-avatar">${escapeHtml(student.name.split(" ").map((part) => part[0]).join("").slice(0, 2))}</b><strong>${escapeHtml(student.name)}<small>${escapeHtml(student.studentId)}</small></strong></div><div class="status-buttons">${["present", "absent", "late", "excused"].map((choice) => `<button class="${status === choice ? `selected ${choice}` : ""}" data-attendance-status="${choice}">${choice}</button>`).join("")}</div></div>`; }).join("") || "<p class='pilot-empty'>No students are assigned to this class yet.</p>"}</div>${students.length ? `<div class="attendance-footer"><p id="attendance-feedback">${pendingAttendance.length ? `${pendingAttendance.length} offline batch(es) waiting to sync.` : "Ready to record today's attendance."}</p><button class="button button-primary" data-pilot-action="save-attendance">Save attendance <span>→</span></button></div>` : ""}`;
}

function showPilotForm(type) {
  const slot = document.querySelector(type === "student" ? "#student-form-slot" : "#staff-form-slot");
  if (!slot) return;
  if (type === "student") {
    slot.innerHTML = `<form class="pilot-inline-form" id="student-form"><h3>Add a student</h3><input name="name" placeholder="Student full name" required /><input name="studentId" placeholder="Student ID (optional)" /><select name="classId">${pilotState.classes.map((item) => `<option value="${item.id}">${escapeHtml(item.name)}</option>`).join("")}</select><input name="guardian" placeholder="Guardian name (optional)" /><button class="button button-primary">Save student</button></form>`;
  } else if (type === "class") {
    slot.innerHTML = `<form class="pilot-inline-form" id="class-form"><h3>Add a class</h3><input name="name" placeholder="Class name (e.g. Primary 4)" required /><input name="year" placeholder="Academic year" value="${escapeHtml(pilotState.school.term)}" /><select name="teacherId"><option value="">Assign teacher later</option>${pilotState.users.filter((user) => user.role === "teacher").map((user) => `<option value="${user.id}">${escapeHtml(user.name)}</option>`).join("")}</select><button class="button button-primary">Save class</button></form>`;
  } else {
    slot.innerHTML = `<form class="pilot-inline-form" id="invite-form"><h3>Invite a staff member</h3><input name="name" placeholder="Full name" required /><input name="email" type="email" placeholder="Work email" required /><select name="role"><option value="teacher">Teacher</option><option value="admin">Administrator</option></select><button class="button button-primary">Create invitation</button></form>`;
  }
  slot.querySelector("input")?.focus();
}

async function saveAttendance() {
  const classId = document.querySelector("#attendance-class").value;
  const date = document.querySelector("#attendance-date").value;
  const records = [...document.querySelectorAll(".attendance-row")].map((row) => ({ studentId: row.dataset.student, status: row.querySelector(".selected")?.dataset.attendanceStatus || "present" }));
  const batch = { classId, date, records };
  try {
    if (!navigator.onLine) {
      const error = new Error("offline");
      error.retryable = true;
      throw error;
    }
    pilotState = await api("/api/attendance", { method: "POST", body: JSON.stringify(batch) });
    document.querySelector("#attendance-feedback").textContent = `Saved ${records.length} records and synced to the school workspace.`;
  } catch (error) {
    if (!error.retryable) {
      document.querySelector("#attendance-feedback").textContent = `${error.message}${error.requestId ? ` (Request ${error.requestId})` : ""}`;
      return;
    }
    pendingAttendance = pendingAttendance.filter((item) => !(item.classId === classId && item.date === date));
    pendingAttendance.push(batch);
    persistQueue();
    document.querySelector("#attendance-feedback").textContent = `Saved on this device. ${records.length} records will sync automatically when connected.`;
  }
}

document.addEventListener("click", async (event) => {
  const authModeButton = event.target.closest("[data-auth-mode]");
  if (authModeButton) { authMode = authModeButton.dataset.authMode; renderLogin(); return; }
  const roleButton = event.target.closest("[data-login-role]");
  if (roleButton) { pilotRole = roleButton.dataset.loginRole; renderLogin(); return; }
  const panelButton = event.target.closest("[data-pilot-panel]");
  if (panelButton) { pilotPanel = panelButton.dataset.pilotPanel; renderPilot(); return; }
  const statusButton = event.target.closest("[data-attendance-status]");
  if (statusButton) { statusButton.closest(".status-buttons").querySelectorAll("button").forEach((button) => button.classList.remove("selected", "present", "absent", "late", "excused")); statusButton.classList.add("selected", statusButton.dataset.attendanceStatus); return; }
  const action = event.target.closest("[data-pilot-action]")?.dataset.pilotAction;
  if (!action) return;
  if (action === "login") { try { await api("/api/auth/login", { method: "POST", body: JSON.stringify({ role: pilotRole }) }); await loadPilotState(); pilotLastUpdated = new Date(); renderPilot(); } catch (error) { renderLogin(error.message); } }
  if (action === "refresh") { try { await loadPilotState(); pilotLastUpdated = new Date(); renderPilot(); } catch (error) { renderLogin(error.message); } }
  if (action === "logout") { await api("/api/auth/logout", { method: "POST" }); pilotState = null; pilotLastUpdated = null; showPilot(); }
  if (action === "open-student") showPilotForm("student");
  if (action === "open-invite") showPilotForm("invite");
  if (action === "open-class") showPilotForm("class");
  if (action === "save-attendance") await saveAttendance();
});

document.addEventListener("change", (event) => {
  if (event.target.id === "attendance-class" || event.target.id === "attendance-date") { pilotState.selectedClassId = document.querySelector("#attendance-class").value; pilotState.attendanceDate = document.querySelector("#attendance-date").value; renderPilot(); }
});

document.addEventListener("submit", async (event) => {
  if (["login-email-form", "register-form", "invite-accept-form"].includes(event.target.id)) {
    event.preventDefault();
    const endpoint = event.target.id === "login-email-form" ? "/api/auth/login-email" : event.target.id === "register-form" ? "/api/auth/register" : "/api/auth/accept-invite";
    const button = event.target.querySelector("button[type='submit']");
    button.disabled = true;
    try {
      await api(endpoint, { method: "POST", body: JSON.stringify(Object.fromEntries(new FormData(event.target))) });
      await loadPilotState();
      pilotLastUpdated = new Date();
      pilotPanel = "overview";
      renderPilot();
    } catch (error) {
      renderLogin(`${error.message}${error.requestId ? ` (Request ${error.requestId})` : ""}`);
    }
    return;
  }
  if (event.target.id === "school-settings-form") {
    event.preventDefault();
    const feedback = event.target.querySelector("#settings-feedback");
    const button = event.target.querySelector("button[type='submit']");
    button.disabled = true;
    feedback.textContent = "Saving…";
    try {
      pilotState = await api("/api/school", { method: "POST", body: JSON.stringify(Object.fromEntries(new FormData(event.target))) });
      pilotLastUpdated = new Date();
      renderPilot();
    } catch (error) {
      feedback.textContent = `${error.message}${error.requestId ? ` (Request ${error.requestId})` : ""}`;
      button.disabled = false;
    }
    return;
  }
  if (["student-form", "invite-form", "class-form"].includes(event.target.id)) {
    event.preventDefault();
    const form = new FormData(event.target);
    const endpoint = event.target.id === "student-form" ? "/api/students" : event.target.id === "invite-form" ? "/api/users" : "/api/classes";
    try { pilotState = await api(endpoint, { method: "POST", body: JSON.stringify(Object.fromEntries(form)) }); renderPilot(); } catch (error) { event.target.insertAdjacentHTML("beforeend", `<p class="pilot-error">${escapeHtml(error.message)}</p>`); }
  }
});

window.addEventListener("online", async () => { await syncPendingAttendance(); if (pilotState) { pilotState = await api("/api/state"); pilotLastUpdated = new Date(); renderPilot(); } });
window.addEventListener("focus", async () => {
  if (pilotState && window.location.hash === "#pilot") {
    try { pilotState = await api("/api/state"); pilotLastUpdated = new Date(); renderPilot(); } catch { /* session may have expired */ }
  }
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !requestModal.classList.contains("hidden")) closeRequest();
  if (event.key === "Escape" && !workspaceModal.classList.contains("hidden")) closeWorkspace();
});

window.addEventListener("hashchange", () => {
  if (window.location.hash === "#dashboard") showDashboard();
  if (window.location.hash === "#pilot") showPilot();
  if (!window.location.hash || window.location.hash === "#home") showMarketing();
});

if (window.location.hash === "#dashboard") showDashboard();
if (window.location.hash === "#pilot") showPilot();