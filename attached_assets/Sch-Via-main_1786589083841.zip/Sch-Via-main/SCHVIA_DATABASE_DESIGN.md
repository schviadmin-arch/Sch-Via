# SchVIA Relational Database Design

## 1. Database technology recommendation

Recommended primary database: PostgreSQL.

Reasons:
- Strong support for multi-tenant applications, row-level security, and schema evolution.
- Reliable concurrency model for write-heavy school workflows.
- Native support for JSONB for audit/metadata fields and migration flexibility.
- Mature migration tooling and hosting options on Supabase, Neon, Railway, AWS RDS, Azure Database for PostgreSQL.
- Better long-term production scalability than SQLite for multiple simultaneous users and backup/restore.

Recommended local development fallback: SQLite.
- Good for simple local testing and prototype runs.
- Use only for development/test, not production, because file locking and concurrency are weak for multi-user school workloads.

## 2. Entity list

The relational design is derived from the current JSON store and the server’s runtime model.

Current entities:
- schools
- users
- memberships
- classes
- students
- attendance
- invitations
- audit

Future/required entities:
- platform-level users and roles
- user credentials and sessions
- platform roles / platform operators / founders
- academic terms / school terms
- subjects and class subject assignments
- assessments and assessment results
- report cards and report card entries
- class-teacher assignments
- student class assignment history
- guardians / parent contacts
- attendance events and records
- invitation lifecycle details
- audit metadata

## 3. Table-by-table schema

### 3.1 `users`

Represents global identity records for people and platform actors.

Columns:
- `id UUID PRIMARY KEY`
- `email TEXT NOT NULL UNIQUE`
- `name TEXT NOT NULL`
- `status TEXT NOT NULL DEFAULT 'active'`
- `created_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- `updated_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- `profile JSONB NULL`

Notes:
- Current JSON stores `users[].role`, but role should be separated from identity.
- Platform administration should use a separate role membership table instead of boolean flags.
- Emails are globally unique in the current implementation.

### 3.2 `platform_memberships`

Represents platform-level administrative and founder relationships.

Columns:
- `id UUID PRIMARY KEY`
- `user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT`
- `role TEXT NOT NULL` -- e.g. `platform_admin`, `founder`, `platform_operator`
- `status TEXT NOT NULL DEFAULT 'active'` -- `active`, `inactive`, `revoked`
- `created_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- `granted_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- `revoked_at TIMESTAMPTZ NULL`

Unique constraints:
- Partial unique index on active platform membership: `UNIQUE (user_id, role) WHERE status = 'active'`

Indexes:
- `idx_platform_memberships_user_id` on `(user_id)`

Notes:
- A user may be a platform administrator/founder and also belong to multiple schools with different roles.
- This model keeps platform-level authorization separate from school membership.

### 3.3 `user_credentials`

Stores authentication secrets separately from identity.

Columns:
- `user_id UUID PRIMARY KEY REFERENCES users(id)`
- `password_hash TEXT NOT NULL`
- `password_algorithm TEXT NOT NULL DEFAULT 'scrypt'`
- `created_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- `updated_at TIMESTAMPTZ NOT NULL DEFAULT now()`

Notes:
- Current JSON stores `passwordHash` directly on the user.
- Future design should preserve credential separation.

### 3.3 `user_sessions`

Tracks active session state for durable sign-in, replacing in-memory session maps.

Columns:
- `id UUID PRIMARY KEY`
- `user_id UUID NOT NULL REFERENCES users(id)`
- `school_id UUID REFERENCES schools(id)`
- `session_token_hash TEXT NOT NULL`
- `created_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- `last_active_at TIMESTAMPTZ NULL`
- `expires_at TIMESTAMPTZ NOT NULL`
- `revoked_at TIMESTAMPTZ NULL`
- `ip_address TEXT NULL`
- `user_agent TEXT NULL`

Indexes:
- `idx_user_sessions_user_id` on `(user_id)`
- `idx_user_sessions_session_token_hash` on `(session_token_hash)`

### 3.4 `schools`

Represents tenant schools and their lifecycle.

Columns:
- `id UUID PRIMARY KEY`
- `name TEXT NOT NULL`
- `location TEXT NULL`
- `status TEXT NOT NULL DEFAULT 'active'`
- `current_term TEXT NULL`
- `created_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- `updated_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- `founder_user_id UUID REFERENCES users(id)`

Unique constraints:
- `UNIQUE (name)` is optional; school names may duplicate across regions.

Notes:
- Current JSON stores a root `school` object and normalizes it into `schools[]`.
- Future schema should make `schools` canonical.

### 3.5 `school_memberships`

Represents school-level relationships between users and schools.

Columns:
- `id UUID PRIMARY KEY`
- `user_id UUID NOT NULL REFERENCES users(id)`
- `school_id UUID NOT NULL REFERENCES schools(id)`
- `role TEXT NOT NULL` -- e.g. `principal`, `admin`, `teacher`, `guardian`
- `status TEXT NOT NULL DEFAULT 'active'` -- e.g. `active`, `pending`, `revoked`, `inactive`
- `created_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- `accepted_at TIMESTAMPTZ NULL`
- `revoked_at TIMESTAMPTZ NULL`
- `ended_at TIMESTAMPTZ NULL`

Unique constraints:
- `UNIQUE (user_id, school_id, status) WHERE status = 'active'` (PostgreSQL partial unique index)

Indexes:
- `idx_memberships_school_id` on `(school_id)`
- `idx_memberships_user_id` on `(user_id)`
- `idx_memberships_role_status` on `(school_id, role, status)`

Notes:
- Current JSON stores roles on both `users` and `memberships`.
- The canonical model separates identity (`users`) from school role membership.

### 3.6 `academic_terms`

Represents school academic year/term structure.

Columns:
- `id UUID PRIMARY KEY`
- `school_id UUID NOT NULL REFERENCES schools(id)`
- `name TEXT NOT NULL`
- `starts_at DATE NULL`
- `ends_at DATE NULL`
- `status TEXT NOT NULL DEFAULT 'active'`
- `created_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- `updated_at TIMESTAMPTZ NOT NULL DEFAULT now()`

Unique constraints:
- `UNIQUE (school_id, name)`

Notes:
- Current model stores `school.term` and `class.year` as text.
- Academic terms should be explicit for reporting and future grade periods.

### `subjects`

Represents academic subjects offered by a school.

Columns:
- `id UUID PRIMARY KEY`
- `school_id UUID NOT NULL REFERENCES schools(id)`
- `name TEXT NOT NULL`
- `code TEXT NULL`
- `description TEXT NULL`
- `status TEXT NOT NULL DEFAULT 'active'`
- `created_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- `updated_at TIMESTAMPTZ NOT NULL DEFAULT now()`

Unique constraints:
- `UNIQUE (school_id, name)`
- `UNIQUE (school_id, code) WHERE code IS NOT NULL`

Indexes:
- `idx_subjects_school_id` on `(school_id)`

Notes:
- Current JSON does not have explicit subject entities.
- Subjects are necessary before assessments, grades, and report cards.

### `class_subjects`

Represents the subjects taught by a class and optionally the responsible teacher.

Columns:
- `id UUID PRIMARY KEY`
- `school_id UUID NOT NULL REFERENCES schools(id)`
- `class_id UUID NOT NULL REFERENCES classes(id)`
- `subject_id UUID NOT NULL REFERENCES subjects(id)`
- `teacher_id UUID REFERENCES users(id)`
- `academic_term_id UUID REFERENCES academic_terms(id)`
- `created_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- `updated_at TIMESTAMPTZ NOT NULL DEFAULT now()`

Unique constraints:
- `UNIQUE (class_id, subject_id, academic_term_id)`

Indexes:
- `idx_class_subjects_class_id` on `(class_id)`
- `idx_class_subjects_subject_id` on `(subject_id)`
- `idx_class_subjects_teacher_id` on `(teacher_id)`

Notes:
- Current JSON stores teacher assignment using a `teacherIds` array without subject context.
- `school_id` should be duplicated to support tenant integrity checks and row-level security.

### `assessments`

Represents academic assessments tied to subjects, classes, and terms.

Columns:
- `id UUID PRIMARY KEY`
- `school_id UUID NOT NULL REFERENCES schools(id)`
- `subject_id UUID NOT NULL REFERENCES subjects(id)`
- `class_id UUID NOT NULL REFERENCES classes(id)`
- `academic_term_id UUID NOT NULL REFERENCES academic_terms(id)`
- `name TEXT NOT NULL`
- `type TEXT NOT NULL` -- e.g. `exam`, `quiz`, `homework`, `project`
- `max_score NUMERIC NULL`
- `date DATE NULL`
- `due_at TIMESTAMPTZ NULL`
- `status TEXT NOT NULL DEFAULT 'active'`
- `created_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- `updated_at TIMESTAMPTZ NOT NULL DEFAULT now()`

Unique constraints:
- `UNIQUE (school_id, class_id, subject_id, name, academic_term_id)`

Indexes:
- `idx_assessments_school_id` on `(school_id)`
- `idx_assessments_class_id` on `(class_id)`
- `idx_assessments_subject_id` on `(subject_id)`

Notes:
- Current JSON has no assessment structure.
- This establishes the foundation for grade records and report cards.

### `assessment_results`

Represents a student’s result for a specific assessment.

Columns:
- `id UUID PRIMARY KEY`
- `school_id UUID NOT NULL REFERENCES schools(id)`
- `assessment_id UUID NOT NULL REFERENCES assessments(id)`
- `student_id UUID NOT NULL REFERENCES students(id)`
- `score NUMERIC NULL`
- `grade TEXT NULL`
- `remarks TEXT NULL`
- `recorded_by UUID REFERENCES users(id)`
- `recorded_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- `updated_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- `status TEXT NOT NULL DEFAULT 'recorded'` -- `recorded`, `published`, `corrected`

Unique constraints:
- `UNIQUE (assessment_id, student_id)`

Indexes:
- `idx_assessment_results_assessment_id` on `(assessment_id)`
- `idx_assessment_results_student_id` on `(student_id)`

Notes:
- This captures student results per assessment and allows later summary into report cards.
- `school_id` should be duplicated to support tenant integrity checks when joining assessment and student records.

### `report_cards`

Represents a student’s academic report for a term or period.

Columns:
- `id UUID PRIMARY KEY`
- `school_id UUID NOT NULL REFERENCES schools(id)`
- `student_id UUID NOT NULL REFERENCES students(id)`
- `academic_term_id UUID NOT NULL REFERENCES academic_terms(id)`
- `issued_at TIMESTAMPTZ NULL`
- `status TEXT NOT NULL DEFAULT 'draft'` -- `draft`, `finalized`
- `comments TEXT NULL`
- `created_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- `updated_at TIMESTAMPTZ NOT NULL DEFAULT now()`

Unique constraints:
- `UNIQUE (school_id, student_id, academic_term_id)`

Indexes:
- `idx_report_cards_school_id` on `(school_id)`
- `idx_report_cards_student_id` on `(student_id)`

Notes:
- Report cards are generated artifacts, not source data.

### `report_card_entries`

Represents subject-level line items on a report card.

Columns:
- `id UUID PRIMARY KEY`
- `report_card_id UUID NOT NULL REFERENCES report_cards(id)`
- `subject_id UUID NOT NULL REFERENCES subjects(id)`
- `assessment_result_summary JSONB NULL`
- `grade TEXT NULL`
- `remarks TEXT NULL`
- `created_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- `updated_at TIMESTAMPTZ NOT NULL DEFAULT now()`

Unique constraints:
- `UNIQUE (report_card_id, subject_id)`

Indexes:
- `idx_report_card_entries_report_card_id` on `(report_card_id)`
- `idx_report_card_entries_subject_id` on `(subject_id)`

Notes:
- Report card entries summarize performance on a per-subject basis.
- The report card row itself carries the tenant `school_id`.

### 3.7 `classes`

Represents class groups within a school.

Columns:
- `id UUID PRIMARY KEY`
- `school_id UUID NOT NULL REFERENCES schools(id)`
- `name TEXT NOT NULL`
- `academic_term_id UUID REFERENCES academic_terms(id)`
- `status TEXT NOT NULL DEFAULT 'active'`
- `created_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- `updated_at TIMESTAMPTZ NOT NULL DEFAULT now()`

Unique constraints:
- `UNIQUE (school_id, name, academic_term_id)`

Indexes:
- `idx_classes_school_id` on `(school_id)`
- `idx_classes_academic_term_id` on `(academic_term_id)`

Notes:
- Current JSON stores `teacherIds` array on classes and `year` text.
- Class name uniqueness must be scoped by school and academic term.

### 3.8 `class_teachers`

Represents teacher assignments to classes.

Columns:
- `id UUID PRIMARY KEY`
- `class_id UUID NOT NULL REFERENCES classes(id)`
- `user_id UUID NOT NULL REFERENCES users(id)`
- `assigned_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- `removed_at TIMESTAMPTZ NULL`

Unique constraints:
- `UNIQUE (class_id, user_id, removed_at) WHERE removed_at IS NULL`

Indexes:
- `idx_class_teachers_class_id` on `(class_id)`
- `idx_class_teachers_user_id` on `(user_id)`

Notes:
- Current JSON stores teacher assignment as a simple ID array.
- This table enables history and safer teacher-scoped access.

### 3.9 `students`

Represents student identities enrolled in schools.

Columns:
- `id UUID PRIMARY KEY`
- `school_id UUID NOT NULL REFERENCES schools(id)`
- `student_number TEXT NOT NULL`
- `name TEXT NOT NULL`
- `gender TEXT NULL`
- `status TEXT NOT NULL DEFAULT 'enrolled'`
- `current_class_id UUID REFERENCES classes(id)`
- `created_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- `updated_at TIMESTAMPTZ NOT NULL DEFAULT now()`

Unique constraints:
- `UNIQUE (school_id, student_number)`

Indexes:
- `idx_students_school_id` on `(school_id)`
- `idx_students_current_class_id` on `(current_class_id)`

Notes:
- Current JSON stores `guardian` as a free-text field and `classId` directly.
- In future, `current_class_id` should reflect an active enrollment record.

### 3.10 `guardians`

Represents parent/guardian contacts.

Columns:
- `id UUID PRIMARY KEY`
- `school_id UUID NOT NULL REFERENCES schools(id)`
- `name TEXT NOT NULL`
- `relationship TEXT NULL`
- `email TEXT NULL`
- `phone TEXT NULL`
- `status TEXT NOT NULL DEFAULT 'active'`
- `created_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- `updated_at TIMESTAMPTZ NOT NULL DEFAULT now()`

Indexes:
- `idx_guardians_school_id` on `(school_id)`

Notes:
- Current code stores `guardian` as text on students.
- A separate guardian table is required for real parent/guardian relationships.
- Guardians are school-owned and may be associated with multiple students.

### 3.11 `student_guardians`

Represents the many-to-many link between students and guardians.

Columns:
- `id UUID PRIMARY KEY`
- `student_id UUID NOT NULL REFERENCES students(id)`
- `guardian_id UUID NOT NULL REFERENCES guardians(id)`
- `school_id UUID NOT NULL REFERENCES schools(id)`
- `is_primary BOOLEAN NOT NULL DEFAULT false`
- `created_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- `ended_at TIMESTAMPTZ NULL`

Unique constraints:
- `UNIQUE (student_id, guardian_id)`

Indexes:
- `idx_student_guardians_student_id` on `(student_id)`
- `idx_student_guardians_guardian_id` on `(guardian_id)`
- `idx_student_guardians_school_id` on `(school_id)`

Notes:
- This enables multiple guardians and preserves history without overwriting string metadata.
- The added `school_id` supports tenant integrity: student and guardian must belong to the same school.
- Future parent portal authentication can connect `guardians` to `users` through a separate identity bridge.

### 3.12 `student_class_assignments`

Preserves student class placement history.

Columns:
- `id UUID PRIMARY KEY`
- `student_id UUID NOT NULL REFERENCES students(id)`
- `class_id UUID NOT NULL REFERENCES classes(id)`
- `school_id UUID NOT NULL REFERENCES schools(id)`
- `assigned_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- `ended_at TIMESTAMPTZ NULL`
- `is_current BOOLEAN NOT NULL DEFAULT true`

Unique constraints:
- `UNIQUE (student_id, class_id, assigned_at)`

Indexes:
- `idx_student_class_assignments_student_id` on `(student_id)`
- `idx_student_class_assignments_class_id` on `(class_id)`
- `idx_student_class_assignments_school_id` on `(school_id)`

Notes:
- Current JSON stores only a single `classId` on `students`.
- This table is required to preserve attendance history when students move classes.

### 3.13 `attendance_events`

Represents attendance capture sessions for a class/date.

Columns:
- `id UUID PRIMARY KEY`
- `school_id UUID NOT NULL REFERENCES schools(id)`
- `class_id UUID NOT NULL REFERENCES classes(id)`
- `date DATE NOT NULL`
- `recorded_by UUID REFERENCES users(id)`
- `recorded_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- `updated_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- `sync_source TEXT NULL`
- `session_id UUID REFERENCES user_sessions(id)`

Unique constraints:
- `UNIQUE (school_id, class_id, date)`

Indexes:
- `idx_attendance_events_school_id` on `(school_id)`
- `idx_attendance_events_class_id` on `(class_id)`
- `idx_attendance_events_date` on `(date)`

Notes:
- Current JSON stores a denormalized `attendance` object keyed by date/class/student.
- This table models the event separately from individual student records.

### 3.14 `attendance_records`

Represents one student attendance status within an event.

Columns:
- `id UUID PRIMARY KEY`
- `event_id UUID NOT NULL REFERENCES attendance_events(id)`
- `student_id UUID NOT NULL REFERENCES students(id)`
- `status TEXT NOT NULL` -- `present`, `absent`, `late`, `excused`
- `recorded_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- `updated_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- `synced BOOLEAN NOT NULL DEFAULT true`
- `sync_client_id TEXT NULL`
- `sync_record_id TEXT NULL`

Unique constraints:
- `UNIQUE (event_id, student_id)`

Indexes:
- `idx_attendance_records_event_id` on `(event_id)`
- `idx_attendance_records_student_id` on `(student_id)`

Notes:
- This structure supports idempotent attendance persistence and future offline sync metadata.

### 3.15 `attendance_record_history`

Optional table for audit/history of attendance changes.

Columns:
- `id UUID PRIMARY KEY`
- `attendance_record_id UUID NOT NULL REFERENCES attendance_records(id)`
- `status TEXT NOT NULL`
- `changed_by UUID REFERENCES users(id)`
- `changed_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- `reason TEXT NULL`
- `metadata JSONB NULL`

Indexes:
- `idx_attendance_record_history_record_id` on `(attendance_record_id)`

Notes:
- Preserves history if records are corrected or resynced.
- Current system does not preserve past attendance versions.

### 3.16 `invitations`

Represents staff invitation lifecycle.

Columns:
- `id UUID PRIMARY KEY`
- `school_id UUID NOT NULL REFERENCES schools(id)`
- `invited_by UUID REFERENCES users(id)`
- `invitee_name TEXT NOT NULL`
- `invitee_email TEXT NOT NULL`
- `role TEXT NOT NULL` -- `teacher`, `admin`, etc.
- `status TEXT NOT NULL DEFAULT 'pending'` -- `pending`, `accepted`, `revoked`, `expired`
- `code TEXT NOT NULL UNIQUE`
- `invited_at TIMESTAMPTZ NOT NULL DEFAULT now()`
- `expires_at TIMESTAMPTZ NULL`
- `accepted_at TIMESTAMPTZ NULL`
- `revoked_at TIMESTAMPTZ NULL`
- `accepted_user_id UUID REFERENCES users(id)`

Indexes:
- `idx_invitations_school_id` on `(school_id)`
- `idx_invitations_invitee_email` on `(invitee_email)`

Unique constraints:
- `UNIQUE (school_id, invitee_email, status) WHERE status = 'pending'`

Notes:
- Current JSON stores only pending invitations and accepted metadata.
- Expiry, revocation, and acceptance references are required for production.

### 3.17 `audits`

Represents tamper-visible audit events.

Columns:
- `id UUID PRIMARY KEY`
- `actor_id UUID REFERENCES users(id)`
- `actor_name TEXT NOT NULL`
- `school_id UUID REFERENCES schools(id)`
- `entity_type TEXT NULL`
- `entity_id UUID NULL`
- `action TEXT NOT NULL`
- `detail TEXT NULL`
- `metadata JSONB NULL`
- `created_at TIMESTAMPTZ NOT NULL DEFAULT now()`

Indexes:
- `idx_audits_school_id` on `(school_id)`
- `idx_audits_actor_id` on `(actor_id)`
- `idx_audits_entity` on `(entity_type, entity_id)`

Notes:
- Current JSON audit items are truncated at 100 entries.
- The table should preserve full history.

## 4. Primary keys

- Use UUIDs for all application-level entities.
- Primary keys are `id` columns on each table.
- Natural keys exist for uniqueness but should not replace surrogate PKs.

## 5. Foreign keys

- `platform_memberships.user_id -> users.id`
- `school_memberships.user_id -> users.id`
- `school_memberships.school_id -> schools.id`
- `classes.school_id -> schools.id`
- `classes.academic_term_id -> academic_terms.id`
- `subjects.school_id -> schools.id`
- `class_subjects.school_id -> schools.id`
- `class_subjects.class_id -> classes.id`
- `class_subjects.subject_id -> subjects.id`
- `class_subjects.teacher_id -> users.id`
- `assessments.school_id -> schools.id`
- `assessments.subject_id -> subjects.id`
- `assessments.class_id -> classes.id`
- `assessments.academic_term_id -> academic_terms.id`
- `assessment_results.school_id -> schools.id`
- `assessment_results.assessment_id -> assessments.id`
- `assessment_results.student_id -> students.id`
- `report_cards.school_id -> schools.id`
- `report_cards.student_id -> students.id`
- `report_cards.academic_term_id -> academic_terms.id`
- `report_card_entries.report_card_id -> report_cards.id`
- `report_card_entries.subject_id -> subjects.id`
- `class_teachers.class_id -> classes.id`
- `class_teachers.user_id -> users.id`
- `students.school_id -> schools.id`
- `students.current_class_id -> classes.id`
- `guardians.school_id -> schools.id`
- `student_guardians.student_id -> students.id`
- `student_guardians.guardian_id -> guardians.id`
- `student_guardians.school_id -> schools.id`
- `student_class_assignments.student_id -> students.id`
- `student_class_assignments.class_id -> classes.id`
- `student_class_assignments.school_id -> schools.id`
- `attendance_events.school_id -> schools.id`
- `attendance_events.class_id -> classes.id`
- `attendance_events.recorded_by -> users.id`
- `attendance_events.session_id -> user_sessions.id`
- `attendance_records.event_id -> attendance_events.id`
- `attendance_records.student_id -> students.id`
- `invitations.school_id -> schools.id`
- `invitations.invited_by -> users.id`
- `invitations.accepted_user_id -> users.id`
- `audits.actor_id -> users.id`
- `audits.school_id -> schools.id`

## 6. Unique constraints

- `users.email UNIQUE`
- `schools.id PRIMARY KEY`
- `school_memberships` partial unique on active membership per user/school
- `classes` unique per `(school_id, name, academic_term_id)`
- `students` unique per `(school_id, student_number)`
- `class_teachers` unique active assignment per `(class_id, user_id)`
- `student_guardians` unique per `(student_id, guardian_id)`
- `student_class_assignments` unique per `(student_id, class_id, assigned_at)`
- `attendance_events` unique per `(school_id, class_id, date)`
- `attendance_records` unique per `(event_id, student_id)`
- `invitations.code UNIQUE`
- `invitations` partial unique on pending invitation per `(school_id, invitee_email)`

## 7. Indexes

Essential indexes:
- `users.email`
- `user_sessions.user_id`
- `platform_memberships.user_id`
- `school_memberships.school_id`
- `school_memberships.user_id`
- `school_memberships.role,status`
- `classes.school_id`
- `classes.academic_term_id`
- `subjects.school_id`
- `class_subjects.class_id`
- `class_subjects.subject_id`
- `class_subjects.teacher_id`
- `assessments.school_id`
- `assessments.class_id`
- `assessments.subject_id`
- `assessment_results.assessment_id`
- `assessment_results.student_id`
- `report_cards.school_id`
- `report_cards.student_id`
- `report_card_entries.report_card_id`
- `report_card_entries.subject_id`
- `class_teachers.class_id`
- `class_teachers.user_id`
- `students.school_id`
- `students.current_class_id`
- `guardians.school_id`
- `student_guardians.student_id`
- `student_guardians.guardian_id`
- `student_guardians.school_id`
- `student_class_assignments.student_id`
- `student_class_assignments.class_id`
- `student_class_assignments.school_id`
- `attendance_events.school_id`
- `attendance_events.class_id`
- `attendance_events.date`
- `attendance_records.event_id`
- `attendance_records.student_id`
- `invitations.school_id`
- `invitations.invitee_email`
- `audits.school_id`

Indexes should align with queries in `visibleState()` and authorization checks in the server.

## 8. Tenant boundaries

Tenant isolation is fundamental.

For every school-owned entity, store `school_id` explicitly and enforce it at the database level whenever possible.

School-owned entities include:
- `school_memberships`
- `classes`
- `students`
- `guardians`
- `student_guardians`
- `student_class_assignments`
- `class_subjects`
- `subjects`
- `assessments`
- `assessment_results`
- `report_cards`
- `report_card_entries`
- `attendance_events`
- `attendance_records`
- `invitations`
- `audits`

Tenant boundary rules:
- `users` remain global identities.
- `school_memberships` connect users to tenant data and enforce active access.
- `classes`, `students`, `guardians`, `subjects`, `assessments`, `report_cards`, and `attendance` must all belong to the same `school_id`.
- `school_id` should be part of index/filter paths for all tenant queries.
- For multi-table relationships, duplicate `school_id` on child tables where needed to support composite integrity checks.

Strong tenant integrity strategy:
- Use composite foreign keys where tables reference both an entity and the owning school.
  - Example: `class_subjects(class_id, subject_id, school_id)` should ensure both `class_id` and `subject_id` belong to the same `school_id`.
- Use partial unique indexes to enforce active/unique constraints on memberships, assignments, and invitations.
- Use PostgreSQL Row Level Security (RLS) in production to prevent accidental cross-tenant reads/writes when queries are not fully filtered.
- Do not rely on `school_id` filtering alone; enforce tenant relationships through schema constraints and application checks.

Application-level authorization should verify both `school_id` and membership status.

## 9. Relationship explanation

### Identity vs membership
- `users` = global actor identity.
- `school_memberships` = tenant-specific relationship, role, and status.
- This avoids conflating `user` with `teacher` or `principal`.
- A user can belong to multiple schools with different roles.

### Classes and teachers
- `classes` are owned by a school.
- `class_teachers` assigns teachers to classes.
- This replaces current array fields `teacherIds` and `users.classIds`.

### Students and guardians
- `students` are school-owned individuals.
- `guardians` are separate contacts.
- `student_guardians` models many-to-many relationships.

### Student class history
- `student_class_assignments` preserves the student’s placement over time.
- `students.current_class_id` is derived from the active assignment.
- Current JSON is a single `classId`; the relational model preserves history.

### Attendance
- `attendance_events` groups attendance by school/class/date.
- `attendance_records` stores one row per student within an event.
- This supports idempotent writes and future offline synchronization.

### Invitations
- `invitations` track invite status and code lifecycle.
- Accepting an invitation creates a `users` record and a `school_memberships` entry.

### Audit
- `audits` capture who acted, what changed, when, where, and which school.
- `entity_type`/`entity_id` link to school-owned data.
- `metadata` stores contextual details.

## 10. Historical-data strategy

Preserve history by modeling current state separately from timeline data.

Key patterns:
- Keep `students` as the current student record, with `student_class_assignments` for historical class placement.
- Keep `class_teachers` as a history of teacher assignments.
- Keep `attendance_events` and `attendance_records` as event-based history rather than overwriting raw attendance keys.
- Keep `audits` as append-only records with full `created_at` history.
- Allow `school_memberships` to store status transitions and end dates.

The existing JSON model does not preserve student/class history or attendance edits; the relational schema explicitly preserves them.

## 11. Attendance data strategy

Future attendance must support:
- idempotent writes for date/class/student combination
- offline-first sync metadata
- actor attribution and record timestamps
- class and student tenancy enforcement
- history of updates or corrections

Schema strategy:
- `attendance_events` is the attendance session identity, unique per `(school_id, class_id, date)`.
- `attendance_records` is the student-level record within the event.
- `sync_source`, `session_id`, `sync_client_id`, `sync_record_id`, and `synced` support later offline synchronization.
- `attendance_record_history` can preserve changes when a record is corrected.

This maps cleanly from current JSON records keyed by `${date}:${classId}:${studentId}`.

## 12. Invitation strategy

Invitation lifecycle must include:
- pending
- accepted
- revoked
- expired

Relational model:
- `invitations` stores the active code, invitee contact, role, and timestamps.
- When accepted, the system creates `users` and `school_memberships` and sets `accepted_at` and `accepted_user_id`.
- A unique pending invitation constraint prevents duplicate pending invites for the same email + school.
- Expiry and revocation are explicit fields.

Current JSON only tracks `pending` invitations and marks acceptance.

## 13. Audit strategy

Audit rows must answer WHO / WHAT / WHEN / WHERE / SCHOOL.

Recommended fields:
- `actor_id` / `actor_name`
- `school_id`
- `entity_type`
- `entity_id`
- `action`
- `detail`
- `metadata JSONB`
- `created_at`

This preserves the existing pattern in `data.audit` while removing the 100-row truncation.

Audit queries should be able to filter by school, actor, entity, and time range.

## 14. Migration considerations

Current JSON store facts:
- `school` root object normalized into `schools[]`
- `users` include flattened `role`, `schoolId`, and `passwordHash`
- `memberships` is already normalized but duplicates `users.role`
- `classes.teacherIds` is a denormalized teacher assignment list
- `students.guardian` is a string, not a proper guardian relationship
- `attendance` is a keyed object, not rows
- `invitations` are simple objects without expiry or revocation fields
- `audit` is limited to the most recent 100 entries

Migration risks:
- Normalizing `school` root into `schools` may require filling `school_id` on all rows.
- Converting `teacherIds` arrays into `class_teachers` rows requires mapping array values to join rows.
- Converting `users.classIds` to `class_teachers` or membership-driven access requires careful de-duplication.
- Converting `attendance` object to event/record rows requires reconstructing event identities and may require deduplicating existing keys.
- Preserving current `guardian` strings into `guardians` may need fallback generic guardian contacts or a `student.guardian_text` field during migration.
- `users.role` and `memberships.role` divergence should be reconciled into canonical membership role semantics.
- Existing `audit` truncation implies lost history; migration can preserve only the existing retained records.

Migration strategy:
1. Create relational schema.
2. Import `schools` and link all current school-owned arrays to `school_id`.
3. Import `users` and `memberships`, then reconcile `role` and `status`.
4. Import `classes`, `students`, `invitations`, and audit rows.
5. Convert `attendance` keys into `attendance_events` and `attendance_records`.
6. Populate `student_class_assignments` from current student `classId`.
7. Keep a temporary legacy field mapping layer for data-store compatibility during migration.

## 15. Risks and tradeoffs

### PostgreSQL vs SQLite
- PostgreSQL is the recommended production database.
  - Pros: concurrency, backups, strong multi-tenant support, hosted managed services.
  - Cons: higher operational complexity than SQLite.
- SQLite is acceptable for local development only.
  - Pros: zero-install dev environment, fast prototype support.
  - Cons: poor concurrent writes, no row-level locking, not a safe production store for multi-tenant workloads.

### Tradeoffs
- Keeping `users` global and `memberships` tenant-scoped adds complexity but avoids identity-role coupling.
- Adding separate `guardians` and `student_class_assignments` increases schema complexity but is necessary for historical and parent/guardian workflows.
- A full `attendance_events` model is more complex than the current flat map, but it is required for durable offline sync and history.
- `audits` should be append-only; dropping the 100-item truncation is essential for compliance, but it increases storage.

### Practical limits for Mission 004A
- This document is a design only. No application code changes are required.
- The current JSON store remains the source of truth until a later migration mission.

## ER-style relationship diagram

PlatformUsers
  → `user_credentials`
  → `user_sessions`
  → `school_memberships`

Schools
  → `classes`
  → `students`
  → `guardians`
  → `academic_terms`
  → `invitations`
  → `audits`
  → `attendance_events`

school_memberships
  → belongs to `users`
  → belongs to `schools`

classes
  → `class_teachers`
  → `student_class_assignments`
  → `attendance_events`

students
  → `student_guardians`
  → `student_class_assignments`
  → `attendance_records`

attendance_events
  → `attendance_records`
  → optionally `attendance_record_history`

invitations
  → may create `users`
  → may create `school_memberships`

audits
  → reference `users`, `schools`, and entity IDs

## Current data vs future required data

### CURRENT DATA
- `schools[]` and fallback root `school`
- `users` with `id`, `name`, `email`, `role`, `status`, `schoolId`, `classIds`, `passwordHash`
- `memberships` with `id`, `userId`, `schoolId`, `role`, `status`
- `classes` with `teacherIds` array and text `year`
- `students` with `classId` and text `guardian`
- `attendance` object keyed by `${date}:${classId}:${studentId}` with the latest record only
- `invitations` with pending invitation codes
- `audit` with author, school, action, detail, timestamp

### FUTURE DATA REQUIRED BY SCHVIA
- platform-level users and founder/platform-admin roles
- durable session storage
- separate authentication credentials
- explicit school lifecycle status and academic terms
- proper teacher-class assignment join table
- guardian/parent entities and student-guardian relationships
- student class assignment history
- attendance event and record history with sync metadata
- invitation expiry/revocation and acceptance references
- full append-only audit history with entity references
- optional permissions/capabilities beyond coarse role names

## Recommended next step: Mission 004B

Design or implement the first migration scaffold from the current JSON store to the relational schema.

Suggested focus for Mission 004B:
- Create a migration plan and toolkit that can read `data/schvia.json`, normalize `school`, `users`, `memberships`, `classes`, `students`, `attendance`, `invitations`, and `audit`, and write them into relational tables.
- Preserve the current application behavior while introducing the schema.
- Keep the JSON store untouched until the migration path is verified.

## 16. Architecture Corrections — Mission 004A.1

### Changes from 004A
- Added a dedicated `platform_memberships` table instead of platform boolean flags on `users`.
- Added Academic Core entities: `subjects`, `class_subjects`, `assessments`, `assessment_results`, `report_cards`, and `report_card_entries`.
- Added tenant-aware `school_id` on `student_guardians` and `class_subjects`.
- Clarified tenant integrity requirements with composite-school constraints and Row Level Security.
- Strengthened attendance sync metadata and correction history guidance.

### Why it was corrected
- The previous design did not model the Academic Core needed for grading, subject management, and report cards.
- Platform-level authorization should not rely on boolean fields attached to a user identity.
- The initial guardian model lacked a proper tenant link and future parent portal relationship shape.
- Stronger tenant integrity is needed to prevent invalid cross-school relationships.
- Attendance must explicitly support offline-first idempotency and history rather than only a denormalized event map.

### New tables
- `platform_memberships`
- `subjects`
- `class_subjects`
- `assessments`
- `assessment_results`
- `report_cards`
- `report_card_entries`

### Removed / replaced fields
- Removed `users.is_platform_admin` and `users.is_founder`.
- Replaced user role flags with `platform_memberships` for platform-level authorization.
- Replaced denormalized `teacherIds` with `class_subjects` and `class_teachers`.
- Replaced string-only guardian metadata with structured `guardians` and `student_guardians`.

### Tenant integrity decisions
- All school-owned tables explicitly store `school_id`.
- Child tables such as `class_subjects`, `assessment_results`, and `student_guardians` duplicate `school_id` to support cross-table tenant validation.
- Use PostgreSQL composite foreign keys or application-enforced checks for school ownership on multi-entity relationships.
- Plan for Row Level Security in production to enforce tenant boundaries beyond query filters.

### Platform identity decisions
- Keep `users` as a global identity store.
- Use `platform_memberships` to represent `platform_admin`, `founder`, and `platform_operator` roles.
- Allow a user to have many school memberships plus platform-level roles.
- Keep school roles in `school_memberships` separate from platform roles.

### Parent/guardian strategy
- `guardians` are school-owned contacts.
- `student_guardians` links students and guardians while preserving school ownership.
- Add `school_id` to `student_guardians` for tenant consistency.
- Future parent portal authentication can be modeled as a bridge between `guardians` and `users` or a separate `guardian_id` identity mapping.

### Academic Core coverage
- `subjects` model school-owned academic disciplines.
- `class_subjects` connect subjects to classes and optionally responsible teachers.
- `assessments` represent classroom evaluations by subject, class, and term.
- `assessment_results` capture student performance on assessments.
- `report_cards` represent term-level student reports.
- `report_card_entries` store subject-level report line items.

### Attendance/offline strategy
- `attendance_events` and `attendance_records` remain the foundation.
- Add `sync_client_id` and `sync_record_id` for idempotent offline replay.
- Use server timestamps for authoritative ordering and store client timestamp metadata if needed.
- Preserve correction history in `attendance_record_history`.
- Reject or carefully reconcile duplicate client-generated IDs in the future.

### Identifier strategy
- Use UUIDs for all major entities to support global uniqueness across tenants.
- Prefer PostgreSQL `gen_random_uuid()` or application-side UUID v4 for server-generated IDs.
- Use client-generated IDs only for offline attendance records, reconciled through `sync_client_id` and `sync_record_id`.

### Confirmation
- No application code was modified during this design correction.
- This mission is design-only and does not implement database changes.
