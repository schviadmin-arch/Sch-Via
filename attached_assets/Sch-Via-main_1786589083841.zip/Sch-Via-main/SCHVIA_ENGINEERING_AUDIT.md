# SCHVIA ENGINEERING AUDIT

## 1. Executive summary

SchVIA is currently a prototype-grade school operating workspace built on a minimal Node.js server and a static browser frontend. The repo contains a working school pilot with supported principal and teacher workflows, local JSON persistence, offline attendance queuing, and a simple email/password identity path. However, the platform is not production-ready: it lacks a package manifest, a relational database, durable session storage, service-worker/PWA support, Founder platform authentication, email delivery, and robust tenant/authorization lifecycle management.

Key findings:
- The working school workspace is real and backed by server-side API routes in `serve.mjs`.
- The founder dashboard from `index.html` is static sample content and not connected to live data.
- Persistence is a local JSON file (`data/schvia.json`) created at runtime; there is no database or migration framework.
- Authentication uses signed HTTP-only cookies and in-memory sessions, but developer fallback secrets and stale session storage are present.
- Attendance has server-side validation and a browser offline queue, but the offline experience is limited and not PWA-based.
- Existing tests pass: `tests/smoke.mjs` and `tests/real-user-e2e.mjs`.

## 2. Current architecture

### Runtime
- Node.js application using native `node:http`, `fs/promises`, `crypto`, and `path`.
- No `package.json`, no npm/yarn/pnpm dependency manifest.
- Static assets served directly from the repository root.
- Environment variables: `PORT`, `DATA_PATH`, `NODE_ENV`, `SESSION_SECRET`.

### Framework / libraries
- No external runtime frameworks.
- Pure vanilla JavaScript on both server and client.
- Browser frontend uses DOM APIs, `fetch`, `localStorage`, and event listeners.

### Server architecture
- Entrypoint: `serve.mjs`.
- Single process HTTP server.
- In-memory session store: `Map` in `serve.mjs`.
- JSON persistence store persisted to disk with `writeFile`.
- API routed by request path matching inside `handleApi`.
- Security headers set on every response.

### Frontend architecture
- Static `index.html` + `styles.css` + `app.js`.
- Client-side UX and app state are implemented in `app.js`.
- No build or compilation step.
- UI state is routed using location hash values (`#home`, `#dashboard`, `#pilot`).

### Persistence mechanism
- Local JSON file: `data/schvia.json` (created at runtime if missing).
- Data is loaded into an in-memory `data` object on server start.
- Writes are performed by rewriting the full JSON file.
- Sessions are stored only in memory and are lost on server restart.

### Data model
- `schools`
- `users`
- `memberships`
- `classes`
- `students`
- `attendance`
- `invitations`
- `audit`
- Seed data is normalized into a membership table at startup.

### API architecture
- `/api/auth/login` — demo role-based login
- `/api/auth/register` — register a new school principal
- `/api/auth/login-email` — login with email/password
- `/api/auth/accept-invite` — accept a staff invitation
- `/api/auth/logout` — clear session
- `/api/state` — return the authorized workspace state
- `/api/school` — update school settings
- `/api/users` — create staff invitations
- `/api/classes` — create classes
- `/api/students` — create students
- `/api/attendance` — submit attendance batches
- `/health` and `/ready` — health and readiness probes

### Authentication architecture
- Session cookie: `schvia_session`.
- Session values are signed with `HMAC-SHA256` and `SESSION_SECRET`.
- Passwords are hashed with Node's built-in `scryptSync`.
- Login attempts are throttled per remote address.
- In production, startup protects against missing `SESSION_SECRET`.

### Authorization architecture
- `requireRole(request, response, roles)` enforces authentication, active account, active membership, and role membership.
- Roles are `principal`, `admin`, and `teacher`.
- `visibleState(session)` scopes data by school and role.
- Teacher access is scoped to assigned classes; principal/admin access is full school scope.

### Tenant architecture
- Every school-owned record contains `schoolId`.
- `membershipFor(session)` ties users to a school and active membership.
- `schoolFor(session)` resolves the current school from the session.
- Multi-school support exists in the data model, but school switching is not exposed beyond session creation for newly registered schools.

### Testing architecture
- `tests/smoke.mjs` — basic API, auth, role filter, and production-secret protection checks.
- `tests/real-user-e2e.mjs` — end-to-end flow including registration, invitation acceptance, class assignment, teacher scope, and tenant isolation.
- Tests launch the server as a child process and use native `fetch`.

### Deployment architecture
- Replit configuration in `.replit` and `replit.md`.
- Server is intended to run with `node serve.mjs`.
- No CI configuration, no Dockerfile, and no deploy pipeline files.

## 3. Current data model

### Schools
- `schools[]`
- Current seed includes a single school `school-northbridge`.
- New schools are created during `/api/auth/register`.

### Users
- `users[]` with fields: `id`, `name`, `email`, `role`, `status`, `schoolId`, `classIds`, `passwordHash`, `createdAt`.
- Demo login selects the first active user matching a requested role.

### Memberships
- `memberships[]` created for every user.
- Fields include `id`, `userId`, `schoolId`, `role`, `status`, `createdAt`.
- `normalizeData()` ensures seeded users have memberships.

### Classes
- `classes[]` with `id`, `schoolId`, `name`, `year`, `teacherIds`.
- Teacher assignment is stored as an array of assigned teacher IDs.

### Students
- `students[]` with `id`, `schoolId`, `studentId`, `name`, `gender`, `classId`, `guardian`, `status`.
- Students are created within a class.

### Attendance
- `attendance` object keyed by `${date}:${classId}:${studentId}`.
- Values contain `id`, `schoolId`, `date`, `classId`, `studentId`, `status`, `recordedBy`, `recordedAt`, `updatedAt`, `synced`.
- There is currently no separate attendance history or correction log beyond the latest record.

### Invitations
- `invitations[]` with `id`, `schoolId`, `name`, `email`, `role`, `status`, `invitedAt`, `code`.
- Accepting an invite creates a user and membership and marks the invitation `accepted`.

### Audit
- `audit[]` stores action events.
- Items include `id`, `actorId`, `actorName`, `schoolId`, `action`, `detail`, `at`.
- The array is truncated to the most recent 100 records.

## 4. Authentication

### Implemented
- Principal registration with email/password.
- Email/password login.
- Invitation acceptance with account creation.
- Signed HTTP-only session cookies.
- Login throttling for demo/credential requests.

### Limitations
- No email delivery or recovery flow.
- Session storage is in-memory and volatile.
- Demo role login remains available via `/api/auth/login`.
- No password reset or MFA.
- No `package.json` or dependency manifest means deployment relies on environment knowledge rather than explicit runtime metadata.

## 5. Authorization

### Implemented
- Role-based authorization for routes.
- Principal/admin-only mutations for school settings, user invitations, class creation, and student creation.
- Teacher assignment enforcement for attendance submission.
- Teacher view restricted to assigned classes and students.

### Limitations
- Role/capability model is coarse; there is no fine-grained capability table.
- No explicit invitation revocation or membership suspension workflows.
- Session authorization relies on session role and membership status but not on a separate capability domain.

## 6. Multi-tenancy

### Implemented
- School ownership is present on records.
- Memberships tie users to schools.
- `visibleState()` filters payloads to the active school and assignment.
- Tenant isolation is exercised in tests by creating two schools and verifying state separation.

### Limitations
- The founder view is not tenant-aware because it is static sample data.
- There is no durable school switching mechanism.
- The persistence layer is a single JSON file, which is a durability and scalability risk.

## 7. Student / records system

### Implemented
- Add student form in the frontend.
- Server-side student creation with validation.
- Student details surfaced in the school workspace.
- Class-based student filtering for teachers.

### Limitations
- No student edit or deletion APIs.
- No guardian entity relationship beyond a string field.
- No enrollment history or archival lifecycle.
- No student search, pagination, or parent-facing records.

## 8. Attendance system

### Implemented
- Attendance submission API with date/class/student validation.
- Teacher- or principal-scoped access.
- Offline browser queuing via `localStorage` and automatic retry.
- Attendance record persistence to JSON.
- Audit event on attendance save.

### Limitations
- Offline support is limited to queue storage; the app shell is not a PWA.
- No durable offline storage like IndexedDB.
- No conflict resolution beyond last-write overwrite.
- No attendance history or report summaries beyond current state.
- The `synced` field exists but is not a complete sync-state model.

## 9. Frontend

### Implemented
- Public marketing site.
- Workspace chooser and role-based pilot entry.
- Principal and teacher workspace screens.
- Client state derived from `/api/state`.
- Offline status indicator and attendance retry messaging.
- Modal form for access requests stored in localStorage.

### Limitations
- No separate frontend build system.
- Founder command center is mocked UI.
- The offline experience is not a full PWA.
- Some UI interactions are hardcoded and not fully reactive.
- Access request submission does not reach a server.

## 10. Testing

### Implemented
- `tests/smoke.mjs` passes.
- `tests/real-user-e2e.mjs` passes.

### Limitations
- No package-based test runner or script.
- No browser automation or end-to-end tests for offline queue behavior.
- No security-focused tests for CSRF, token replay, or XSS.
- No regression tests for founder UX or static marketing flows.

## 11. Security

### Implemented
- HTTP-only, SameSite=session cookie handling for auth.
- Server validation of JSON request bodies and content type.
- Throttled login attempts.
- Security headers on every response.
- Production startup guard against missing `SESSION_SECRET`.

### Risks
- `SESSION_SECRET` fallback value exists in development mode.
- Session storage is volatile and lost on restart.
- There is no explicit CSRF token protection beyond SameSite cookies.
- No audit of failed auth or suspicious state transitions.
- Static Founder UI is publicly reachable and may confuse users.

## 12. Deployment

### Implemented
- Replit metadata in `.replit` and `replit.md`.
- Runtime command `node serve.mjs`.
- Health and readiness endpoints.

### Limitations
- No package manifest, Dockerfile, or CI pipeline.
- No documented production hosting configuration.
- No explicit backup strategy for `data/schvia.json`.
- No migration path from runtime JSON persistence to a durable datastore.

## 13. Technical debt

- Missing dependency manifest (`package.json`).
- Local JSON persistence with full-file rewrites.
- In-memory sessions.
- Founder dashboard is mocked while school workspace is live.
- Coarse role model and lack of capability abstraction.
- No offline app shell or durable browser storage beyond `localStorage`.
- Incomplete audit history and no event metadata beyond the latest 100 records.
- No email or token lifecycle for invitations.
- No admin or platform-level separation for founder users.
- The app mixes demo compatibility login and real account flows.

## 14. Missing functionality

- Parent portal.
- Reports/results engine.
- Invite email delivery and expiration.
- Password recovery.
- Student/class editing and lifecycle management.
- Real founder control plane.
- Durable database and migration system.
- PWA/service worker and offline shell.
- Backup/recovery for `data/schvia.json`.
- Security test coverage.
- CI/CD pipeline.

## 15. Risks

### Highest priority risks
1. Persistence risk: `data/schvia.json` is the only durable store and is rewritten in full without transaction support.
2. Secret risk: development fallback for `SESSION_SECRET` exists and can be accidentally relied on.
3. Session risk: in-memory sessions are not durable and are lost on restart.
4. Tenant risk: multi-school support is present in data, but the founder UI is not tenant-aware and school switching is not explicit.
5. Offline risk: the browser offline queue is not durable or conflict-aware.

### Additional risks
- Missing `package.json` and formal dependency metadata.
- Mocked Founder dashboard may be mistaken for a real platform feature.
- No CSRF protection model beyond SameSite cookies.
- Invitation lifecycle is incomplete without revocation or expiry.
- Audit truncation may lose historical action records.

## 16. Recommended architecture

1. Keep the existing `serve.mjs` domain behavior as a compatibility reference.
2. Introduce an explicit Node application manifest and package metadata.
3. Migrate persistence to a relational database with structured tables and tenant-scoped foreign keys.
4. Replace in-memory sessions with durable session storage or a managed auth provider.
5. Implement a small capability-based authorization layer separate from role names.
6. Build a separate founder control plane with explicit authentication.
7. Move offline attendance toward IndexedDB and a service-worker shell.
8. Preserve the static marketing site and the browser `#pilot` experience while evolving the backend.

## 17. Recommended implementation order

1. Baseline and safety: document architecture, preserve current tests, and add a package manifest.
2. Persistence foundation: relational tenant-aware datastore and migration path.
3. Authentication foundation: durable sessions, secure secrets, password recovery/invite flows.
4. Authorization foundation: capability model, membership lifecycle, invitation expiry.
5. Attendance foundation: robust offline sync and correction history.
6. Founder/control plane foundation: separate authenticated platform access.
7. UX retention: preserve working school workspace flows while adding backend safety.
