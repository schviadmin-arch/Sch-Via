# SchVIA project handoff

## What this project is

SchVIA is a dependency-free school operations MVP: a calm, trustworthy operating layer for a first school pilot. It now includes both the original public product direction and a working local school workspace:

- Public, enterprise-oriented landing page and founder preview
- Real school workspace creation with password-based local accounts
- Invitation acceptance with password setup and school membership
- Compatibility demo entry for the seeded pilot
- Server-side multi-school state persisted to a local JSON file
- Principal/admin workflows for students, classes, school settings, and staff invitations
- Teacher workflow for assigned-class attendance
- Server-side role/capability checks and school-scoped data access
- Idempotent attendance writes with audit events
- Offline attendance queue in the browser with automatic retry when connectivity returns
- Responsive behavior for desktop and mobile

The interface uses SchVIA’s initial design direction: deep navy, cool neutrals, restrained blue, spacious hierarchy, and minimal noise.

## Run locally / on Replit

This is a dependency-free static web app. Install dependencies and start the project with:

```bash
npm install
npm start
```

Run the existing tests with:

```bash
npm run smoke
npm run e2e
npm run persistence
npm test
```

The Replit workflow is configured to run `node serve.mjs`.

## Accessing the product

- Open the public site at `/`.
- Choose **Sign in** or **Sign in to a workspace** to open the workspace chooser.
- **Founder command center** (`#dashboard`) is the oversight view with clearly labeled sample network data.
- **School workspace** (`#pilot`) opens the role sign-in for the working pilot. Choose Principal to manage the school or Teacher to work with assigned-class attendance. This MVP uses demo role selection rather than email/password identity.
- The school workspace reads current server state on entry, browser focus, reconnect, and manual refresh. Attendance saves to `data/schvia.json` and creates an audit event.

## Important boundary: what is real today

The working pilot is intentionally narrow and uses seeded demo roles rather than production identity infrastructure:

- Real workspace users can create accounts, sign in with email/password, and accept staff invitations; the seeded role selector remains explicitly labeled as demo compatibility access.
- Founder access is intentionally separate from school access: the founder view is sample network data, while the school pilot is the live persisted operational workspace.
- The JSON file is a practical MVP persistence layer, not a production relational database. Records now carry school ownership and real-user workspaces are isolated server-side, but relational migration is still required before production scale.
- The current pilot now exposes `/health` and `/ready`, adds request IDs/security headers, rejects invalid JSON/content types, validates key identifiers/dates, and distinguishes retryable attendance failures from permission/validation failures.
- Demo sessions now have an explicit eight-hour server-side expiry, expired sessions are cleaned up, and repeated sign-in requests are throttled per source address for the current pilot.
- Principals can now open the School settings panel to persist school name, location, and academic term changes through the existing audited `/api/school` route.
- Staff invitations are recorded with a demo acceptance code; email delivery and full account linking are not connected.
- Attendance supports present, absent, late, and excused states, local offline queuing, retry, audit history, and duplicate-safe updates.
- Parent access, communications, payments, grading, email delivery, and production request-access routing remain outside this slice.
- The founder dashboard remains clearly labeled as sample data; the working pilot is entered through “Open the working school pilot”.

## Recommended next implementation sequence

1. Add password recovery/email verification and replace the remaining demo compatibility path with the selected production identity provider.
2. Move the JSON persistence layer to a relational database with migrations, explicit tenant IDs, foreign keys, and backups.
3. Add automated end-to-end coverage for onboarding, permissions, tenant isolation, online attendance, offline attendance, retry, and recovery.
4. Add school configuration, invitation expiry/revocation, teacher assignment editing, and a real invite delivery provider.
5. Add controlled parent attendance access and communication only after school data ownership and retention rules are confirmed.
6. Replace the public Founder sample dashboard with a separately authenticated control plane and connect request access to an approved provider.

The dependency-aware implementation plan and dated build record are maintained in:

- `SCHVIA_POST_AUDIT_IMPLEMENTATION_PLAN.md`
- `SCHVIA_BUILD_LOG.md`

The plan is the source of truth for implementation order, preservation/replacement boundaries, infrastructure gates, migration risks, and verification criteria.

## Product decisions recorded

- Pricing is presented as **request access / early access**, not fabricated self-serve tiers. This fits a school-pilot and enterprise discovery motion while pricing is still being learned.
- The founder layer is an oversight surface, not an unrestricted backdoor. Future authorization must preserve school boundaries and separation of duties.
- Infrastructure should remain replaceable. Do not add Supabase, paid messaging, AI, or other external services just to make a demo appear complete.

## Design notes for the next agent

Use the uploaded master prompt as the product constitution. Preserve the question: **“If this happens, what else must happen?”** Every future workflow should connect consequences, show state, and leave an appropriate audit trail.