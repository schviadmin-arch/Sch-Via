# SchVIA Database Implementation

## Overview

This document describes the relational database foundation built for SchVIA as part of Mission 004C.

The goal is to establish a PostgreSQL-ready schema, migration mechanism, and persistence boundary while preserving the existing JSON persistence path.

## Architecture

### Database technology choice

- The foundation targets PostgreSQL.
- The smallest appropriate dependency added is the official `pg` driver.
- No ORM, framework, or database abstraction library was added.
- Schema and migration behavior are implemented with raw SQL and a lightweight migration runner.

### Schema organization

The relational schema lives in `db/migrations/0001_initial_schema.sql`.

It defines the following entities:

- `users`
- `platform_memberships`
- `user_credentials`
- `user_sessions`
- `schools`
- `school_memberships`
- `academic_terms`
- `classes`
- `class_teachers`
- `subjects`
- `class_subjects`
- `assessments`
- `assessment_results`
- `report_cards`
- `report_card_entries`
- `students`
- `guardians`
- `student_guardians`
- `student_class_assignments`
- `attendance_events`
- `attendance_records`
- `attendance_record_history`
- `invitations`
- `audits`

The schema includes tenant-aware constraints and cross-table composite references where appropriate to prevent invalid cross-school relationships.

## Migration mechanism

### Runner

The migration runner is implemented in `db/migrate.mjs`.

It:

- requires `DATABASE_URL` to be configured
- connects to PostgreSQL using the `pg` driver
- ensures a `schema_migrations` table exists
- applies pending `.sql` files from `db/migrations/`
- records applied migration versions in `schema_migrations`
- executes each migration in a transaction
- fails clearly on error

### Migration files

- Migrations are named with a numeric prefix, such as `0001_initial_schema.sql`.
- They are sorted by filename and applied in numeric order.
- The first migration contains the full initial schema.

## Connection configuration

The database layer reads configuration from:

- `DATABASE_URL`

The connection helper is implemented in `db/index.mjs`.

If `DATABASE_URL` is not configured, the database helper throws a clear error.

## Persistence boundary

A dedicated database module exists at `db/index.mjs`.

It exposes:

- `query(text, params)`
- `connect()`
- `close()`

This module is intentionally separate from the current JSON persistence implementation.

The existing app continues to use `data-store.mjs` and `serve.mjs` without change.

## Local development requirements

To use the database foundation locally, developers must:

- install dependencies with `npm install`
- configure a PostgreSQL connection in `DATABASE_URL`
- run migrations with `node db/migrate.mjs`

The foundation does not require PostgreSQL to be present to keep the current JSON-based app working.

## Testing strategy

Database-focused validation is implemented in `tests/db-schema.mjs`.

It checks:

- migration file ordering
- presence of the initial migration
- creation of all required tables
- expected foreign key references
- expected uniqueness and partial index definitions
- tenant-aware composite foreign key patterns

If `DATABASE_URL` is configured, this test file can be extended to perform a real PostgreSQL validation run, but the current mission does not require or depend on a live database instance.

## Mission 004E — Migration validation

Mission 004E adds a dedicated JSON-to-relational validation layer in `db/migration-utils.mjs` and mission tests in `tests/migration-004e.mjs`.

What is validated:

- deterministic migration plan generation from source JSON
- duplicate student numbers within the same school
- duplicate or conflicting user and membership conditions
- orphan and missing reference validation for users, schools, classes, students, memberships, guardians, attendance, and invitations
- cross-school / tenant integrity checks for classes, students, teachers, attendance, and invitations
- attendance reference integrity for class, student, and recorder relationships
- invitation integrity including duplicate pending invitations per school
- categorized migration issues with `duplicate_conflict`, `tenant_violation`, `orphan_reference`, and `validation`
- accepted vs rejected migration status with explicit `READY` / `NOT READY` report output

Commands used for verification:

- `npm test`
- `npm run db-schema`
- `npm run persistence`
- `npm run migrate:json`
- `npm run db-migrate:dry`
- `node tests/migration-004e.mjs`

Acceptance criteria:

- `tests/migration-004e.mjs` exercises negative validation cases and deterministic plan output
- migration report exposes explicit `accepted`, `rejected`, `success`, and `status` fields
- issue categories are summarized in the report
- existing JSON persistence is unchanged and the current app still runs without PostgreSQL

Known limitation:

- live PostgreSQL cannot be tested without `DATABASE_URL`, so verification is limited to dry-run migration validation and schema checks.

## What is implemented

- PostgreSQL schema foundation for the approved relational model
- migration runner and version tracking
- database connection helper with environment-driven configuration
- schema validation tests
- implementation documentation

## What is intentionally NOT implemented yet

- any actual data migration from JSON to PostgreSQL
- switching the application from JSON persistence to relational persistence
- frontend changes to use a relational store
- platform founder console behavior
- audit history beyond the current JSON audit array
- development seed data or production users
- runtime use of the new database layer in `serve.mjs`

## Future JSON → PostgreSQL migration plug-in

This foundation is designed to be used later by a migration layer that:

1. reads the existing JSON store from `data-store.mjs`
2. writes normalized rows into PostgreSQL using the database boundary in `db/index.mjs`
3. preserves the existing API contracts by keeping JSON persistence active until cutover
4. uses the migration runner to create and evolve the PostgreSQL schema

The current implementation keeps the app running against JSON while establishing a clear relational boundary and schema.
