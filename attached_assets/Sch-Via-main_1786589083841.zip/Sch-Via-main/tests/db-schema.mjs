import assert from "node:assert/strict";
import { readdir, readFile } from "node:fs/promises";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const migrationsDir = join(__dirname, "..", "db", "migrations");

function assertContains(haystack, needle, message) {
  assert.ok(haystack.includes(needle), `${message} (expected substring: ${JSON.stringify(needle)})`);
}

async function main() {
  const files = (await readdir(migrationsDir)).filter((file) => file.endsWith(".sql")).sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
  assert.ok(files.length > 0, "Expected at least one SQL migration file");

  const seen = new Set();
  let previousNumber = 0;
  for (const file of files) {
    const match = file.match(/^(\d{4})_/);
    assert.ok(match, `Migration file name must start with a numeric prefix: ${file}`);
    const number = Number(match[1]);
    assert.equal(file, files[number - 1], `Migration ordering must match numeric prefix for ${file}`);
    assert.ok(number === previousNumber + 1, `Migration sequence must be continuous. Found gap before ${file}`);
    previousNumber = number;
    assert.ok(!seen.has(file), `Duplicate migration file: ${file}`);
    seen.add(file);
  }

  const sql = await readFile(join(migrationsDir, files[0]), "utf8");

  assertContains(sql, "CREATE TABLE IF NOT EXISTS schema_migrations", "Migration must include the schema_migrations table");

  const expectedTables = [
    "users",
    "schools",
    "platform_memberships",
    "user_credentials",
    "user_sessions",
    "school_memberships",
    "academic_terms",
    "classes",
    "subjects",
    "class_subjects",
    "assessments",
    "assessment_results",
    "report_cards",
    "report_card_entries",
    "class_teachers",
    "students",
    "guardians",
    "student_guardians",
    "student_class_assignments",
    "attendance_events",
    "attendance_records",
    "attendance_record_history",
    "invitations",
    "audits"
  ];

  for (const table of expectedTables) {
    assertContains(sql, `CREATE TABLE IF NOT EXISTS ${table}`, `Expected migration to create table ${table}`);
  }

  const fkChecks = [
    "REFERENCES users(id)",
    "REFERENCES schools(id)",
    "REFERENCES academic_terms(id)",
    "REFERENCES classes(id)",
    "REFERENCES subjects(id)",
    "REFERENCES students(id)",
    "REFERENCES attendance_events(id)",
    "REFERENCES report_cards(id)"
  ];
  for (const check of fkChecks) {
    assertContains(sql, check, `Expected foreign key reference ${check}`);
  }

  assertContains(sql, "UNIQUE INDEX IF NOT EXISTS idx_platform_memberships_active_user_role", "Expected platform membership unique partial index");
  assertContains(sql, "UNIQUE INDEX IF NOT EXISTS idx_school_memberships_active_user_school", "Expected school membership active unique index");
  assertContains(sql, "UNIQUE INDEX IF NOT EXISTS idx_class_teachers_active_assignment", "Expected class teacher active assignment unique index");
  assertContains(sql, "UNIQUE (school_id, class_id, date)", "Expected unique attendance event constraint");
  assertContains(sql, "UNIQUE (event_id, student_id)", "Expected unique attendance record constraint");
  assertContains(sql, "UNIQUE INDEX IF NOT EXISTS idx_invitations_school_pending_email", "Expected pending invitation unique index");

  assertContains(sql, "FOREIGN KEY (class_id, school_id) REFERENCES classes (id, school_id)", "Expected class/school composite foreign key constraint");
  assertContains(sql, "FOREIGN KEY (student_id, school_id) REFERENCES students (id, school_id)", "Expected student/school composite foreign key constraint");
  assertContains(sql, "FOREIGN KEY (guardian_id, school_id) REFERENCES guardians (id, school_id)", "Expected guardian/school composite foreign key constraint");
  assertContains(sql, "FOREIGN KEY (current_class_id, school_id) REFERENCES classes (id, school_id)", "Expected current class composite foreign key on students");

  if (process.env.DATABASE_URL) {
    console.log("DATABASE_URL detected. A real PostgreSQL validation run is possible but is not automatically executed by this test.");
  } else {
    console.log("DATABASE_URL is not configured. Skipping real database execution checks.");
  }

  console.log("DB schema validation passed.");
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
