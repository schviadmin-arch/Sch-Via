import assert from "node:assert/strict";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { Pool } from "pg";
import { loadJsonSource, buildMigrationPlan, validateMigrationPlan } from "../db/migration-utils.mjs";
import { applyMigration } from "../db/migrate-json.mjs";

const __dirname = dirname(fileURLToPath(import.meta.url));
const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) {
  console.error("Skipping PostgreSQL integration tests because DATABASE_URL is not configured.");
  process.exit(0);
}

const pool = new Pool({ connectionString: databaseUrl });

const execFileAsync = promisify(execFile);

async function runCommand(command, args) {
  const { stdout, stderr } = await execFileAsync(command, args, { env: { ...process.env, DATABASE_URL: databaseUrl } });
  return { stdout, stderr };
}

async function resetDatabase() {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const result = await client.query("SELECT quote_ident(tablename) AS table_name FROM pg_tables WHERE schemaname = 'public'");
    for (const { table_name } of result.rows) {
      await client.query(`DROP TABLE IF EXISTS ${table_name} CASCADE`);
    }
    await client.query("COMMIT");
  } finally {
    client.release();
  }
}

async function queryOne(sql, params = []) {
  const client = await pool.connect();
  try {
    const result = await client.query(sql, params);
    return result.rows[0] ? Object.values(result.rows[0])[0] : null;
  } finally {
    client.release();
  }
}

async function getCounts(tables) {
  const counts = {};
  const client = await pool.connect();
  try {
    for (const table of tables) {
      const result = await client.query(`SELECT COUNT(*) AS count FROM ${table}`);
      counts[table] = Number(result.rows[0].count);
    }
  } finally {
    client.release();
  }
  return counts;
}

async function run() {
  await resetDatabase();
  const schemaResult = await runCommand("node", [join(__dirname, "..", "db", "migrate.mjs")]);
  assert.ok(schemaResult.stdout.includes("Migrations applied successfully."), "Schema migration should apply successfully");

  const schemaMigrationsCount = Number(await queryOne("SELECT COUNT(*) FROM schema_migrations"));
  assert.equal(schemaMigrationsCount, 1, "schema_migrations should contain exactly one applied migration");
  const migrationVersion = await queryOne("SELECT version FROM schema_migrations");
  assert.equal(migrationVersion, "0001_initial_schema.sql", "schema_migrations should record the initial SQL file");

  const source = await loadJsonSource(join(__dirname, "..", "data", "schvia.json"));
  const plan = buildMigrationPlan(source);
  const validated = validateMigrationPlan(plan);
  assert.equal(validated.errors.length, 0, `Expected source JSON to validate before applying migration, got errors: ${JSON.stringify(validated.errors)}`);

  const applyResult = await runCommand("node", [join(__dirname, "..", "db", "migrate-json.mjs"), "--apply"]);
  assert.ok(applyResult.stdout.includes("Migration applied successfully."), "JSON migration should apply successfully");

  const expectedCounts = {
    schools: plan.rows.schools.length,
    users: plan.rows.users.length,
    school_memberships: plan.rows.school_memberships.length,
    academic_terms: plan.rows.academic_terms.length,
    classes: plan.rows.classes.length,
    class_teachers: plan.rows.class_teachers.length,
    students: plan.rows.students.length,
    guardians: plan.rows.guardians.length,
    student_guardians: plan.rows.student_guardians.length,
    student_class_assignments: plan.rows.student_class_assignments.length,
    attendance_events: plan.rows.attendance_events.length,
    attendance_records: plan.rows.attendance_records.length,
    invitations: plan.rows.invitations.length,
    audits: plan.rows.audits.length,
  };

  const dbCounts = await getCounts(Object.keys(expectedCounts));
  for (const [table, expected] of Object.entries(expectedCounts)) {
    assert.equal(dbCounts[table], expected, `Expected ${expected} rows in ${table}, found ${dbCounts[table]}`);
  }

  const orphanChecks = [
    ["classes", "SELECT COUNT(*) FROM classes c LEFT JOIN schools s ON c.school_id = s.id WHERE s.id IS NULL"],
    ["school_memberships_school", "SELECT COUNT(*) FROM school_memberships m LEFT JOIN schools s ON m.school_id = s.id WHERE s.id IS NULL"],
    ["school_memberships_user", "SELECT COUNT(*) FROM school_memberships m LEFT JOIN users u ON m.user_id = u.id WHERE u.id IS NULL"],
    ["class_teachers_class", "SELECT COUNT(*) FROM class_teachers ct LEFT JOIN classes c ON ct.class_id = c.id WHERE c.id IS NULL"],
    ["class_teachers_user", "SELECT COUNT(*) FROM class_teachers ct LEFT JOIN users u ON ct.user_id = u.id WHERE u.id IS NULL"],
    ["student_class_assignments_student", "SELECT COUNT(*) FROM student_class_assignments a LEFT JOIN students s ON a.student_id = s.id WHERE s.id IS NULL"],
    ["student_class_assignments_class", "SELECT COUNT(*) FROM student_class_assignments a LEFT JOIN classes c ON a.class_id = c.id WHERE c.id IS NULL"],
    ["student_guardians_student", "SELECT COUNT(*) FROM student_guardians sg LEFT JOIN students s ON sg.student_id = s.id WHERE s.id IS NULL"],
    ["student_guardians_guardian", "SELECT COUNT(*) FROM student_guardians sg LEFT JOIN guardians g ON sg.guardian_id = g.id WHERE g.id IS NULL"],
    ["attendance_events_class", "SELECT COUNT(*) FROM attendance_events e LEFT JOIN classes c ON e.class_id = c.id WHERE c.id IS NULL"],
    ["attendance_records_event", "SELECT COUNT(*) FROM attendance_records r LEFT JOIN attendance_events e ON r.event_id = e.id WHERE e.id IS NULL"],
    ["attendance_records_student", "SELECT COUNT(*) FROM attendance_records r LEFT JOIN students s ON r.student_id = s.id WHERE s.id IS NULL"],
    ["invitations_school", "SELECT COUNT(*) FROM invitations i LEFT JOIN schools s ON i.school_id = s.id WHERE s.id IS NULL"],
    ["audits_school", "SELECT COUNT(*) FROM audits a LEFT JOIN schools s ON a.school_id = s.id WHERE a.school_id IS NOT NULL AND s.id IS NULL"],
    ["audits_actor", "SELECT COUNT(*) FROM audits a LEFT JOIN users u ON a.actor_id = u.id WHERE a.actor_id IS NOT NULL AND u.id IS NULL"],
  ];
  for (const [name, query] of orphanChecks) {
    const count = Number(await queryOne(query));
    assert.equal(count, 0, `${name} should have no orphaned records, found ${count}`);
  }

  const tenantChecks = [
    ["class_teachers_school", "SELECT COUNT(*) FROM class_teachers ct JOIN classes c ON ct.class_id = c.id WHERE ct.school_id != c.school_id"],
    ["student_class_assignments_school", "SELECT COUNT(*) FROM student_class_assignments a JOIN classes c ON a.class_id = c.id JOIN students s ON a.student_id = s.id WHERE a.school_id != c.school_id OR a.school_id != s.school_id"],
    ["student_guardians_school", "SELECT COUNT(*) FROM student_guardians sg JOIN students s ON sg.student_id = s.id WHERE sg.school_id != s.school_id"],
    ["attendance_events_school", "SELECT COUNT(*) FROM attendance_events e JOIN classes c ON e.class_id = c.id WHERE e.school_id != c.school_id"],
    ["attendance_records_school_event", "SELECT COUNT(*) FROM attendance_records r JOIN attendance_events e ON r.event_id = e.id WHERE r.school_id != e.school_id"],
    ["attendance_records_school_student", "SELECT COUNT(*) FROM attendance_records r JOIN students s ON r.student_id = s.id WHERE r.school_id != s.school_id"],
  ];
  for (const [name, query] of tenantChecks) {
    const count = Number(await queryOne(query));
    assert.equal(count, 0, `${name} should have no tenant inconsistency, found ${count}`);
  }

  const rerunResult = await runCommand("node", [join(__dirname, "..", "db", "migrate-json.mjs"), "--apply"]);
  assert.ok(rerunResult.stdout.includes("Migration applied successfully."), "Second JSON migration run should complete successfully");
  const dbCountsAfterRerun = await getCounts(Object.keys(expectedCounts));
  for (const table of Object.keys(expectedCounts)) {
    assert.equal(dbCountsAfterRerun[table], expectedCounts[table], `Rerun should not duplicate rows in ${table}`);
  }

  await resetDatabase();
  await runCommand("node", [join(__dirname, "..", "db", "migrate.mjs")]);

  const invalidPlan = buildMigrationPlan(source);
  invalidPlan.rows.students[0].student_number = null; // violates NOT NULL constraint
  let rollbackError;
  try {
    await applyMigration(invalidPlan);
  } catch (error) {
    rollbackError = error;
  }
  assert.ok(rollbackError, "Invalid migration should fail and rollback");
  const countsAfterRollback = await getCounts(Object.keys(expectedCounts));
  for (const table of Object.keys(expectedCounts)) {
    assert.equal(countsAfterRollback[table], 0, `Failed migration should not leave partial rows in ${table}`);
  }

  console.log("PostgreSQL integration tests passed.");
}

run().then(() => process.exit(0)).catch((error) => {
  console.error(error);
  process.exit(1);
});
