import assert from "node:assert/strict";
import { copyFile, mkdir, rm, readFile, stat } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { randomBytes } from "node:crypto";
import { createPersistence } from "../persistence.mjs";

const tempRoot = join(tmpdir(), `schvia-persistence-${randomBytes(6).toString("hex")}`);
await mkdir(tempRoot, { recursive: true });
const existingPath = join(tempRoot, "existing.json");
const emptyPath = join(tempRoot, "missing.json");

try {
  await copyFile("data/schvia.json", existingPath);

  const existingStore = createPersistence({ dataPath: existingPath });
  const existingData = await existingStore.loadData();
  assert.equal(existingData.school.name, "Northbridge School");
  assert.ok(Array.isArray(existingData.users));
  assert.ok(existingData.users.some((user) => user.role === "principal"));

  const originalCount = existingData.students.length;
  existingData.students.push({
    id: "student-test",
    studentId: "NBS-999",
    name: "Test Student",
    gender: "Not specified",
    classId: existingData.classes[0].id,
    guardian: "Test Guardian",
    status: "enrolled",
    schoolId: existingData.school.id,
  });
  await existingStore.saveData();

  const reloadedStore = createPersistence({ dataPath: existingPath });
  const reloadedData = await reloadedStore.loadData();
  assert.equal(reloadedData.students.length, originalCount + 1);
  assert.ok(reloadedData.students.some((student) => student.studentId === "NBS-999"));

  const raw = await readFile(existingPath, "utf8");
  const parsed = JSON.parse(raw);
  assert.equal(parsed.students.length, originalCount + 1);
  assert.equal(parsed.school.name, "Northbridge School");

  const missingStore = createPersistence({ dataPath: emptyPath });
  const missingData = await missingStore.loadData();
  assert.equal(missingData.school.name, "Northbridge School");
  assert.ok(await stat(emptyPath));

  console.log("Persistence boundary tests passed: load, save, reload, initialize, and format preservation.");
} finally {
  await rm(tempRoot, { recursive: true, force: true });
}
