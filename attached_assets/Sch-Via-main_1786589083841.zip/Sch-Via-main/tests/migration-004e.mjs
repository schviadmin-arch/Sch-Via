import assert from "node:assert/strict";
import { buildMigrationPlan, validateMigrationPlan, buildMigrationReport } from "../db/migration-utils.mjs";

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function makeBaseSource() {
  return {
    school: { id: "school-a", name: "School A", term: "Term 1", createdAt: "2024-01-01T00:00:00.000Z" },
    schools: [
      { id: "school-a", name: "School A", term: "Term 1", createdAt: "2024-01-01T00:00:00.000Z" },
      { id: "school-b", name: "School B", term: "Term 2", createdAt: "2024-01-02T00:00:00.000Z" },
    ],
    users: [
      { id: "user-1", email: "alice@example.com", name: "Alice", role: "teacher", schoolId: "school-a", createdAt: "2024-01-01T00:00:00.000Z" },
      { id: "user-2", email: "bob@example.com", name: "Bob", role: "principal", schoolId: "school-b", createdAt: "2024-01-02T00:00:00.000Z" },
    ],
    memberships: [
      { id: "membership-1", userId: "user-1", schoolId: "school-a", role: "teacher", status: "active", createdAt: "2024-01-01T00:00:00.000Z" },
      { id: "membership-2", userId: "user-2", schoolId: "school-b", role: "principal", status: "active", createdAt: "2024-01-02T00:00:00.000Z" },
    ],
    classes: [
      { id: "class-1", name: "Math", year: "Term 1", teacherIds: ["user-1"], schoolId: "school-a", createdAt: "2024-01-01T00:00:00.000Z" },
      { id: "class-2", name: "Science", year: "Term 2", teacherIds: ["user-2"], schoolId: "school-b", createdAt: "2024-01-02T00:00:00.000Z" },
    ],
    students: [
      { id: "student-1", studentId: "S001", name: "Student One", classId: "class-1", guardian: "Guardian One", schoolId: "school-a", createdAt: "2024-01-01T00:00:00.000Z" },
      { id: "student-2", studentId: "S002", name: "Student Two", classId: "class-2", guardian: "Guardian Two", schoolId: "school-b", createdAt: "2024-01-02T00:00:00.000Z" },
    ],
    attendance: {
      "2024-01-01:class-1:student-1": { date: "2024-01-01", classId: "class-1", studentId: "student-1", status: "present", recordedBy: "user-1", recordedAt: "2024-01-01T08:00:00.000Z" },
    },
    invitations: [
      { id: "invite-1", email: "invitee@example.com", name: "Invitee", schoolId: "school-a", role: "teacher", status: "pending", invitedAt: "2024-01-01T00:00:00.000Z" },
    ],
    audit: [
      { id: "audit-1", actorId: "user-1", actorName: "Alice", schoolId: "school-a", action: "created class", entityType: "class", entityId: "class-1", at: "2024-01-01T00:00:00.000Z" },
    ],
  };
}

function validateDeterministic(source) {
  const plan1 = buildMigrationPlan({ raw: clone(source) });
  const plan2 = buildMigrationPlan({ raw: clone(source) });
  assert.equal(JSON.stringify(plan1), JSON.stringify(plan2), "Repeated planning must produce identical migration plans");
}

function validateSourceIntact(source) {
  const original = clone(source);
  buildMigrationPlan({ raw: clone(source) });
  assert.deepEqual(source, original, "Source JSON must not be mutated by migration planning");
}

function runFixture(source) {
  const plan = buildMigrationPlan({ raw: clone(source) });
  const validated = validateMigrationPlan(plan);
  const report = buildMigrationReport(validated, { sourcePath: "fixture", dryRun: true });
  return { plan, validated, report };
}

function assertRejected(report, expectedErrorSubstr) {
  assert.equal(report.success, false, "Expected migration to be rejected");
  assert.equal(report.status, "NOT READY");
  assert.ok(report.errors.some((error) => error.message.includes(expectedErrorSubstr)), `Expected error containing '${expectedErrorSubstr}'`);
}

function assertAccepted(report) {
  assert.equal(report.success, true, "Expected migration to be accepted");
  assert.equal(report.status, "READY");
}

function testEmptyCollections() {
  const source = { school: { id: "school-empty", name: "Empty School", term: "Term X" } };
  const { report } = runFixture(source);
  assertAccepted(report);
  assert.equal(report.sourceCounts.schools, 1);
  assert.equal(report.sourceCounts.users, 0);
  assert.equal(report.sourceCounts.classes, 0);
  assert.equal(report.counts.users, 0);
}

function testDuplicateUserEmail() {
  const source = makeBaseSource();
  source.users.push({ id: "user-3", email: "alice@example.com", name: "Alice Duplicate", role: "teacher", schoolId: "school-a" });
  const { report } = runFixture(source);
  assertRejected(report, "Duplicate user email alice@example.com");
}

function testDuplicateStudentNumber() {
  const source = makeBaseSource();
  source.students.push({ id: "student-duplicate", studentId: "S001", name: "Student Duplicate", classId: "class-1", guardian: "Guardian One", schoolId: "school-a" });
  const { report } = runFixture(source);
  assertRejected(report, "Duplicate student_number S001");
}

function testConflictingRole() {
  const source = makeBaseSource();
  source.memberships[0].role = "principal";
  const { report } = runFixture(source);
  assertRejected(report, "Conflicting role for user user-1");
}

function testCrossSchoolClassAssignment() {
  const source = makeBaseSource();
  source.students[0].schoolId = "school-b";
  const { report } = runFixture(source);
  assertRejected(report, "Student class class-1 belongs to a different school");
}

function testInvalidTeacher() {
  const source = makeBaseSource();
  source.classes[0].teacherIds = ["user-2"];
  const { report } = runFixture(source);
  assertRejected(report, "Teacher user-2 belongs to school school-b but class class-1 belongs to school");
}

function testMalformedAttendance() {
  const source = makeBaseSource();
  source.attendance["bad"] = { date: "2024-13-01", classId: "class-1", studentId: "student-1" };
  const { report } = runFixture(source);
  assertRejected(report, "Attendance entry has invalid date");
}

function testAttendanceUnknownClassReference() {
  const source = makeBaseSource();
  source.attendance["unknown-class"] = { date: "2024-01-02", classId: "class-x", studentId: "student-1", status: "present" };
  const { report } = runFixture(source);
  assertRejected(report, "Attendance entry references unknown class class-x");
}

function testAttendanceCrossSchool() {
  const source = makeBaseSource();
  source.attendance["cross-school"] = { date: "2024-01-02", classId: "class-1", studentId: "student-2", status: "present" };
  const { report } = runFixture(source);
  assertRejected(report, "Attendance student student-2 and class class-1 belong to different schools.");
}

function testDuplicateMembership() {
  const source = makeBaseSource();
  source.memberships.push({ id: "membership-duplicate", userId: "user-1", schoolId: "school-a", role: "teacher", status: "active", createdAt: "2024-01-03T00:00:00.000Z" });
  const { report } = runFixture(source);
  assertRejected(report, "Duplicate membership for user user-1 and school school-a.");
}

function testIssueCategorization() {
  const source = makeBaseSource();
  source.users.push({ id: "user-3", email: "alice@example.com", name: "Alice Duplicate", role: "teacher", schoolId: "school-a" });
  source.students.push({ id: "student-duplicate", studentId: "S001", name: "Student Duplicate", classId: "class-1", guardian: "Guardian One", schoolId: "school-a" });
  const { report } = runFixture(source);
  assertRejected(report, "Duplicate user email alice@example.com");
  assert.equal(report.errorTypes.duplicate_conflict > 0, true);
  assert.equal(report.errorTypes.tenant_violation >= 0, true);
}

function testDuplicateInvitation() {
  const source = makeBaseSource();
  source.invitations.push({ id: "invite-2", email: "invitee@example.com", name: "Invitee Duplicate", schoolId: "school-a", role: "teacher", status: "pending" });
  const { report } = runFixture(source);
  assertRejected(report, "Duplicate pending invitation for invitee@example.com");
}

function testOrphanReferences() {
  const source = makeBaseSource();
  source.memberships.push({ id: "membership-orphan", userId: "user-missing", schoolId: "school-a", role: "teacher", status: "active" });
  source.invitations.push({ id: "invite-missing", email: "orphan@example.com", name: "Orphan", schoolId: "school-missing", role: "teacher", status: "pending" });
  const { report } = runFixture(source);
  assertRejected(report, "Membership references unknown user user-missing");
  assert.ok(report.errors.some((error) => error.message.includes("Invitation references unknown school")));
}

function testDeterministicBehavior() {
  const source = makeBaseSource();
  validateDeterministic(source);
  validateSourceIntact(source);
}

function main() {
  testEmptyCollections();
  testDuplicateUserEmail();
  testDuplicateStudentNumber();
  testConflictingRole();
  testCrossSchoolClassAssignment();
  testInvalidTeacher();
  testMalformedAttendance();
  testDuplicateInvitation();
  testOrphanReferences();
  testDeterministicBehavior();
  console.log("004E migration validation tests passed.");
}

main();
