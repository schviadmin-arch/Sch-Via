import assert from "node:assert/strict";
import { copyFile, rm } from "node:fs/promises";
import { spawn } from "node:child_process";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { randomBytes } from "node:crypto";

const port = 5131;
const dataPath = join(tmpdir(), `schvia-e2e-${randomBytes(6).toString("hex")}.json`);
await copyFile("data/schvia.json", dataPath);
const server = spawn(process.execPath, ["serve.mjs"], {
  env: { ...process.env, PORT: String(port), NODE_ENV: "test", SESSION_SECRET: "e2e-secret", DATA_PATH: dataPath },
  stdio: ["ignore", "pipe", "pipe"],
});
let output = "";
server.stdout.on("data", (chunk) => { output += chunk; });
server.stderr.on("data", (chunk) => { output += chunk; });
const baseUrl = `http://127.0.0.1:${port}`;

async function waitForServer() {
  for (let attempt = 0; attempt < 50; attempt += 1) {
    try {
      if ((await fetch(`${baseUrl}/health`)).ok) return;
    } catch {
      // The child process may need another moment to bind.
    }
    await new Promise((resolve) => setTimeout(resolve, 40));
  }
  throw new Error(`Server did not start:\n${output}`);
}

async function request(path, options = {}) {
  const response = await fetch(`${baseUrl}${path}`, {
    ...options,
    headers: { ...(options.body ? { "Content-Type": "application/json" } : {}), ...(options.headers || {}) },
  });
  const payload = await response.json().catch(() => ({}));
  return { response, payload };
}

function cookieFrom(response) {
  return response.headers.get("set-cookie")?.split(";")[0];
}

try {
  await waitForServer();
  const register = await request("/api/auth/register", {
    method: "POST",
    body: JSON.stringify({ name: "Nia Founder", email: "nia@bright.edu", password: "strongpass1", schoolName: "Bright Future School", location: "Kumasi, Ghana" }),
  });
  assert.equal(register.response.status, 201, JSON.stringify(register.payload));
  const principalCookie = cookieFrom(register.response);
  assert.ok(principalCookie);

  const principalState = await request("/api/state", { headers: { Cookie: principalCookie } });
  assert.equal(principalState.response.status, 200);
  assert.equal(principalState.payload.school.name, "Bright Future School");
  assert.equal(principalState.payload.currentUser.role, "principal");

  const invitation = await request("/api/users", {
    method: "POST",
    headers: { Cookie: principalCookie },
    body: JSON.stringify({ name: "Teacher One", email: "teacher@bright.edu", role: "teacher" }),
  });
  assert.equal(invitation.response.status, 201, JSON.stringify(invitation.payload));
  const code = invitation.payload.invitations[0].code;
  assert.ok(code);

  const accepted = await request("/api/auth/accept-invite", {
    method: "POST",
    body: JSON.stringify({ code, name: "Teacher One", email: "teacher@bright.edu", password: "teacherpass1" }),
  });
  assert.equal(accepted.response.status, 201, JSON.stringify(accepted.payload));
  const teacherCookie = cookieFrom(accepted.response);
  assert.ok(teacherCookie);

  const teacherState = await request("/api/state", { headers: { Cookie: teacherCookie } });
  assert.equal(teacherState.response.status, 200);
  assert.equal(teacherState.payload.currentUser.role, "teacher");
  assert.equal(teacherState.payload.classes.length, 0);
  assert.equal(teacherState.payload.students.length, 0);

  const classCreated = await request("/api/classes", {
    method: "POST",
    headers: { Cookie: principalCookie },
    body: JSON.stringify({ name: "Year 1", teacherId: teacherState.payload.currentUser.id }),
  });
  assert.equal(classCreated.response.status, 201, JSON.stringify(classCreated.payload));
  const assignedTeacherState = await request("/api/state", { headers: { Cookie: teacherCookie } });
  assert.equal(assignedTeacherState.payload.classes.length, 1);
  assert.equal(assignedTeacherState.payload.classes[0].name, "Year 1");

  const secondOwner = await request("/api/auth/register", {
    method: "POST",
    body: JSON.stringify({ name: "Other Owner", email: "owner@other.edu", password: "otherpass1", schoolName: "Other School" }),
  });
  assert.equal(secondOwner.response.status, 201, JSON.stringify(secondOwner.payload));
  const otherState = await request("/api/state", { headers: { Cookie: cookieFrom(secondOwner.response) } });
  assert.equal(otherState.payload.school.name, "Other School");
  assert.equal(otherState.payload.students.length, 0);
  assert.equal(otherState.payload.classes.length, 0);

  console.log("Real-user E2E passed: workspace creation, password session, invite acceptance, teacher scope, assignment, and tenant isolation.");
} finally {
  server.kill("SIGTERM");
  await rm(dataPath, { force: true });
}