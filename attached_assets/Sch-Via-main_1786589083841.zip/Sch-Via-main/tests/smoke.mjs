import assert from "node:assert/strict";
import { spawn } from "node:child_process";

const port = 5127;
const baseUrl = `http://127.0.0.1:${port}`;
const server = spawn(process.execPath, ["serve.mjs"], {
  env: { ...process.env, PORT: String(port), NODE_ENV: "test", SESSION_SECRET: "smoke-test-secret" },
  stdio: ["ignore", "pipe", "pipe"],
});

let output = "";
server.stdout.on("data", (chunk) => { output += chunk; });
server.stderr.on("data", (chunk) => { output += chunk; });

async function waitForServer() {
  for (let attempt = 0; attempt < 40; attempt += 1) {
    try {
      const response = await fetch(`${baseUrl}/health`);
      if (response.ok) return;
    } catch {
      // The child process may need another moment to bind.
    }
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
  throw new Error(`Server did not start:\n${output}`);
}

async function request(path, options = {}) {
  const response = await fetch(`${baseUrl}${path}`, {
    ...options,
    headers: { ...(options.body ? { "Content-Type": "application/json" } : {}), ...(options.headers || {}) },
  });
  const payload = await response.json().catch(() => ({}));
  return { response, payload };
}

function cookieFrom(response) {
  return response.headers.get("set-cookie")?.split(";")[0];
}

try {
  await waitForServer();

  const health = await request("/health");
  assert.equal(health.response.status, 200);
  assert.equal(health.payload.ok, true);
  assert.match(health.response.headers.get("x-request-id"), /^[a-f0-9]{16}$/);

  const ready = await request("/ready");
  assert.equal(ready.response.status, 200);
  assert.equal(ready.payload.ready, true);

  const unauthenticated = await request("/api/state");
  assert.equal(unauthenticated.response.status, 401);
  assert.equal(unauthenticated.payload.error, "Sign in required");
  assert.ok(unauthenticated.payload.requestId);

  const principalLogin = await request("/api/auth/login", {
    method: "POST",
    body: JSON.stringify({ role: "principal" }),
  });
  assert.equal(principalLogin.response.status, 200);
  const principalCookie = cookieFrom(principalLogin.response);
  assert.ok(principalCookie);

  const principalState = await request("/api/state", { headers: { Cookie: principalCookie } });
  assert.equal(principalState.response.status, 200);
  assert.equal(principalState.payload.currentUser.role, "principal");
  assert.equal(principalState.payload.students.length, 5);

  const teacherLogin = await request("/api/auth/login", {
    method: "POST",
    body: JSON.stringify({ role: "teacher" }),
  });
  assert.equal(teacherLogin.response.status, 200);
  const teacherCookie = cookieFrom(teacherLogin.response);
  assert.ok(teacherCookie);

  const teacherState = await request("/api/state", { headers: { Cookie: teacherCookie } });
  assert.equal(teacherState.response.status, 200);
  assert.equal(teacherState.payload.currentUser.role, "teacher");
  assert.deepEqual(teacherState.payload.classes.map((item) => item.name), ["Primary 5"]);
  assert.equal(teacherState.payload.students.length, 4);

  const forbidden = await request("/api/classes", {
    method: "POST",
    headers: { Cookie: teacherCookie },
    body: JSON.stringify({ name: "Should Not Exist" }),
  });
  assert.equal(forbidden.response.status, 403);

  const invalidAttendance = await request("/api/attendance", {
    method: "POST",
    headers: { Cookie: teacherCookie },
    body: JSON.stringify({
      classId: "class-primary-5",
      date: "not-a-date",
      records: [{ studentId: "student-ama", status: "present" }],
    }),
  });
  assert.equal(invalidAttendance.response.status, 400);
  assert.match(invalidAttendance.payload.error, /valid YYYY-MM-DD/);

  const invalidContentType = await request("/api/school", {
    method: "POST",
    headers: { Cookie: teacherCookie, "Content-Type": "text/plain" },
    body: "not-json",
  });
  assert.equal(invalidContentType.response.status, 415);

  const expiredProduction = spawn(process.execPath, ["serve.mjs"], {
    env: { ...process.env, PORT: String(port + 1), NODE_ENV: "production", SESSION_SECRET: "" },
    stdio: ["ignore", "pipe", "pipe"],
  });
  const productionExit = await new Promise((resolve) => {
    const timer = setTimeout(() => resolve(null), 1000);
    expiredProduction.once("exit", (code) => {
      clearTimeout(timer);
      resolve(code);
    });
  });
  assert.equal(productionExit, 1);

  console.log("Smoke checks passed: health, readiness, auth, role filtering, authorization, validation, and production secret protection.");
} finally {
  server.kill("SIGTERM");
}