import assert from "node:assert/strict";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { loadJsonSource, buildMigrationPlan, validateMigrationPlan, buildMigrationReport } from "../db/migration-utils.mjs";

const __dirname = fileURLToPath(new URL(".", import.meta.url));
const sourcePath = join(__dirname, "..", "data", "schvia.json");

async function main() {
  const source = await loadJsonSource(sourcePath);
  assert.equal(source.sourcePath, sourcePath, "Source path should resolve correctly");
  assert.ok(source.raw, "Parsed JSON source should be returned");

  const plan = buildMigrationPlan(source);
  const validated = validateMigrationPlan(plan);
  const report = buildMigrationReport(validated, { sourcePath, dryRun: true });

  assert.equal(report.success, true, `Expected migration plan to be valid, got errors: ${JSON.stringify(validated.errors, null, 2)}`);
  assert.ok(report.counts.schools >= 1, "Expected at least one school in migration plan");
  assert.ok(report.counts.users >= 1, "Expected at least one user in migration plan");
  assert.ok(report.counts.classes >= 1, "Expected at least one class in migration plan");
  assert.ok(report.counts.students >= 1, "Expected at least one student in migration plan");

  const duplicateUser = report.counts.users === report.sourceCounts.users;
  assert.ok(duplicateUser, "Expected user count to match source users when no duplicates exist");

  console.log("Migration utility dry-run validation passed.");
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
