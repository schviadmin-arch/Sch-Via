# SCHVIA Migration Plan

## 1. Current persistence model

The current application persists all operational data in a single JSON file:

- `data/schvia.json`

The runtime data shape is loaded at server startup and held in memory in `serve.mjs` as `data`.

Current persisted entities:

- `school` / normalized `schools[]`
- `users[]`
- `memberships[]`
- `classes[]`
- `students[]`
- `attendance` object keyed by `${date}:${classId}:${studentId}`
- `invitations[]`
- `audit[]`

The file is written atomically by `data-store.mjs` using a temporary file and rename.

### Current persistence flows

- `/api/auth/register` creates a new school, principal user, membership, and audit event.
- `/api/auth/login-email` authenticates a user against `data.users.*.passwordHash`.
- `/api/auth/accept-invite` creates a new user and membership, accepts an invitation.
- `/api/school` updates the school record.
- `/api/users` creates a pending invitation.
- `/api/classes` creates a class record and stores `teacherIds`.
- `/api/students` creates a student record with `classId` and free-text `guardian`.
- `/api/attendance` writes attendance records directly into `data.attendance`.
- Audit records are prepended to `data.audit` and truncated to 100 items.

### Current authorization model

- Sessions are in-memory in `serve.mjs` and signed via `schvia_session` cookie.
- The `requireRole()` helper enforces `principal`, `admin`, and `teacher` route access.
- `membershipFor(session)` validates active school membership for the session's `userId` and `schoolId`.
- `visibleState(session)` filters school data by `schoolId` and teacher assignment.

### Current tenant model

- Every runtime record is normalized to include `schoolId` before use.
- `data.schedules` does not exist; `schoolId` is present on `classes`, `students`, `invitations`, `audit`, and attendance records.
- `schoolFor(session)` resolves the active school from session state.

## 2. Target relational model

The migration target is the relational schema documented in `SCHVIA_DATABASE_DESIGN.md`.

Key target entities:

- `users`
- `platform_memberships`
- `user_credentials`
- `user_sessions`
- `schools`
- `school_memberships`
- `academic_terms`
- `classes`
- `class_teachers`
- `students`
- `guardians`
- `student_guardians`
- `student_class_assignments`
- `attendance_events`
- `attendance_records`
- `attendance_record_history`
- `invitations`
- `audits`
- `subjects`, `class_subjects`, `assessments`, `assessment_results`, `report_cards`, `report_card_entries`

The future model explicitly separates identity from school membership and platform membership, and it structures attendance as an event/record model rather than a denormalized composite object.

## 3. Entity mapping matrix

| Current JSON structure | Current server operations | Future table(s) | Migration transformation | Required foreign keys | Tenant checks | Risk / notes |
|---|---|---|---|---|---|---|
| `school` / `schools[]` | `/api/auth/register`, `/api/school` | `schools` | Migrate root school and normalized schools; preserve `name`, `location`, `term` → `current_term` | None | `school_id` must match session school or membership school | `term` text becomes term record metadata; no loss if stored as text temporarily |
| `users[]` | `/api/auth/register`, `/api/auth/login-email`, `/api/auth/accept-invite` | `users` + `user_credentials` + `school_memberships` | Split identity from credential; preserve `email`, `name`, `status`, `createdAt`; assign school membership role from existing memberships | `users.id`, `user_credentials.user_id`, `school_memberships.user_id` | Verify membership.school_id matches user.school_id and active membership exists | `classIds` is redundant and has no direct relational destination; infer from `classes.teacherIds` |
| `passwordHash` on user | auth routes | `user_credentials` | Move password hash into credentials table; preserve algorithm metadata conceptually | `REFERENCES users(id)` | login must verify credential user_id and `users.status` | no loss if hash preserved intact |
| `memberships[]` | `visibleState`, login session creation | `school_memberships` | Migrate each membership row; preserve role/status/createdAt | `school_memberships.user_id`, `school_memberships.school_id` | validate session membership at auth and access time | current `users.role` duplicates role but membership is authoritative; preserve both in target membership |
| implicit platform role | none in current store | `platform_memberships` | No direct current source; seed from platform admin decisions or initial founder users | `platform_memberships.user_id` | platform authorization must not infer from school roles | this is a new entity and cannot be migrated from JSON; it requires explicit configuration |
| in-memory sessions | `getSession`, auth routes | `user_sessions` | Session persistence may start with a clean sign-in boundary; old sessions are lost if not captured | `user_sessions.user_id`, `user_sessions.school_id` | session school_id must match membership school_id | session loss on migration is acceptable if cutover is controlled; preserve auth semantics by requiring fresh sign-in |
| `school.term`, `class.year` | `/api/school`, `/api/classes` | `academic_terms` | Create term records from existing text fields; assign classes to terms | `classes.academic_term_id`, `academic_terms.school_id` | match class term to school term, reject cross-school names | ambiguous year text may require manual review when a school has multiple inconsistent class years |
| `classes[]` | `/api/classes`, `visibleState`, teacher assignment checks | `classes` + `class_teachers` | Migrate classes and expand `teacherIds` into assignment rows; preserve `name`, `year`, `schoolId` | `classes.school_id`, `class_teachers.class_id`, `class_teachers.user_id` | verify class belongs to school; teacher assignment belongs to same school and active membership | if class teacher IDs refer to missing or inactive users, migration must handle gracefully and preserve class while dropping invalid assignments |
| `students[]` | `/api/students`, `/api/attendance`, `visibleState` | `students` + `student_class_assignments` | Migrate students; preserve `studentId`→`student_number`, `name`, `gender`, `status`, `classId`; create current assignment rows and optional history | `students.school_id`, `students.current_class_id`, `student_class_assignments.student_id`, `student_class_assignments.class_id`, `student_class_assignments.school_id` | enforce student.school_id = class.school_id | risk: no prior class assignment history exists beyond current `classId` |
| `guardian` text on student | `/api/students` payload | `guardians` + `student_guardians` | Create guardians from free-text names; preserve string as `name`, tie one guardian row per unique school/name | `guardians.school_id`, `student_guardians.student_id`, `student_guardians.guardian_id`, `student_guardians.school_id` | require guardian school = student school | loss of relationship detail and missing contact info; if multiple students share a guardian name, migration may collapse them unless deduplicated carefully |
| `attendance` object | `/api/attendance`, `visibleState` | `attendance_events` + `attendance_records` + optional `attendance_record_history` | Convert each current attendance record to event+record; group by `date`+`classId`; preserve `status`, `recordedBy`, `recordedAt`, `updatedAt` | `attendance_events.school_id`, `attendance_events.class_id`, `attendance_events.recorded_by`, `attendance_records.event_id`, `attendance_records.student_id` | validate event.class.school_id = school_id, record.student_id belongs to class at date | historical change history is lost; existing object contains only latest records and no past versions |
| attendance duplicates (composite key) | `/api/attendance` writes by key | `attendance_events` unique per class/date and `attendance_records` unique per student/event | preserve deduplication semantics through relational unique constraints | `UNIQUE(school_id,class_id,date)`, `UNIQUE(event_id,student_id)` | reject or update duplicate submissions based on event identity | current JSON may already overwrite earlier modifications; no additional loss beyond existing behavior |
| `invitations[]` | `/api/users`, `/api/auth/accept-invite`, `visibleState` | `invitations` | Migrate invitation rows; preserve `code`, `role`, `status`, `invitedAt`, `acceptedAt`, `acceptedUserId` | `invitations.school_id`, `invitations.invited_by`, `invitations.accepted_user_id` | ensure invitation.school_id matches accepting user.school_id | no existing expiry/revocation metadata; future schema can start with `expires_at=NULL` and `revoked_at=NULL` |
| `audit[]` | `audit()` helper in many mutating routes | `audits` | Migrate audit entries; preserve `actorId`, `actorName`, `schoolId`, `action`, `detail`, `at` | `audits.actor_id`, `audits.school_id` | audit school_id must match operation school | current system truncates to 100 items; migration should preserve current list only, not earlier evicted audit history |

## 4. Detailed entity migration analysis

### 4.1 Schools

Current JSON structure:
- `data.school`
- `data.schools[]` after normalization by `data-store.mjs`

Current operations:
- `/api/auth/register` adds a school object and new principal.
- `/api/school` updates `name`, `location`, `term`.

Future table:
- `schools`

Migration transformation:
- Create `schools` rows for each item in `data.schools`.
- Map `school.term` to `schools.current_term` or create an initial `academic_terms` row.

Required foreign keys:
- None directly, but child tables will reference `schools.id`.

Tenant checks:
- school updates must be restricted to the matching session school.
- no record should be written with a school_id that does not exist.

Data risk:
- `term` is free-text; future normalized `academic_terms` may require review.

### 4.2 Users

Current JSON structure:
- `data.users[]` with `id`, `name`, `email`, `role`, `status`, `schoolId`, `classIds`, `passwordHash`, `createdAt`

Current operations:
- `/api/auth/register` inserts a new user.
- `/api/auth/login-email` reads user by email and verifies password.
- `/api/auth/accept-invite` creates a new user.
- `visibleState()` reads users filtered by school.

Future tables:
- `users`
- `user_credentials`
- `school_memberships`

Migration transformation:
- Migrate each user to `users` with identity fields.
- Move `passwordHash` into `user_credentials`.
- Migrate memberships separately.
- Preserve `createdAt` in `users.created_at` and `user_credentials.created_at`.

Required foreign keys:
- `user_credentials.user_id -> users.id`
- `school_memberships.user_id -> users.id`

Tenant checks:
- a user’s `school_id` must be consistent with their membership school_id.
- a user should only be returned in visible state for the active session school.

Data risk:
- `classIds` has no direct destination; infer teacher assignments from `classes.teacherIds`.
- if a user exists without a matching active membership, the user should still migrate but must be disabled or reconciled.

### 4.3 Credentials

Current JSON structure:
- `passwordHash` field on user objects.

Current operations:
- `verifyPassword` compares login password to `user.passwordHash`.

Future table:
- `user_credentials`

Migration transformation:
- Create a `user_credentials` row for each existing user with a `passwordHash`.
- Keep hash value unchanged and attach an algorithm metadata field conceptually.

Required foreign keys:
- `user_credentials.user_id -> users.id`

Tenant checks:
- credentials verify against the user identity; no tenant-specific constraints are needed beyond user existence.

Data risk:
- none if the hash is migrated intact.

### 4.4 Memberships

Current JSON structure:
- `data.memberships[]` with `id`, `userId`, `schoolId`, `role`, `status`, `createdAt`

Current operations:
- `normalizeData()` ensures memberships exist for seeded users.
- login and state read membership data to assign session role and expose user role.

Future table:
- `school_memberships`

Migration transformation:
- Directly copy membership rows.
- Preserve `role`, `status`, and `created_at`.
- Add `accepted_at`, `ended_at` as `NULL` if absent.

Required foreign keys:
- `school_memberships.user_id -> users.id`
- `school_memberships.school_id -> schools.id`

Tenant checks:
- only active memberships may be used for auth.
- any role lookup must include `school_id` matching the current tenant.

Data risk:
- none significant; just preserve current membership semantics.

### 4.5 Platform memberships

Current JSON structure:
- none.

Current operations:
- none.

Future table:
- `platform_memberships`

Migration transformation:
- No direct migration source from JSON.
- Seed platform-level rows as a separate step, not by transformation of existing data.
- Existing school principals may be provisioned as platform founders or operators based on business policy.

Required foreign keys:
- `platform_memberships.user_id -> users.id`

Tenant checks:
- platform roles are independent of school roles and should not be inferred from them.

Data risk:
- no JSON data to migrate; the risk is in operational configuration rather than data loss.

### 4.6 Sessions

Current structure:
- runtime-only `Map` of session objects in `serve.mjs`.

Current operations:
- `getSession`, `signSession`, login routes, logout.

Future table:
- `user_sessions`

Migration transformation:
- There is no durable persisted session state to migrate.
- The migration plan should accept a fresh sign-in boundary when moving to relational session storage.

Required foreign keys:
- `user_sessions.user_id -> users.id`
- `user_sessions.school_id -> schools.id`

Tenant checks:
- session school_id must match the school membership and active role.

Data risk:
- live sessions will be invalidated during cutover unless a capture layer is added.

### 4.7 Academic terms

Current JSON structure:
- `school.term`
- `classes[].year`

Current operations:
- `/api/school` updates `school.term`.
- `/api/classes` uses `body.year` and persists the text.

Future table:
- `academic_terms`

Migration transformation:
- Create one or more academic term records from `school.term` and each distinct class `year`.
- Map `classes.year` into `classes.academic_term_id`.
- If the school has a single coherent term string, create a single active term row.

Required foreign keys:
- `classes.academic_term_id -> academic_terms.id`
- `academic_terms.school_id -> schools.id`

Tenant checks:
- each class term must belong to the same school.

Data risk:
- ambiguous or inconsistent year labels may require manual reconciliation.

### 4.8 Classes

Current JSON structure:
- `data.classes[]` with `id`, `schoolId`, `name`, `year`, `teacherIds`

Current operations:
- `/api/classes` creates a class and optionally validates `teacherId`.
- `visibleState()` filters classes by school and teacher assignment.
- `/api/attendance` validates class existence and teacher assignment.

Future tables:
- `classes`
- `class_teachers`

Migration transformation:
- Migrate `classes` rows.
- For each `teacherId` in `teacherIds`, add a `class_teachers` row with `assigned_at`.
- Preserve `school_id`, `name`, and the term reference.

Required foreign keys:
- `classes.school_id -> schools.id`
- `class_teachers.class_id -> classes.id`
- `class_teachers.user_id -> users.id`

Tenant checks:
- class operations must enforce `classes.school_id = session.schoolId`.
- teacher assignments must belong to active teachers in the same school.

Data risk:
- invalid or stale `teacherIds` references may need reconciliation.

### 4.9 Students

Current JSON structure:
- `data.students[]` with `id`, `studentId`, `name`, `gender`, `classId`, `guardian`, `status`, `schoolId`

Current operations:
- `/api/students` validates class membership and unique `studentId`.
- `visibleState()` filters students by school and assigned class for teachers.
- `/api/attendance` validates student membership in the selected class.

Future tables:
- `students`
- `student_class_assignments`

Migration transformation:
- Migrate `students` records.
- Preserve `studentId` as `student_number`.
- Set `current_class_id` from `classId`.
- Create an active `student_class_assignments` row for the existing class.

Required foreign keys:
- `students.school_id -> schools.id`
- `students.current_class_id -> classes.id`
- `student_class_assignments.student_id -> students.id`
- `student_class_assignments.class_id -> classes.id`
- `student_class_assignments.school_id -> schools.id`

Tenant checks:
- a student must belong to the same school as the assigned class.

Data risk:
- no historical class assignments exist beyond current `classId`.
- if a student's current class does not exist, migration must either reject or assign `NULL` and flag for review.

### 4.10 Guardians

Current JSON structure:
- free-text `guardian` field on each student

Current operations:
- `/api/students` stores guardian text.
- the guardian value is displayed in student lists.

Future tables:
- `guardians`
- `student_guardians`

Migration transformation:
- Create guardian rows for unique `guardian` names per school.
- Link each student to the corresponding guardian row.
- Use `relationship` and contact fields as `NULL` unless data exists.

Required foreign keys:
- `guardians.school_id -> schools.id`
- `student_guardians.student_id -> students.id`
- `student_guardians.guardian_id -> guardians.id`
- `student_guardians.school_id -> schools.id`

Tenant checks:
- both guardian and student must share the same school.

Data risk:
- the free-text field may not uniquely identify a real guardian.
- if multiple students share the same guardian name, deduplication may be incorrect.
- no email or phone data is available.

### 4.11 Student guardians

Current JSON structure:
- no dedicated link table

Current operations:
- none beyond the free-text guardian on student.

Future tables:
- `student_guardians`

Migration transformation:
- For each student, create one active guardian relationship row.
- If more than one student has the same guardian name in the same school, optionally reuse the same guardian row.

Required foreign keys:
- `student_guardians.student_id -> students.id`
- `student_guardians.guardian_id -> guardians.id`
- `student_guardians.school_id -> schools.id`

Tenant checks:
- enforce `student_guardians.school_id` equals the student and guardian school.

Data risk:
- guardian relationship semantics are inferred from text and are not fully recoverable.

### 4.12 Student class assignments

Current JSON structure:
- `students[].classId`

Current operations:
- `/api/students` creates a student with `classId`.
- attendance and teacher filtering use current class membership only.

Future table:
- `student_class_assignments`

Migration transformation:
- Create current assignment rows for existing student class membership.
- Set `is_current = true`.

Required foreign keys:
- `student_class_assignments.student_id -> students.id`
- `student_class_assignments.class_id -> classes.id`
- `student_class_assignments.school_id -> schools.id`

Tenant checks:
- student and class school must match.

Data risk:
- no prior assignment history exists; only current assignment is preserved.

### 4.13 Attendance events

Current JSON structure:
- `data.attendance` object keyed by `${date}:${classId}:${studentId}`
- each value contains full attendance record metadata

Current operations:
- `/api/attendance` validates date, class access, student membership, and writes records.
- `visibleState()` flattens attendance to arrays for the school view.

Future tables:
- `attendance_events`
- `attendance_records`
- optional `attendance_record_history`

Migration transformation:
- Group attendance records by `schoolId`, `classId`, and `date`.
- Create one `attendance_events` row per group and one `attendance_records` row per student.
- Preserve `status`, `recordedBy`, `recordedAt`, `updatedAt`, and `synced`.

Required foreign keys:
- `attendance_events.school_id -> schools.id`
- `attendance_events.class_id -> classes.id`
- `attendance_events.recorded_by -> users.id`
- `attendance_events.session_id -> user_sessions.id` (optional)
- `attendance_records.event_id -> attendance_events.id`
- `attendance_records.student_id -> students.id`

Tenant checks:
- event school_id must equal class school_id.
- record student_id must map to a student in the same school.

Data risk:
- only current attendance snapshots are available.
- if multiple writes to the same composite key exist, the latest overwrites earlier state and prior change history is lost.

### 4.14 Attendance records/history

Current JSON structure:
- latest record state only

Current operations:
- overwrite on repeated attendance submissions for same student/class/date

Future tables:
- `attendance_records`
- `attendance_record_history`

Migration transformation:
- write current state to `attendance_records`.
- optionally create a history row for each migrated record if a baseline history is desired.

Required foreign keys:
- `attendance_record_history.attendance_record_id -> attendance_records.id`

Tenant checks:
- change history rows must preserve school ownership indirectly via the linked record.

Data risk:
- no prior correction history can be reconstructed.

### 4.15 Invitations

Current JSON structure:
- `data.invitations[]` with `id`, `schoolId`, `name`, `email`, `role`, `status`, `invitedAt`, `code`, `acceptedAt`, `acceptedUserId`

Current operations:
- `/api/users` creates a pending invitation.
- `/api/auth/accept-invite` consumes the code and creates a user.
- `visibleState()` returns invitations to school admins.

Future table:
- `invitations`

Migration transformation:
- migrate invitation rows.
- preserve acceptance metadata.
- add `expires_at` and `revoked_at` as `NULL`.

Required foreign keys:
- `invitations.school_id -> schools.id`
- `invitations.invited_by -> users.id`
- `invitations.accepted_user_id -> users.id`

Tenant checks:
- invitation acceptance must validate school consistency.

Data risk:
- no expiry or revocation history exists; future semantics will start from current pending/accepted states.

### 4.16 Audits

Current JSON structure:
- `data.audit[]` with `id`, `actorId`, `actorName`, `schoolId`, `action`, `detail`, `at`

Current operations:
- `audit()` is called after school settings, invitations, class creation, student creation, and attendance saves.

Future table:
- `audits`

Migration transformation:
- migrate current audit rows.
- preserve actor metadata and timestamps.

Required foreign keys:
- `audits.actor_id -> users.id`
- `audits.school_id -> schools.id`

Tenant checks:
- audit rows should be filtered by school in tenant queries.

Data risk:
- older audit entries beyond the current truncated array are already lost.

## 5. Authorization review

### Platform-level boundaries

Current platform-level roles:
- none explicit in JSON.
- the app has no founder or platform admin guard in server code.

Future target:
- `platform_memberships` will represent `founder`, `platform_admin`, and platform oversight roles.
- platform authorization must be explicit and auditable.
- platform-level authority must not be implemented as a hidden bypass on `users.role` or via a school-level role.

Verification points:
- the future model supports explicit founder/platform membership rows.
- `platform_memberships` is orthogonal to `school_memberships`.
- a founder console will consume `users`, `platform_memberships`, `schools`, and `audits` through explicit platform queries.

### School-level boundaries

Current school roles:
- `principal`
- `admin` (invited but not fully exercised)
- `teacher`

Current enforcement:
- `requireRole()` blocks unauthorized API access.
- `visibleState()` restricts teacher-scoped data.
- attendance writes require class access by teacher membership.

Future preservation:
- `school_memberships.role` and `status` enforce school-scoped access.
- queries must always join or filter by `school_id`.
- class and student operations must verify both the session school and the school of the target entity.

Verification points:
- school-level users cannot access another school’s data because all runtime filters are built on `session.schoolId`.
- if `session.schoolId` is absent, the fallback school is the first school; this will need a stricter future policy.

### Potential contradictions

No concrete contradiction was found between the current behavior and the proposed relational model. The core authorization model is coarse but compatible with the target schema. The migration must preserve the same tenant and role scoping, not broaden it.

## 6. Attendance review

### Current attendance flow

Class access determination:
- the requested class must exist in `data.classes` for the current school.
- the teacher must either be a `principal` or included in `classes.teacherIds` for that class.

Teacher access determination:
- if `session.role !== principal`, the teacher must be listed in the class’s `teacherIds`.

Student selection:
- `validStudents` are `data.students` where `schoolId` matches and `classId === body.classId`.

Attendance recording:
- the API validates `date`, `classId`, and `records`.
- each record is validated and deduplicated in the request batch.
- the server writes into `data.attendance[key]` where `key = `${date}:${classId}:${studentId}``.
- existing records are updated in place; `recordedBy` and `recordedAt` are preserved from the first save, `updatedAt` is refreshed.

Attendance updates:
- updates to the same composite key overwrite the existing record.
- the `synced` flag is always set to `true` on save.

Offline records:
- the browser stores attendance batches in `localStorage` under `schvia_attendance_queue`.
- if offline, the batch is queued and retried when connectivity returns.
- the server receives the same `/api/attendance` payload as online saves.

Duplicate submissions:
- duplicate student IDs in the same request batch are rejected with `409`.
- repeated submissions for the same student/class/date overwrite the existing attendance entry.

Tenant ownership checks:
- the class is validated against the current school.
- students are validated to belong to the class and school.
- attendance records are written with `schoolId`.

### What must change for relational persistence

- Represent attendance as `attendance_events` + `attendance_records` rather than a flat keyed object.
- Preserve the same uniqueness guarantee at the business grain: one record per `school_id, class_id, date, student_id`.
- Add an explicit event/record ID so updates can be idempotent and future history can be tracked.
- Keep offline retries compatible with the same request payload, but introduce sync metadata fields such as `sync_client_id` and `sync_record_id` for idempotent replay.
- Preserve server-side validation for class membership and teacher assignment in the relational model.
- Avoid introducing a new silent reconciliation behavior; the first migration iteration should preserve existing acceptance/rewrite semantics.

### Attendance migration specifics

- Each distinct `date`+`classId` combination becomes one `attendance_events` row.
- Each student record becomes one `attendance_records` row linked to the event.
- `recordedBy` and `recordedAt` should be preserved on the event or record as appropriate.
- `updatedAt` should map to the record's `updated_at`.
- `synced` can default to `true` for migrated records.
- `attendance_record_history` can be initialized empty and starts collecting only after migration.

### Offline-first implications

- The current front end is already queueing requests safely in `localStorage`.
- The relational model must preserve the same request API contract so no frontend changes are required for Stage 1.
- The future offline strategy should treat the current server response as authoritative and a retryable transport failure only when the request fails due to connectivity or server 5xx.
- `401`, `403`, validation errors, or business conflicts must remain visible and not be stored as offline retries.

## 7. Migration sequence

### Stage 1 — schema creation

Input:
- target relational schema definitions
- current JSON persistence file

Output:
- relational schema created in a migration-compatible database engine
- empty tables available for seed and migration

Validation:
- schema compiles and can be connected to by the app migration layer
- foreign keys and unique constraints exist as designed

Failure condition:
- schema creation fails or constraints are missing

Rollback:
- drop the freshly created schema or revert migration files; JSON store remains untouched

### Stage 2 — seed/reference data

Input:
- current `data.schvia.json`
- target schema

Output:
- `schools`, `users`, `academic_terms`, `classes`, `guardians` reference rows inserted into relational tables as appropriate

Validation:
- expected counts for schools, users, classes
- referential integrity checks pass

Failure condition:
- missing required reference rows or incorrect tenant assignment

Rollback:
- truncate seeded tables or restore the relational schema from backup snapshot

### Stage 3 — identity migration

Input:
- migrated `users`
- `memberships` data
- credential hashes from JSON

Output:
- `users` and `user_credentials` populated
- `school_memberships` created

Validation:
- every user has a corresponding credential row if they had `passwordHash`
- every active login email exists in `users` and can be matched by email
- active membership rows exist for each user and school pairing

Failure condition:
- users without credentials, mismatched membership school, duplicate email conflicts

Rollback:
- delete inserted `users`, `user_credentials`, `school_memberships` from relational database

### Stage 4 — school/membership migration

Input:
- current schools and memberships from JSON

Output:
- `schools`
- `school_memberships`
- `platform_memberships` seeded by policy, not JSON

Validation:
- each `membership.school_id` exists in `schools`
- active membership queries return expected counts by school
- session role mapping can be simulated by joining `users` and `school_memberships`

Failure condition:
- orphan memberships, duplicate active memberships, incorrect role mapping

Rollback:
- truncate membership tables and reseed from JSON if needed

### Stage 5 — academic data migration

Input:
- `classes`, `students`, `school.term`, `classes.year`

Output:
- `academic_terms`
- `classes`
- `class_teachers`
- `students`
- `student_class_assignments`

Validation:
- class counts and teacher assignments match JSON semantics
- every active student has a current assignment
- student-class-school relationships are consistent

Failure condition:
- inconsistent class-school joins, missing teacher assignments, orphan students

Rollback:
- restore class and student tables from a schema snapshot or truncate and rerun migration

### Stage 6 — guardian migration

Input:
- student `guardian` text values

Output:
- `guardians`
- `student_guardians`

Validation:
- every student has at least one guardian relationship if guardian text existed
- guardian rows belong to the correct school
- no student has a guardian row that violates the school boundary

Failure condition:
- failed deduplication logic, collapsed distinct guardians, or orphan student_guardians

Rollback:
- truncate guardian tables and rerun conversion with corrected deduplication rules

### Stage 7 — attendance migration

Input:
- `data.attendance` object
- current student and class relationships

Output:
- `attendance_events`
- `attendance_records`

Validation:
- every current JSON attendance record appears in exactly one joined event+record
- unique constraint on `school_id,class_id,date` holds
- student ownership is consistent with class membership on the attendance date

Failure condition:
- event grouping errors, missing record rows, violations of unique constraints

Rollback:
- truncate attendance tables and rerun from the same JSON source

### Stage 8 — invitation migration

Input:
- `data.invitations[]`

Output:
- `invitations`

Validation:
- invitation counts match JSON
- accepted invitations map to existing user IDs
- pending invitations preserve codes and role assignments

Failure condition:
- codes not preserved, orphan accepted_user_id, missing invitation rows

Rollback:
- truncate invitations and rerun migration

### Stage 9 — audit migration

Input:
- `data.audit[]`

Output:
- `audits`

Validation:
- audit counts match JSON
- audit rows reference valid users and schools where possible
- ordering is preserved by timestamp

Failure condition:
- audit rows fail foreign key checks, null references not handled, truncated or reordered history

Rollback:
- truncate audits and rerun migration

### Stage 10 — verification

Input:
- relational data populated from migration stages
- current JSON store untouched

Output:
- validation reports for identity, tenant isolation, attendance, invitations, audits
- decisions on readiness for cutover

Validation:
- row counts match expected JSON-derived counts
- application-level queries against relational data return equivalent state for current users
- authorization boundaries still enforce by school and role
- attendance event/record uniqueness is valid
- no cross-school records exist

Failure condition:
- any mismatch between JSON-derived state and relational state, or failed tenant assertion

Rollback:
- do not cut over; investigate and fix the migration script before retrying

### Stage 11 — controlled application cutover

Input:
- validated relational store with complete migrated data
- code path that can read from relational store
- either dual-write or feature-flagged cutover support

Output:
- application reads from relational store in production
- JSON store remains available as a fallback during transition if safe

Validation:
- existing smoke and E2E tests pass against the new authoritative store
- no frontend behavior changes are observed
- audit and attendance flows behave identically

Failure condition:
- any regression in user-visible workflows or tenant isolation

Rollback:
- revert to the JSON-first runtime path
- keep relational data intact for later retry

### Stage 12 — rollback strategy

Input:
- migration plan and validation results

Output:
- clear rollback steps for each stage

Rollback actions:
- preserve the original `data/schvia.json` file throughout the migration.
- use relational schema snapshots or truncation to undo each stage.
- if a stage fails, stop and do not proceed to the next stage.
- if cutover fails, restore the app to JSON-first behavior and keep the new relational store for investigation.

## 8. Dual-run / cutover recommendation

The safest temporary strategy is to support a JSON-first authoritative store with a relational sidecar during migration.

Concretely:

- keep the current JSON store as the authoritative source while the relational schema is populated and validated.
- implement migration reads and writes in parallel where feasible, but do not make relational the primary authority until verification passes.
- once the relational data is fully validated, switch reads to relational and stop writing to JSON.
- keep JSON available as a rollback target until cutover is confirmed.

Why this is safest:

- it avoids a split-brain scenario where relational and JSON diverge.
- the current app behavior can continue unchanged while migration data is verified.
- the JSON file is already the existing persistence medium, so it can remain the canonical source until cutover.
- the application can preserve existing tests and routes during migration.

Alternative strategies such as making relational authoritative immediately (`JSON ← relational`) are riskier because they introduce a new primary store before all data and access semantics are verified.

## 9. Data-loss risks

### Fields that map directly

- `school.id`, `school.name`, `school.location`
- `users.id`, `users.name`, `users.email`, `users.status`, `users.createdAt`
- `memberships.*`
- `classes.id`, `classes.name`, `classes.schoolId`
- `students.id`, `students.studentId`, `students.name`, `students.gender`, `students.status`
- `attendance.*` current fields except the composite key structure
- `invitations.*`
- `audit.*`

### Fields that require transformation

- `users.role` → `school_memberships.role` and future `platform_memberships` decisions
- `passwordHash` → `user_credentials.password_hash`
- `school.term` and `classes.year` → `academic_terms`
- `classes.teacherIds` → `class_teachers`
- `students.classId` → `student_class_assignments` and `students.current_class_id`
- `students.guardian` → `guardians` + `student_guardians`
- `attendance` keyed object → `attendance_events` + `attendance_records`

### Fields with no direct relational destination

- `users.classIds` (redundant teacher assignment field)
- `students.guardian` free-text semantics beyond guardian `name`
- `attendance` existing `synced` field may be preserved as metadata but is not a durable sync contract in the relational design
- implicit platform-level settings and founder state

### Ambiguous data

- `students.guardian` may represent a parent name, relationship, or contact person; migration can only preserve the string as guardian name.
- `school.term` and `classes.year` may not map cleanly into a single academic term if values are inconsistent.
- teacher assignment may be stale if `classes.teacherIds` contains invalid IDs.

### Historical information that cannot be recovered

- past attendance changes that were overwritten by later saves.
- any audit rows evicted earlier than the current in-memory/truncated `data.audit` array.
- past student class assignment history, because only current `classId` is stored.

## 10. Validation strategy

Validation must be implemented before cutover.

### Core validations

- user migration: every migrated user has matching email and credential row.
- school migration: every migrated school has a matching JSON school.
- membership migration: every active school membership resolves to an existing user and school.
- class migration: each class belongs to the expected school and term.
- teacher assignment migration: every teacher assignment maps to an active teacher in the same school.
- student migration: every student row preserves ID, student number, class membership, and school.
- guardian migration: every non-empty guardian string becomes at least one guardian relationship.
- attendance migration: every current attendance record is represented in event+record rows.
- invitation migration: invitation codes and statuses are preserved.
- audit migration: audit row count and actor/school references match the current JSON audit.

### Tenant isolation validations

- no row in a school-owned table references a `school_id` that does not exist.
- no `class_teachers`, `student_class_assignments`, or `attendance_records` link across schools.
- queries scoped by session school return only that school’s rows.
- active membership lookups in the relational store enforce the same school boundary as the current app.

### Authorization validations

- the migrated identity and membership model allows the same `requireRole` semantics.
- teacher-scoped class access can be computed from `class_teachers` instead of `classes.teacherIds`.
- principal/admin roles continue to be able to manage school settings, invitations, classes, students, and attendance.
- platform role queries remain separate from school role queries.

### Attendance validations

- the relational event/record model enforces uniqueness for `school_id,class_id,date,student_id`.
- each attendance record’s student belongs to the class on the attendance date.
- offline queued batches submitted later still map to the same business grain.

### Verification tools

- row count comparison between JSON export and relational query results.
- sample query equivalence for `visibleState()` payloads.
- tenant-scoped query tests for cross-school exclusion.
- reconciliation reports for ambiguous fields such as guardian names and term strings.

## 11. Rollback strategy

### General rollback principles

- preserve the current JSON store until the new relational model is fully validated.
- treat each migration stage as reversible by truncating or restoring only the affected tables.
- do not delete or overwrite `data/schvia.json` during migration.
- only cut over when validations pass.

### Rollback steps by stage

- schema creation: drop or revert the new schema migration.
- seed/reference data: truncate newly inserted reference tables.
- identity migration: remove inserted `users`, `user_credentials`, and `school_memberships` rows.
- academic migration: truncate `classes`, `class_teachers`, `students`, `student_class_assignments`, and `academic_terms` if necessary.
- guardian migration: truncate `guardians` and `student_guardians`.
- attendance migration: truncate `attendance_events`, `attendance_records`, and `attendance_record_history`.
- invitation migration: truncate `invitations`.
- audit migration: truncate `audits`.

### Cutover rollback

- if relational cutover fails, restore the app to the JSON-first runtime path.
- keep the relational store intact for diagnostics and reruns.
- do not attempt to reconcile half-migrated writes without first restoring a known-good state.

## 12. Dual-run / cutover recommendation

Recommended strategy:

- support a JSON-first authoritative store with relational sidecar population.
- perform migration by copying JSON state into relational tables while the app continues to read/write JSON.
- once verified, switch the app to relational reads and writes.
- retain JSON as a fallback until the first full successful cutover.

This approach minimizes risk by preserving existing behavior, leaving the current persistence layer authoritative, and allowing validation before a hard switch.

## 13. Founder / platform oversight implications

The future relational model supports a real founder console through explicit platform entities.

Entities the founder console will consume:

- `platform_memberships` for platform-level roles and founder/admin status
- `users` for global identity and account status
- `schools` for tenant/workspace metadata
- `school_memberships` for school-specific roles and active status
- `audits` for platform and school audit trails
- `invitations` to inspect pending school invitations
- `classes`, `students`, and `attendance_events` for high-level school health indicators

The founder console must not:

- infer platform authority from `school_memberships`
- rely on hidden rules in the application server
- expose school data without explicit platform-level authorization

The founder console can start with read-only oversight and later add controlled operations once platform-level authorization is stable.

## 14. Preconditions for Mission 004B implementation

Before implementing the migration:

- confirm the current JSON store is stable and complete for the pilot workflows.
- ensure `serve.mjs` has a clean persistence boundary and read/write abstraction.
- preserve all existing tests and their current pass state.
- agree on the exact relational schema from `SCHVIA_DATABASE_DESIGN.md`.
- establish a migration staging environment separate from production.
- confirm that no PostgreSQL-specific code or dependency is added yet.

## 15. Explicit things that MUST NOT change during migration

- do not change the frontend behavior or UI API contracts.
- do not remove or alter existing API routes semantics.
- do not disable current authorization checks.
- do not introduce PostgreSQL dependencies or a database engine in this mission.
- do not destroy or overwrite `data/schvia.json`.
- do not change the current test expectations in `tests/smoke.mjs`, `tests/real-user-e2e.mjs`, or `tests/persistence.mjs`.
- do not invent new attendance states or invitation workflows during migration.
- do not infer platform-level authority from school-level roles.
- do not treat the relational store as authoritative before validation and cutover.

## 16. Summary

The path from JSON persistence to the relational model is achievable without redesigning the current application behavior. The safest migration is a phased cutover that preserves JSON as the authoritative store until relational data is verified.

The key risks are:
- free-text guardian migration
- ambiguous academic term mapping
- lost attendance history beyond current records
- missing platform membership data in the current JSON
- session migration because sessions are currently in-memory only

The plan above defines the sequence, validation points, rollback actions, and safe dual-run strategy needed to prepare SchVIA for Mission 004B.
