import { readFile, readdir } from "node:fs/promises";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { Pool } from "pg";

const __dirname = dirname(fileURLToPath(import.meta.url));
const migrationsPath = join(__dirname, "migrations");
const databaseUrl = process.env.DATABASE_URL;

if (!databaseUrl) {
  console.error("ERROR: DATABASE_URL must be set to run migrations.");
  process.exit(1);
}

const pool = new Pool({ connectionString: databaseUrl });

async function ensureMigrationTable(client) {
  await client.query(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version TEXT PRIMARY KEY,
      applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
  `);
}

async function getMigrationFiles() {
  const files = await readdir(migrationsPath);
  return files
    .filter((file) => file.endsWith(".sql"))
    .sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
}

async function getAppliedMigrations(client) {
  const result = await client.query("SELECT version FROM schema_migrations ORDER BY version");
  return new Set(result.rows.map((row) => row.version));
}

async function applyMigration(client, file) {
  const path = join(migrationsPath, file);
  const sql = await readFile(path, "utf8");
  await client.query("BEGIN");
  try {
    await client.query(sql);
    await client.query(
      "INSERT INTO schema_migrations (version) VALUES ($1)",
      [file],
    );
    await client.query("COMMIT");
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  }
}

async function run() {
  const client = await pool.connect();
  try {
    await ensureMigrationTable(client);
    const files = await getMigrationFiles();
    const applied = await getAppliedMigrations(client);
    const pending = files.filter((file) => !applied.has(file));
    if (!pending.length) {
      console.log("No pending migrations.");
      return;
    }
    for (const file of pending) {
      console.log(`Applying migration: ${file}`);
      await applyMigration(client, file);
    }
    console.log("Migrations applied successfully.");
  } finally {
    client.release();
    await pool.end();
  }
}

run().catch((error) => {
  console.error("Migration failed:", error.message || error);
  process.exit(1);
});
