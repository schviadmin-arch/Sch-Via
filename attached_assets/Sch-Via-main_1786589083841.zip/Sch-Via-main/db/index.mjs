import { Pool } from "pg";

const connectionString = process.env.DATABASE_URL || null;
const pool = connectionString ? new Pool({ connectionString }) : null;

export function ensureDatabaseConfigured() {
  if (!pool) {
    throw new Error("DATABASE_URL is not configured. Set DATABASE_URL to a PostgreSQL connection string to enable relational persistence.");
  }
}

export async function query(text, params = []) {
  ensureDatabaseConfigured();
  return pool.query(text, params);
}

export async function connect() {
  ensureDatabaseConfigured();
  return pool.connect();
}

export async function close() {
  if (pool) {
    await pool.end();
  }
}
