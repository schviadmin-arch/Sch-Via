#!/usr/bin/env node
import { resolve as resolvePath, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { connect, close } from "./index.mjs";
import {
  loadJsonSource,
  buildMigrationPlan,
  validateMigrationPlan,
  buildMigrationReport,
  formatReport,
} from "./migration-utils.mjs";

const __dirname = dirname(fileURLToPath(import.meta.url));

function parseArgs(argv) {
  const options = {
    sourcePath: resolvePath(__dirname, "..", "data", "schvia.json"),
    dryRun: false,
    apply: false,
  };

  const args = [...argv];
  while (args.length) {
    const token = args.shift();
    switch (token) {
      case "--source":
      case "-s": {
        const value = args.shift();
        if (!value) {
          throw new Error("--source requires a file path");
        }
        options.sourcePath = resolvePath(process.cwd(), value);
        break;
      }
      case "--dry-run":
      case "-d":
        options.dryRun = true;
        break;
      case "--apply":
      case "-a":
        options.apply = true;
        break;
      case "--help":
      case "-h":
        options.help = true;
        break;
      default:
        throw new Error(`Unknown argument: ${token}`);
    }
  }

  if (!options.apply) {
    options.dryRun = true;
  }
  return options;
}

function printHelp() {
  console.log("Usage: node db/migrate-json.mjs [options]\n");
  console.log("Options:");
  console.log("  --source, -s  Path to JSON source file (defaults to data/schvia.json)");
  console.log("  --dry-run, -d  Validate and report without writing to the database (default)");
  console.log("  --apply, -a    Apply the migration to the configured PostgreSQL database");
  console.log("  --help, -h     Print this help text");
}

async function insertRows(client, table, rows) {
  if (!rows.length) return;
  const columns = Object.keys(rows[0]);
  const placeholders = columns.map((_, index) => `$${index + 1}`).join(", ");
  const text = `INSERT INTO ${table} (${columns.join(", ")}) VALUES (${placeholders}) ON CONFLICT DO NOTHING`;
  for (const row of rows) {
    const values = columns.map((column) => row[column]);
    await client.query(text, values);
  }
}

export async function applyMigration(plan) {
  const client = await connect();
  try {
    await client.query("BEGIN");
    await insertRows(client, "schools", plan.rows.schools);
    await insertRows(client, "users", plan.rows.users);
    await insertRows(client, "user_credentials", plan.rows.user_credentials);
    await insertRows(client, "school_memberships", plan.rows.school_memberships);
    await insertRows(client, "academic_terms", plan.rows.academic_terms);
    await insertRows(client, "classes", plan.rows.classes);
    await insertRows(client, "class_teachers", plan.rows.class_teachers);
    await insertRows(client, "students", plan.rows.students);
    await insertRows(client, "guardians", plan.rows.guardians);
    await insertRows(client, "student_guardians", plan.rows.student_guardians);
    await insertRows(client, "student_class_assignments", plan.rows.student_class_assignments);
    await insertRows(client, "attendance_events", plan.rows.attendance_events);
    await insertRows(client, "attendance_records", plan.rows.attendance_records);
    await insertRows(client, "invitations", plan.rows.invitations);
    await insertRows(client, "audits", plan.rows.audits);
    await client.query("COMMIT");
    console.log("Migration applied successfully.");
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
    await close();
  }
}

async function run() {
  let options;
  try {
    options = parseArgs(process.argv.slice(2));
  } catch (error) {
    console.error(error.message);
    printHelp();
    process.exit(1);
  }

  if (options.help) {
    printHelp();
    return;
  }

  const source = await loadJsonSource(options.sourcePath);
  const plan = buildMigrationPlan(source);
  const validatedPlan = validateMigrationPlan(plan);
  const report = buildMigrationReport(validatedPlan, {
    sourcePath: options.sourcePath,
    dryRun: options.dryRun,
  });
  console.log(formatReport(report));

  if (validatedPlan.errors.length) {
    process.exit(1);
  }

  if (options.apply) {
    await applyMigration(validatedPlan);
  }
}

run().catch((error) => {
  console.error("Migration failed:", error.message || error);
  process.exit(1);
});
