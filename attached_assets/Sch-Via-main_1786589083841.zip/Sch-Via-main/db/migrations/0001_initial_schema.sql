CREATE TABLE IF NOT EXISTS schema_migrations (
  version TEXT PRIMARY KEY,
  applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  profile JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS schools (
  id UUID PRIMARY KEY,
  name TEXT NOT NULL,
  location TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  current_term TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  founder_user_id UUID REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS platform_memberships (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  role TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  granted_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  revoked_at TIMESTAMPTZ NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_platform_memberships_active_user_role
  ON platform_memberships (user_id, role)
  WHERE status = 'active';

CREATE TABLE IF NOT EXISTS user_credentials (
  user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  password_hash TEXT NOT NULL,
  password_algorithm TEXT NOT NULL DEFAULT 'scrypt',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS user_sessions (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  school_id UUID REFERENCES schools(id),
  session_token_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_active_at TIMESTAMPTZ,
  expires_at TIMESTAMPTZ NOT NULL,
  revoked_at TIMESTAMPTZ NULL,
  ip_address TEXT,
  user_agent TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_user_sessions_token_hash ON user_sessions (session_token_hash);
CREATE INDEX IF NOT EXISTS idx_user_sessions_user_id ON user_sessions (user_id);

CREATE TABLE IF NOT EXISTS school_memberships (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  role TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  accepted_at TIMESTAMPTZ NULL,
  revoked_at TIMESTAMPTZ NULL,
  ended_at TIMESTAMPTZ NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_school_memberships_active_user_school
  ON school_memberships (user_id, school_id)
  WHERE status = 'active';
CREATE INDEX IF NOT EXISTS idx_school_memberships_school_id ON school_memberships (school_id);
CREATE INDEX IF NOT EXISTS idx_school_memberships_user_id ON school_memberships (user_id);

CREATE TABLE IF NOT EXISTS academic_terms (
  id UUID PRIMARY KEY,
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  starts_at DATE NULL,
  ends_at DATE NULL,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (school_id, name)
);
CREATE INDEX IF NOT EXISTS idx_academic_terms_school_id ON academic_terms (school_id);

CREATE TABLE IF NOT EXISTS classes (
  id UUID PRIMARY KEY,
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  academic_term_id UUID REFERENCES academic_terms(id),
  status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (school_id, name, academic_term_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_classes_school_id_unique ON classes (id, school_id);
CREATE INDEX IF NOT EXISTS idx_classes_school_id ON classes (school_id);
CREATE INDEX IF NOT EXISTS idx_classes_academic_term_id ON classes (academic_term_id);

CREATE TABLE IF NOT EXISTS subjects (
  id UUID PRIMARY KEY,
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  code TEXT NULL,
  description TEXT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (school_id, name),
  UNIQUE (school_id, code)
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_subjects_school_id_unique ON subjects (id, school_id);
CREATE INDEX IF NOT EXISTS idx_subjects_school_id ON subjects (school_id);

CREATE TABLE IF NOT EXISTS class_subjects (
  id UUID PRIMARY KEY,
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  class_id UUID NOT NULL,
  subject_id UUID NOT NULL,
  teacher_id UUID NULL REFERENCES users(id),
  academic_term_id UUID REFERENCES academic_terms(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (class_id, subject_id, academic_term_id),
  FOREIGN KEY (class_id, school_id) REFERENCES classes (id, school_id) ON DELETE CASCADE,
  FOREIGN KEY (subject_id, school_id) REFERENCES subjects (id, school_id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_class_subjects_class_id ON class_subjects (class_id);
CREATE INDEX IF NOT EXISTS idx_class_subjects_subject_id ON class_subjects (subject_id);
CREATE INDEX IF NOT EXISTS idx_class_subjects_teacher_id ON class_subjects (teacher_id);

CREATE TABLE IF NOT EXISTS assessments (
  id UUID PRIMARY KEY,
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  subject_id UUID NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
  class_id UUID NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  academic_term_id UUID NOT NULL REFERENCES academic_terms(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  max_score NUMERIC NULL,
  date DATE NULL,
  due_at TIMESTAMPTZ NULL,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_assessments_school_id ON assessments (school_id);
CREATE INDEX IF NOT EXISTS idx_assessments_class_id ON assessments (class_id);
CREATE INDEX IF NOT EXISTS idx_assessments_subject_id ON assessments (subject_id);

CREATE TABLE IF NOT EXISTS students (
  id UUID PRIMARY KEY,
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  student_number TEXT NOT NULL,
  name TEXT NOT NULL,
  gender TEXT NULL,
  status TEXT NOT NULL DEFAULT 'enrolled',
  current_class_id UUID NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (school_id, student_number),
  FOREIGN KEY (current_class_id, school_id) REFERENCES classes (id, school_id) ON DELETE SET NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_students_school_id_unique ON students (id, school_id);
CREATE INDEX IF NOT EXISTS idx_students_school_id ON students (school_id);
CREATE INDEX IF NOT EXISTS idx_students_current_class_id ON students (current_class_id);

CREATE TABLE IF NOT EXISTS guardians (
  id UUID PRIMARY KEY,
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  relationship TEXT NULL,
  email TEXT NULL,
  phone TEXT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_guardians_school_id_unique ON guardians (id, school_id);
CREATE INDEX IF NOT EXISTS idx_guardians_school_id ON guardians (school_id);

CREATE TABLE IF NOT EXISTS student_guardians (
  id UUID PRIMARY KEY,
  student_id UUID NOT NULL,
  guardian_id UUID NOT NULL,
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  is_primary BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  ended_at TIMESTAMPTZ NULL,
  UNIQUE (student_id, guardian_id),
  FOREIGN KEY (student_id, school_id) REFERENCES students (id, school_id) ON DELETE CASCADE,
  FOREIGN KEY (guardian_id, school_id) REFERENCES guardians (id, school_id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_student_guardians_student_id ON student_guardians (student_id);
CREATE INDEX IF NOT EXISTS idx_student_guardians_guardian_id ON student_guardians (guardian_id);
CREATE INDEX IF NOT EXISTS idx_student_guardians_school_id ON student_guardians (school_id);

CREATE TABLE IF NOT EXISTS student_class_assignments (
  id UUID PRIMARY KEY,
  student_id UUID NOT NULL,
  class_id UUID NOT NULL,
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  assigned_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  ended_at TIMESTAMPTZ NULL,
  is_current BOOLEAN NOT NULL DEFAULT true,
  UNIQUE (student_id, class_id, assigned_at),
  FOREIGN KEY (student_id, school_id) REFERENCES students (id, school_id) ON DELETE CASCADE,
  FOREIGN KEY (class_id, school_id) REFERENCES classes (id, school_id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_student_class_assignments_student_id ON student_class_assignments (student_id);
CREATE INDEX IF NOT EXISTS idx_student_class_assignments_class_id ON student_class_assignments (class_id);
CREATE INDEX IF NOT EXISTS idx_student_class_assignments_school_id ON student_class_assignments (school_id);

CREATE TABLE IF NOT EXISTS assessment_results (
  id UUID PRIMARY KEY,
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  assessment_id UUID NOT NULL REFERENCES assessments(id) ON DELETE CASCADE,
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  score NUMERIC NULL,
  grade TEXT NULL,
  remarks TEXT NULL,
  recorded_by UUID REFERENCES users(id),
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  status TEXT NOT NULL DEFAULT 'recorded',
  UNIQUE (assessment_id, student_id)
);
CREATE INDEX IF NOT EXISTS idx_assessment_results_assessment_id ON assessment_results (assessment_id);
CREATE INDEX IF NOT EXISTS idx_assessment_results_student_id ON assessment_results (student_id);

CREATE TABLE IF NOT EXISTS report_cards (
  id UUID PRIMARY KEY,
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  academic_term_id UUID NOT NULL REFERENCES academic_terms(id) ON DELETE CASCADE,
  issued_at TIMESTAMPTZ NULL,
  status TEXT NOT NULL DEFAULT 'draft',
  comments TEXT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (school_id, student_id, academic_term_id)
);
CREATE INDEX IF NOT EXISTS idx_report_cards_school_id ON report_cards (school_id);
CREATE INDEX IF NOT EXISTS idx_report_cards_student_id ON report_cards (student_id);

CREATE TABLE IF NOT EXISTS report_card_entries (
  id UUID PRIMARY KEY,
  report_card_id UUID NOT NULL REFERENCES report_cards(id) ON DELETE CASCADE,
  subject_id UUID NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
  assessment_result_summary JSONB NULL,
  grade TEXT NULL,
  remarks TEXT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (report_card_id, subject_id)
);
CREATE INDEX IF NOT EXISTS idx_report_card_entries_report_card_id ON report_card_entries (report_card_id);
CREATE INDEX IF NOT EXISTS idx_report_card_entries_subject_id ON report_card_entries (subject_id);

CREATE TABLE IF NOT EXISTS class_teachers (
  id UUID PRIMARY KEY,
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  class_id UUID NOT NULL,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  assigned_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  removed_at TIMESTAMPTZ NULL,
  FOREIGN KEY (class_id, school_id) REFERENCES classes (id, school_id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_class_teachers_active_assignment
  ON class_teachers (class_id, user_id)
  WHERE removed_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_class_teachers_class_id ON class_teachers (class_id);
CREATE INDEX IF NOT EXISTS idx_class_teachers_user_id ON class_teachers (user_id);

CREATE TABLE IF NOT EXISTS attendance_events (
  id UUID PRIMARY KEY,
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  class_id UUID NOT NULL,
  date DATE NOT NULL,
  recorded_by UUID REFERENCES users(id),
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  sync_source TEXT NULL,
  session_id UUID REFERENCES user_sessions(id),
  FOREIGN KEY (class_id, school_id) REFERENCES classes (id, school_id) ON DELETE CASCADE,
  UNIQUE (school_id, class_id, date)
);
CREATE INDEX IF NOT EXISTS idx_attendance_events_school_id ON attendance_events (school_id);
CREATE INDEX IF NOT EXISTS idx_attendance_events_class_id ON attendance_events (class_id);
CREATE INDEX IF NOT EXISTS idx_attendance_events_date ON attendance_events (date);

CREATE TABLE IF NOT EXISTS attendance_records (
  id UUID PRIMARY KEY,
  event_id UUID NOT NULL REFERENCES attendance_events(id) ON DELETE CASCADE,
  student_id UUID NOT NULL,
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  status TEXT NOT NULL,
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  synced BOOLEAN NOT NULL DEFAULT true,
  sync_client_id TEXT NULL,
  sync_record_id TEXT NULL,
  UNIQUE (event_id, student_id),
  FOREIGN KEY (student_id, school_id) REFERENCES students (id, school_id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_attendance_records_event_id ON attendance_records (event_id);
CREATE INDEX IF NOT EXISTS idx_attendance_records_student_id ON attendance_records (student_id);

CREATE TABLE IF NOT EXISTS attendance_record_history (
  id UUID PRIMARY KEY,
  attendance_record_id UUID NOT NULL REFERENCES attendance_records(id) ON DELETE CASCADE,
  status TEXT NOT NULL,
  changed_by UUID REFERENCES users(id),
  changed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  reason TEXT NULL,
  metadata JSONB NULL
);
CREATE INDEX IF NOT EXISTS idx_attendance_record_history_record_id ON attendance_record_history (attendance_record_id);

CREATE TABLE IF NOT EXISTS invitations (
  id UUID PRIMARY KEY,
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  invited_by UUID REFERENCES users(id),
  invitee_name TEXT NOT NULL,
  invitee_email TEXT NOT NULL,
  role TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  code TEXT NOT NULL UNIQUE,
  invited_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at TIMESTAMPTZ NULL,
  accepted_at TIMESTAMPTZ NULL,
  revoked_at TIMESTAMPTZ NULL,
  accepted_user_id UUID REFERENCES users(id)
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_invitations_school_pending_email
  ON invitations (school_id, invitee_email)
  WHERE status = 'pending';
CREATE INDEX IF NOT EXISTS idx_invitations_school_id ON invitations (school_id);
CREATE INDEX IF NOT EXISTS idx_invitations_invitee_email ON invitations (invitee_email);

CREATE TABLE IF NOT EXISTS audits (
  id UUID PRIMARY KEY,
  actor_id UUID REFERENCES users(id),
  actor_name TEXT NOT NULL,
  school_id UUID REFERENCES schools(id),
  entity_type TEXT NULL,
  entity_id UUID NULL,
  action TEXT NOT NULL,
  detail TEXT NULL,
  metadata JSONB NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_audits_school_id ON audits (school_id);
CREATE INDEX IF NOT EXISTS idx_audits_actor_id ON audits (actor_id);
CREATE INDEX IF NOT EXISTS idx_audits_entity ON audits (entity_type, entity_id);
