import { readFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const defaultDataPath = () => join(__dirname, "..", "data", "schvia.json");

const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const DEFAULT_TIMESTAMP = "1970-01-01T00:00:00.000Z";

function cloneValue(value) {
  if (Array.isArray(value)) {
    return value.map(cloneValue);
  }
  if (value && typeof value === "object") {
    return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, cloneValue(item)]));
  }
  return value;
}

function normalizeTimestamp(value) {
  if (typeof value !== "string") return DEFAULT_TIMESTAMP;
  const date = new Date(value);
  if (Number.isNaN(date.valueOf())) return DEFAULT_TIMESTAMP;
  return date.toISOString();
}

function normalizeId(type, sourceId, fallbackObject) {
  if (typeof sourceId === "string" && uuidRegex.test(sourceId)) {
    return sourceId.toLowerCase();
  }
  if (typeof sourceId === "string" && sourceId.length > 0) {
    return deterministicUuid(`${type}:${sourceId}`);
  }
  return deterministicUuid(`${type}:${JSON.stringify(fallbackObject)}`);
}

function deterministicUuid(value) {
  const hash = createHash("sha1").update(value, "utf8").digest("hex");
  return `${hash.slice(0, 8)}-${hash.slice(8, 12)}-${hash.slice(12, 16)}-${hash.slice(16, 20)}-${hash.slice(20, 32)}`;
}

function parseJson(text, path) {
  try {
    return JSON.parse(text);
  } catch (error) {
    const parseError = new Error(`Failed to parse JSON from ${path}: ${error.message}`);
    parseError.code = "INVALID_JSON";
    throw parseError;
  }
}

export async function loadJsonSource(sourcePath = defaultDataPath()) {
  const raw = await readFile(sourcePath, "utf8");
  const parsed = parseJson(raw, sourcePath);
  return { sourcePath, raw: parsed };
}

export function normalizeSourceData({ raw }) {
  const originalSchool = raw.school ? cloneValue(raw.school) : null;
  const primarySchool = originalSchool || {
    id: normalizeId("school", "default-school", { source: raw }),
    name: "Unknown School",
    location: "",
    term: "",
    createdAt: DEFAULT_TIMESTAMP,
  };

  const data = {
    ...cloneValue(raw),
    school: cloneValue(primarySchool),
    schools: Array.isArray(raw.schools) ? raw.schools.map(cloneValue) : [],
    memberships: Array.isArray(raw.memberships) ? raw.memberships.map(cloneValue) : [],
    users: Array.isArray(raw.users) ? raw.users.map(cloneValue) : [],
    classes: Array.isArray(raw.classes) ? raw.classes.map(cloneValue) : [],
    students: Array.isArray(raw.students) ? raw.students.map(cloneValue) : [],
    attendance: raw.attendance && typeof raw.attendance === "object" && !Array.isArray(raw.attendance)
      ? Object.fromEntries(Object.entries(raw.attendance).map(([key, value]) => [key, cloneValue(value)]))
      : {},
    invitations: Array.isArray(raw.invitations) ? raw.invitations.map(cloneValue) : [],
    audit: Array.isArray(raw.audit) ? raw.audit.map(cloneValue) : [],
  };

  if (!data.schools.some((school) => school && school.id === primarySchool.id)) {
    data.schools.unshift(primarySchool);
  }

  for (const user of data.users) {
    user.schoolId ??= primarySchool.id;
    const role = user.role === "teacher" ? "teacher" : user.role === "principal" ? "principal" : user.role;
    if (!data.memberships.some((membership) => membership.userId === user.id && membership.schoolId === user.schoolId)) {
      data.memberships.push({
        id: `membership-${user.id}`,
        userId: user.id,
        schoolId: user.schoolId,
        role: role || "teacher",
        status: user.status || "active",
        createdAt: user.createdAt || new Date().toISOString(),
      });
    }
  }

  for (const item of data.classes) item.schoolId ??= primarySchool.id;
  for (const item of data.students) item.schoolId ??= primarySchool.id;
  for (const item of data.invitations) item.schoolId ??= primarySchool.id;
  for (const item of data.audit) item.schoolId ??= primarySchool.id;
  for (const item of Object.values(data.attendance || {})) item.schoolId ??= primarySchool.id;

  return data;
}

function ensureArray(value) {
  return Array.isArray(value) ? value : [];
}

function isValidDate(value) {
  if (typeof value !== "string") return false;
  const parsed = new Date(`${value}T00:00:00.000Z`);
  return !Number.isNaN(parsed.valueOf()) && parsed.toISOString().slice(0, 10) === value;
}

function normalizeString(value) {
  return typeof value === "string" ? value.trim() : "";
}

function issueTypeForMessage(message) {
  const normalized = String(message).toLowerCase();
  if (/duplicate|conflict|contradictory|duplicate pending/.test(normalized)) {
    return "duplicate_conflict";
  }
  if (/school|tenant|cross-school|cross school|belongs to a different school|ownership|school_id/.test(normalized)) {
    return "tenant_violation";
  }
  if (/missing|references missing|unknown user|unknown class|unknown student|unknown guardian|unknown school/.test(normalized)) {
    return "orphan_reference";
  }
  return "validation";
}

function createIssue(entity, message, type) {
  const normalizedType = type || issueTypeForMessage(message);
  return { entity, message, type: normalizedType };
}

function summarizeIssueTypes(issues) {
  return issues.reduce((summary, issue) => {
    const type = issue.type || issueTypeForMessage(issue.message);
    summary[type] = (summary[type] || 0) + 1;
    return summary;
  }, {
    duplicate_conflict: 0,
    tenant_violation: 0,
    orphan_reference: 0,
    validation: 0,
  });
}

export function buildMigrationPlan(data) {
  const normalized = normalizeSourceData(data);
  const now = DEFAULT_TIMESTAMP;
  const warnings = [];
  const errors = [];
  const attendanceEntries = ensureArray(Object.values(normalized.attendance || {}));
  const attendanceEventKeys = new Set(
    attendanceEntries
      .filter((entry) => entry && entry.date && entry.classId)
      .map((entry) => `${entry.date}:${entry.classId}`),
  );
  const sourceCounts = {
    schools: ensureArray(normalized.schools).length,
    users: ensureArray(normalized.users).length,
    memberships: ensureArray(normalized.memberships).length,
    classes: ensureArray(normalized.classes).length,
    students: ensureArray(normalized.students).length,
    guardians: ensureArray(normalized.students).filter((student) => normalizeString(student.guardian)).length,
    attendance_events: attendanceEventKeys.size,
    attendance_records: attendanceEntries.length,
    invitations: ensureArray(normalized.invitations).length,
    audit: ensureArray(normalized.audit).length,
  };

  const schoolMap = new Map();
  const userMap = new Map();
  const classMap = new Map();
  const studentMap = new Map();
  const invitationMap = new Map();
  const auditMap = new Map();

  const schools = [];
  for (const school of ensureArray(normalized.schools)) {
    if (!school || !school.id) {
      errors.push({ entity: "school", message: "School is missing an id." });
      continue;
    }
    const id = normalizeId("school", school.id, school);
    if (schoolMap.has(id)) {
      errors.push({ entity: "school", message: `Duplicate school id ${school.id}` });
      continue;
    }
    const currentTerm = normalizeString(school.term);
    schools.push({
      id,
      name: normalizeString(school.name) || "Unnamed School",
      location: normalizeString(school.location) || null,
      status: "active",
      current_term: currentTerm || null,
      created_at: normalizeTimestamp(school.createdAt),
      updated_at: now,
      founder_user_id: null,
    });
    schoolMap.set(school.id, { id, school });
  }

  if (schoolMap.size === 0) {
    errors.push({ entity: "school", message: "No valid school records were found." });
  }

  const users = [];
  const legacyUserIdToUuid = new Map();
  const emailSet = new Map();
  for (const user of ensureArray(normalized.users)) {
    if (!user || !user.id) {
      errors.push({ entity: "user", message: "User entry is missing an id." });
      continue;
    }
    if (!user.email) {
      errors.push({ entity: "user", id: user.id, message: "User email is required." });
    }
    if (!user.name) {
      errors.push({ entity: "user", id: user.id, message: "User name is required." });
    }
    const id = normalizeId("user", user.id, user);
    if (legacyUserIdToUuid.has(user.id)) {
      errors.push({ entity: "user", message: `Duplicate user id ${user.id}` });
      continue;
    }
    const email = normalizeString(user.email).toLowerCase() || null;
    if (email) {
      const existingEmail = emailSet.get(email);
      if (existingEmail) {
        errors.push({ entity: "user", id: user.id, message: `Duplicate user email ${email} (also used by ${existingEmail})` });
      } else {
        emailSet.set(email, user.id);
      }
    }
    const schoolReference = schoolMap.get(user.schoolId || normalized.school.id);
    if (!schoolReference) {
      errors.push({ entity: "user", id: user.id, message: `User schoolId ${user.schoolId} does not resolve to a valid school.` });
    }
    legacyUserIdToUuid.set(user.id, id);
    users.push({
      id,
      email,
      name: normalizeString(user.name) || "Unnamed User",
      status: normalizeString(user.status) || "active",
      profile: {
        legacyId: user.id,
        legacyRole: normalizeString(user.role) || null,
        classIds: Array.isArray(user.classIds) ? [...user.classIds] : [],
      },
      created_at: normalizeTimestamp(user.createdAt),
      updated_at: now,
    });
    if (!schoolReference) {
      continue;
    }
    if (!user.role) {
      warnings.push({ entity: "user", id: user.id, message: "User role is missing; defaulting to teacher-like membership mapping." });
    }
  }

  const memberships = [];
  const membershipKeySet = new Set();
  const membershipSourceMap = new Map();
  for (const membership of ensureArray(normalized.memberships)) {
    if (!membership || !membership.id || !membership.userId || !membership.schoolId) {
      errors.push({ entity: "membership", message: "Membership entry is missing required id, userId, or schoolId." });
      continue;
    }
    const userUuid = legacyUserIdToUuid.get(membership.userId);
    if (!userUuid) {
      errors.push({ entity: "membership", id: membership.id, message: `Membership references unknown user ${membership.userId}.` });
      continue;
    }
    const schoolReference = schoolMap.get(membership.schoolId);
    if (!schoolReference) {
      errors.push({ entity: "membership", id: membership.id, message: `Membership references unknown school ${membership.schoolId}.` });
      continue;
    }
    const id = normalizeId("school_membership", membership.id, membership);
    const key = `${userUuid}:${schoolReference.id}`;
    if (membershipKeySet.has(key)) {
      errors.push({ entity: "membership", id: membership.id, message: `Duplicate membership for user ${membership.userId} and school ${membership.schoolId}.` });
      continue;
    }
    membershipKeySet.add(key);
    membershipSourceMap.set(key, membership);
    memberships.push({
      id,
      user_id: userUuid,
      school_id: schoolReference.id,
      role: normalizeString(membership.role) || "teacher",
      status: normalizeString(membership.status) || "active",
      created_at: normalizeTimestamp(membership.createdAt),
      accepted_at: null,
      revoked_at: null,
      ended_at: null,
    });
    const userSource = normalized.users.find((item) => item.id === membership.userId);
    if (userSource && userSource.schoolId && userSource.schoolId !== membership.schoolId) {
      warnings.push({ entity: "membership", id: membership.id, message: `Membership schoolId ${membership.schoolId} differs from user ${membership.userId} schoolId ${userSource.schoolId}.` });
    }
  }

  for (const user of ensureArray(normalized.users)) {
    const userUuid = legacyUserIdToUuid.get(user.id);
    const schoolReference = schoolMap.get(user.schoolId || normalized.school.id);
    if (!userUuid || !schoolReference) continue;
    const key = `${userUuid}:${schoolReference.id}`;
    if (!membershipKeySet.has(key)) {
      const role = normalizeString(user.role) || "teacher";
      memberships.push({
        id: normalizeId("school_membership", `fallback-${user.id}-${schoolReference.id}`, { user, school: schoolReference }),
        user_id: userUuid,
        school_id: schoolReference.id,
        role,
        status: normalizeString(user.status) || "active",
        created_at: user.createdAt || now,
        accepted_at: null,
        revoked_at: null,
        ended_at: null,
      });
      membershipKeySet.add(key);
      warnings.push({ entity: "membership", id: user.id, message: "Created fallback membership from user record because no explicit membership existed." });
    }
  }

  const credentials = [];
  for (const user of ensureArray(normalized.users)) {
    if (typeof user.passwordHash === "string" && user.passwordHash.length > 0) {
      const userUuid = legacyUserIdToUuid.get(user.id);
      if (userUuid) {
        credentials.push({
          user_id: userUuid,
          password_hash: user.passwordHash,
          password_algorithm: "scrypt",
          created_at: user.createdAt || now,
          updated_at: now,
        });
      }
    }
  }

  const termMap = new Map();
  const academicTerms = [];
  for (const schoolEntry of schoolMap.values()) {
    const { school } = schoolEntry;
    const termName = normalizeString(school.term);
    if (termName) {
      const id = normalizeId("academic_term", `${school.id}:${termName}`, school);
      if (!termMap.has(`${school.id}:${termName}`)) {
        termMap.set(`${school.id}:${termName}`, id);
        academicTerms.push({
          id,
          school_id: schoolEntry.id,
          name: termName,
          starts_at: null,
          ends_at: null,
          status: "active",
          created_at: school.createdAt || now,
          updated_at: now,
        });
      }
    }
  }

  for (const klass of ensureArray(normalized.classes)) {
    const schoolReference = schoolMap.get(klass.schoolId || normalized.school.id);
    if (!schoolReference) continue;
    const termName = normalizeString(klass.year);
    if (termName) {
      const key = `${schoolReference.id}:${termName}`;
      if (!termMap.has(key)) {
        const id = normalizeId("academic_term", key, klass);
        termMap.set(key, id);
        academicTerms.push({
          id,
          school_id: schoolReference.id,
          name: termName,
          starts_at: null,
          ends_at: null,
          status: "active",
          created_at: klass.createdAt || now,
          updated_at: now,
        });
      }
    }
  }

  const classes = [];
  for (const klass of ensureArray(normalized.classes)) {
    if (!klass || !klass.id) {
      errors.push({ entity: "class", message: "Class record is missing an id." });
      continue;
    }
    const schoolReference = schoolMap.get(klass.schoolId || normalized.school.id);
    if (!schoolReference) {
      errors.push({ entity: "class", id: klass.id, message: `Class references unknown school ${klass.schoolId}.` });
      continue;
    }
    const id = normalizeId("class", klass.id, klass);
    if (classMap.has(klass.id)) {
      errors.push({ entity: "class", message: `Duplicate class id ${klass.id}` });
      continue;
    }
    const year = normalizeString(klass.year);
    const academicTermId = year ? termMap.get(`${schoolReference.id}:${year}`) || null : null;
    classes.push({
      id,
      school_id: schoolReference.id,
      name: normalizeString(klass.name) || "Unnamed class",
      academic_term_id: academicTermId,
      status: "active",
      created_at: normalizeTimestamp(klass.createdAt),
      updated_at: now,
    });
    classMap.set(klass.id, { id, schoolId: schoolReference.id, class: klass });
  }

  const studentClassAssignments = [];
  const students = [];
  for (const student of ensureArray(normalized.students)) {
    if (!student || !student.id) {
      errors.push({ entity: "student", message: "Student record is missing an id." });
      continue;
    }
    const schoolReference = schoolMap.get(student.schoolId || normalized.school.id);
    if (!schoolReference) {
      errors.push({ entity: "student", id: student.id, message: `Student references unknown school ${student.schoolId}.` });
      continue;
    }
    const id = normalizeId("student", student.id, student);
    if (studentMap.has(student.id)) {
      errors.push({ entity: "student", message: `Duplicate student id ${student.id}` });
      continue;
    }
    const classReference = student.classId ? classMap.get(student.classId) : null;
    if (student.classId && !classReference) {
      errors.push({ entity: "student", id: student.id, message: `Student references unknown class ${student.classId}.` });
      continue;
    }
    if (classReference && classReference.schoolId !== schoolReference.id) {
      errors.push({ entity: "student", id: student.id, message: `Student class ${student.classId} belongs to a different school than student ${student.schoolId}.` });
      continue;
    }
    students.push({
      id,
      school_id: schoolReference.id,
      student_number: normalizeString(student.studentId) || null,
      name: normalizeString(student.name) || "Unnamed Student",
      gender: normalizeString(student.gender) || null,
      status: normalizeString(student.status) || "enrolled",
      current_class_id: classReference ? classReference.id : null,
      created_at: student.createdAt || now,
      updated_at: now,
    });
    studentMap.set(student.id, { id, student, schoolId: schoolReference.id, classId: student.classId });
    if (classReference) {
      studentClassAssignments.push({
        id: normalizeId("student_class_assignment", `${student.id}:${student.classId}`, student),
        student_id: id,
        class_id: classReference.id,
        school_id: schoolReference.id,
        assigned_at: student.createdAt || now,
        ended_at: null,
        is_current: true,
      });
    }
  }

  const guardianMap = new Map();
  const guardians = [];
  const studentGuardians = [];
  for (const student of ensureArray(normalized.students)) {
    if (!student || !student.id || !student.guardian) continue;
    const studentReference = studentMap.get(student.id);
    if (!studentReference) continue;
    const guardianName = normalizeString(student.guardian);
    if (!guardianName) continue;
    const key = `${studentReference.schoolId}:${guardianName.toLowerCase()}`;
    if (!guardianMap.has(key)) {
      const guardianId = normalizeId("guardian", `${studentReference.schoolId}:${guardianName}`, { name: guardianName, schoolId: studentReference.schoolId });
      guardians.push({
        id: guardianId,
        school_id: studentReference.schoolId,
        name: guardianName,
        relationship: null,
        email: null,
        phone: null,
        status: "active",
        created_at: now,
        updated_at: now,
      });
      guardianMap.set(key, guardianId);
    }
    studentGuardians.push({
      id: normalizeId("student_guardian", `${student.id}:${guardianMap.get(key)}`, student),
      student_id: studentReference.id,
      guardian_id: guardianMap.get(key),
      school_id: studentReference.schoolId,
      is_primary: true,
      created_at: now,
      ended_at: null,
    });
  }

  const teacherAssignmentKeys = new Set();
  const classTeacherRows = [];
  for (const klass of ensureArray(normalized.classes)) {
    const classReference = classMap.get(klass.id);
    if (!classReference) continue;
    const teacherIds = ensureArray(klass.teacherIds);
    for (const teacherId of teacherIds) {
      const key = `${klass.id}:${teacherId}`;
      teacherAssignmentKeys.add(key);
    }
  }
  for (const user of ensureArray(normalized.users)) {
    if (user.role !== "teacher" || !Array.isArray(user.classIds)) continue;
    for (const classId of user.classIds) {
      const key = `${classId}:${user.id}`;
      teacherAssignmentKeys.add(key);
    }
  }
  for (const combined of teacherAssignmentKeys) {
    const [classId, userId] = combined.split(":");
    const classReference = classMap.get(classId);
    const userUuid = legacyUserIdToUuid.get(userId);
    if (!classReference) {
      errors.push({ entity: "class_teacher", message: `Teacher assignment references unknown class ${classId}.` });
      continue;
    }
    if (!userUuid) {
      errors.push({ entity: "class_teacher", message: `Teacher assignment references unknown user ${userId}.` });
      continue;
    }
    const userSource = normalized.users.find((item) => item.id === userId);
    if (userSource && userSource.role !== "teacher") {
      warnings.push({ entity: "class_teacher", message: `User ${userId} assigned to class ${classId} is not a teacher; preserving assignment if the user exists.` });
    }
    const userSchoolRawId = userSource?.schoolId || normalized.school.id;
    const userSchoolReference = schoolMap.get(userSchoolRawId);
    const userSchoolId = userSchoolReference ? userSchoolReference.id : null;
    if (userSchoolId !== classReference.schoolId) {
      errors.push({ entity: "class_teacher", message: `Teacher ${userId} belongs to school ${userSchoolRawId} but class ${classId} belongs to school ${classReference.schoolId}.` });
      continue;
    }
    classTeacherRows.push({
      id: normalizeId("class_teacher", `${classId}:${userId}`, { classId, userId }),
      school_id: classReference.schoolId,
      class_id: classReference.id,
      user_id: userUuid,
      assigned_at: now,
      removed_at: null,
    });
  }

  const attendanceEvents = new Map();
  const attendanceRecords = [];
  for (const entry of attendanceEntries) {
    if (!entry || !entry.date || !entry.classId || !entry.studentId) {
      errors.push({ entity: "attendance", message: "Attendance entry is missing required date, classId, or studentId." });
      continue;
    }
    if (!isValidDate(entry.date)) {
      errors.push({ entity: "attendance", message: `Attendance entry has invalid date ${entry.date}.` });
      continue;
    }
    const classReference = classMap.get(entry.classId);
    if (!classReference) {
      errors.push({ entity: "attendance", message: `Attendance entry references unknown class ${entry.classId}.` });
      continue;
    }
    const studentReference = studentMap.get(entry.studentId);
    if (!studentReference) {
      errors.push({ entity: "attendance", message: `Attendance entry references unknown student ${entry.studentId}.` });
      continue;
    }
    if (studentReference.schoolId !== classReference.schoolId) {
      errors.push({ entity: "attendance", message: `Attendance student ${entry.studentId} and class ${entry.classId} belong to different schools.` });
      continue;
    }
    const schoolId = classReference.schoolId;
    const eventKey = `${schoolId}:${classReference.id}:${entry.date}`;
    let event = attendanceEvents.get(eventKey);
    if (!event) {
      const recordedAt = entry.recordedAt || now;
      const updatedAt = entry.updatedAt || recordedAt;
      const recordedById = entry.recordedBy ? legacyUserIdToUuid.get(entry.recordedBy) : null;
      if (entry.recordedBy && !recordedById) {
        errors.push({ entity: "attendance", message: `Attendance entry recordedBy references unknown user ${entry.recordedBy}.` });
      }
      event = {
        id: normalizeId("attendance_event", eventKey, entry),
        school_id: schoolId,
        class_id: classReference.id,
        date: entry.date,
        recorded_by: recordedById || null,
        recorded_at: recordedAt,
        updated_at: updatedAt,
        sync_source: normalizeString(entry.syncSource) || null,
        session_id: null,
      };
      attendanceEvents.set(eventKey, event);
    }
    const recordId = normalizeId("attendance_record", `${event.id}:${entry.studentId}`, entry);
    attendanceRecords.push({
      id: recordId,
      event_id: event.id,
      student_id: studentReference.id,
      school_id: event.school_id,
      status: normalizeString(entry.status) || "absent",
      recorded_at: entry.recordedAt || now,
      updated_at: entry.updatedAt || entry.recordedAt || now,
      synced: entry.synced === false ? false : true,
      sync_client_id: normalizeString(entry.syncClientId) || null,
      sync_record_id: normalizeString(entry.syncRecordId) || null,
    });
  }

  const invitations = [];
  for (const invitation of ensureArray(normalized.invitations)) {
    if (!invitation || !invitation.id) {
      errors.push({ entity: "invitation", message: "Invitation record is missing an id." });
      continue;
    }
    const schoolReference = schoolMap.get(invitation.schoolId || normalized.school.id);
    if (!schoolReference) {
      errors.push({ entity: "invitation", id: invitation.id, message: `Invitation references unknown school ${invitation.schoolId}.` });
      continue;
    }
    if (!invitation.email) {
      errors.push({ entity: "invitation", id: invitation.id, message: "Invitation is missing an email." });
      continue;
    }
    if (!invitation.name) {
      errors.push({ entity: "invitation", id: invitation.id, message: "Invitation is missing a name." });
      continue;
    }
    const id = normalizeId("invitation", invitation.id, invitation);
    invitations.push({
      id,
      school_id: schoolReference.id,
      invited_by: invitation.invitedBy ? legacyUserIdToUuid.get(invitation.invitedBy) || null : null,
      invitee_name: normalizeString(invitation.name),
      invitee_email: normalizeString(invitation.email).toLowerCase(),
      role: normalizeString(invitation.role) || "teacher",
      status: normalizeString(invitation.status) || "pending",
      code: normalizeString(invitation.code) || normalizeString(invitation.id) || normalizeString(invitation.email) || normalizeId("invitation_code", `${schoolReference.id}:${invitation.email || invitation.id}`, invitation),
      invited_at: normalizeTimestamp(invitation.invitedAt),
      expires_at: invitation.expiresAt || null,
      accepted_at: invitation.acceptedAt || null,
      revoked_at: invitation.revokedAt || null,
      accepted_user_id: invitation.acceptedUserId ? legacyUserIdToUuid.get(invitation.acceptedUserId) || null : null,
    });
    invitationMap.set(invitation.id, invitation);
  }

  const audits = [];
  const auditIds = new Set();
  for (const entry of ensureArray(normalized.audit)) {
    if (!entry || !entry.id) {
      errors.push({ entity: "audit", message: "Audit record is missing an id." });
      continue;
    }
    const schoolReference = schoolMap.get(entry.schoolId || normalized.school.id);
    if (!schoolReference) {
      errors.push({ entity: "audit", id: entry.id, message: `Audit entry references unknown school ${entry.schoolId}.` });
      continue;
    }
    if (!entry.action) {
      errors.push({ entity: "audit", id: entry.id, message: "Audit entry is missing an action." });
      continue;
    }
    if (!entry.actorName) {
      errors.push({ entity: "audit", id: entry.id, message: "Audit entry is missing an actorName." });
      continue;
    }
    const auditId = normalizeId("audit", entry.id, entry);
    if (auditIds.has(auditId)) {
      warnings.push({ entity: "audit", id: entry.id, message: "Duplicate audit id after normalization." });
      continue;
    }
    auditIds.add(auditId);
    const actorId = entry.actorId ? legacyUserIdToUuid.get(entry.actorId) : null;
    if (entry.actorId && !actorId) {
      warnings.push({ entity: "audit", id: entry.id, message: `Audit actorId ${entry.actorId} does not resolve to a migrated user; preserved actorName only.` });
    }
    const actorUser = actorId ? normalized.users.find((item) => item.id === entry.actorId) : null;
    if (actorUser && actorUser.schoolId !== schoolReference.id) {
      warnings.push({ entity: "audit", id: entry.id, message: `Audit actor school ${actorUser.schoolId} differs from audit school ${schoolReference.id}.` });
    }
    audits.push({
      id: auditId,
      actor_id: actorId,
      actor_name: normalizeString(entry.actorName),
      school_id: schoolReference.id,
      entity_type: normalizeString(entry.entityType) || null,
      entity_id: entry.entityId && typeof entry.entityId === "string" ? normalizeId("audit_entity", `${schoolReference.id}:${entry.entityId}`, entry) : null,
      action: normalizeString(entry.action),
      detail: normalizeString(entry.detail) || null,
      metadata: entry.metadata || null,
      created_at: entry.at || entry.createdAt || now,
    });
  }

  const attendanceEventRows = Array.from(attendanceEvents.values());

  return {
    normalized,
    sourceCounts,
    rows: {
      schools,
      academic_terms: academicTerms,
      users,
      user_credentials: credentials,
      school_memberships: memberships,
      classes,
      class_teachers: classTeacherRows,
      students,
      guardians,
      student_guardians: studentGuardians,
      student_class_assignments: studentClassAssignments,
      attendance_events: attendanceEventRows,
      attendance_records: attendanceRecords,
      invitations,
      audits,
    },
    warnings,
    errors,
  };
}

function summarizeCounts(rows) {
  return {
    schools: rows.schools.length,
    academic_terms: rows.academic_terms.length,
    users: rows.users.length,
    user_credentials: rows.user_credentials.length,
    school_memberships: rows.school_memberships.length,
    classes: rows.classes.length,
    class_teachers: rows.class_teachers.length,
    students: rows.students.length,
    guardians: rows.guardians.length,
    student_guardians: rows.student_guardians.length,
    student_class_assignments: rows.student_class_assignments.length,
    attendance_events: rows.attendance_events.length,
    attendance_records: rows.attendance_records.length,
    invitations: rows.invitations.length,
    audits: rows.audits.length,
  };
}

export function buildMigrationReport(plan, options = {}) {
  const counts = summarizeCounts(plan.rows);
  const errorTypes = summarizeIssueTypes(plan.errors);
  const warningTypes = summarizeIssueTypes(plan.warnings);
  const success = plan.errors.length === 0;
  const report = {
    timestamp: new Date().toISOString(),
    sourcePath: options.sourcePath || null,
    dryRun: Boolean(options.dryRun),
    counts,
    sourceCounts: plan.sourceCounts,
    warnings: plan.warnings,
    errors: plan.errors,
    warningTypes,
    errorTypes,
    accepted: success,
    rejected: !success,
    success,
    status: success ? "READY" : "NOT READY",
  };
  return report;
}

export function formatReport(report) {
  const lines = [];
  lines.push(`Migration report for ${report.sourcePath || "unknown source"}`);
  lines.push(`  dryRun: ${report.dryRun}`);
  lines.push(`  status: ${report.status}`);
  lines.push(`  accepted: ${report.accepted}`);
  lines.push(`  rejected: ${report.rejected}`);
  lines.push(`  success: ${report.success}`);
  lines.push(`  source counts:`);
  for (const [key, value] of Object.entries(report.sourceCounts)) {
    lines.push(`    ${key}: ${value}`);
  }
  lines.push(`  migrated counts:`);
  for (const [key, value] of Object.entries(report.counts)) {
    lines.push(`    ${key}: ${value}`);
  }
  lines.push(`  errors: ${report.errors.length}`);
  lines.push(`  warnings: ${report.warnings.length}`);
  lines.push(`  error categories:`);
  for (const [type, count] of Object.entries(report.errorTypes)) {
    lines.push(`    ${type}: ${count}`);
  }
  lines.push(`  warning categories:`);
  for (const [type, count] of Object.entries(report.warningTypes)) {
    lines.push(`    ${type}: ${count}`);
  }
  if (report.warnings.length) {
    lines.push("  warning details:");
    for (const warning of report.warnings) {
      lines.push(`    - [${warning.entity}] ${warning.message}`);
    }
  }
  if (report.errors.length) {
    lines.push("  error details:");
    for (const error of report.errors) {
      lines.push(`    - [${error.entity}] ${error.message}`);
    }
  }
  return lines.join("\n");
}

export function validateMigrationPlan(plan) {
  const errors = [...plan.errors];
  const warnings = [...plan.warnings];
  const { normalized, rows } = plan;

  if (!rows.schools.length) {
    errors.push({ entity: "school", message: "No schools are available for migration." });
  }
  if (!rows.users.length) {
    warnings.push({ entity: "user", message: "No users will be migrated." });
  }

  const schoolIds = new Set(rows.schools.map((school) => school.id));
  for (const membership of rows.school_memberships) {
    if (!schoolIds.has(membership.school_id)) {
      errors.push({ entity: "membership", message: `Membership school_id ${membership.school_id} does not exist.` });
    }
  }

  const userIds = new Set(rows.users.map((user) => user.id));
  for (const credential of rows.user_credentials) {
    if (!userIds.has(credential.user_id)) {
      errors.push({ entity: "user_credentials", message: `Credential references missing user ${credential.user_id}.` });
    }
  }

  const classIds = new Set(rows.classes.map((klass) => klass.id));
  for (const assignment of rows.student_class_assignments) {
    if (!classIds.has(assignment.class_id)) {
      errors.push({ entity: "student_class_assignment", message: `Assignment references missing class ${assignment.class_id}.` });
    }
  }

  const teacherAssignmentKeys = new Set();
  for (const teacher of rows.class_teachers) {
    if (!classIds.has(teacher.class_id)) {
      errors.push({ entity: "class_teacher", message: `Class teacher assignment references missing class ${teacher.class_id}.` });
      continue;
    }
    if (!userIds.has(teacher.user_id)) {
      errors.push({ entity: "class_teacher", message: `Class teacher assignment references missing user ${teacher.user_id}.` });
      continue;
    }
    const key = `${teacher.class_id}:${teacher.user_id}`;
    if (teacherAssignmentKeys.has(key)) {
      errors.push({ entity: "class_teacher", message: `Duplicate teacher assignment for class ${teacher.class_id} and user ${teacher.user_id}.` });
    } else {
      teacherAssignmentKeys.add(key);
    }
  }

  const studentIds = new Set(rows.students.map((student) => student.id));
  for (const record of rows.student_guardians) {
    if (!studentIds.has(record.student_id)) {
      errors.push({ entity: "student_guardian", message: `Student guardian references missing student ${record.student_id}.` });
    }
  }
  for (const assignment of rows.student_class_assignments) {
    if (!studentIds.has(assignment.student_id)) {
      errors.push({ entity: "student_class_assignment", message: `Student class assignment references missing student ${assignment.student_id}.` });
    }
  }

  const guardianIds = new Set(rows.guardians.map((guardian) => guardian.id));
  for (const sg of rows.student_guardians) {
    if (!guardianIds.has(sg.guardian_id)) {
      errors.push({ entity: "student_guardian", message: `Student guardian references missing guardian ${sg.guardian_id}.` });
    }
  }

  const eventIds = new Set(rows.attendance_events.map((event) => event.id));
  const attendanceRecordKeys = new Set();
  for (const record of rows.attendance_records) {
    if (!eventIds.has(record.event_id)) {
      errors.push({ entity: "attendance_record", message: `Attendance record references missing event ${record.event_id}.` });
    }
    if (!studentIds.has(record.student_id)) {
      errors.push({ entity: "attendance_record", message: `Attendance record references missing student ${record.student_id}.` });
    }
    const key = `${record.event_id}:${record.student_id}`;
    if (attendanceRecordKeys.has(key)) {
      errors.push({ entity: "attendance_record", message: `Duplicate attendance record for event ${record.event_id} and student ${record.student_id}.` });
    } else {
      attendanceRecordKeys.add(key);
    }
  }

  const duplicateStudentNumbers = new Map();
  for (const student of rows.students) {
    if (!student.student_number) continue;
    const key = `${student.school_id}:${student.student_number}`;
    if (duplicateStudentNumbers.has(key)) {
      errors.push({ entity: "student", message: `Duplicate student_number ${student.student_number} in school ${student.school_id}.` });
    } else {
      duplicateStudentNumbers.set(key, true);
    }
  }

  const membershipRoles = new Map();
  for (const membership of rows.school_memberships) {
    const key = `${membership.user_id}:${membership.school_id}`;
    membershipRoles.set(key, membership.role);
  }
  for (const user of ensureArray(normalized.users)) {
    const userId = normalizeId("user", user.id, user);
    const schoolReference = schoolIds.has(normalizeId("school", user.schoolId || normalized.school.id, user.schoolId ? { id: user.schoolId } : normalized.school))
      ? normalizeId("school", user.schoolId || normalized.school.id, user.schoolId ? { id: user.schoolId } : normalized.school)
      : null;
    if (!userId || !schoolReference) continue;
    const key = `${userId}:${schoolReference}`;
    const membershipRole = membershipRoles.get(key);
    const normalizedRole = normalizeString(user.role) || "teacher";
    if (membershipRole && normalizedRole && membershipRole !== normalizedRole) {
      errors.push({ entity: "user", message: `Conflicting role for user ${user.id}: user role ${normalizedRole} differs from membership role ${membershipRole}.` });
    }
  }

  const studentAssignmentCount = new Map();
  for (const assignment of rows.student_class_assignments) {
    const key = assignment.student_id;
    studentAssignmentCount.set(key, (studentAssignmentCount.get(key) || 0) + 1);
  }
  for (const [studentId, count] of studentAssignmentCount.entries()) {
    if (count > 1) {
      warnings.push({ entity: "student_class_assignment", message: `Student ${studentId} has ${count} class assignment rows; assignment history may be ambiguous.` });
    }
  }

  const invitationEmails = new Map();
  for (const invite of rows.invitations) {
    const key = `${invite.school_id}:${invite.invitee_email}`;
    if (invitationEmails.has(key)) {
      errors.push({ entity: "invitation", message: `Duplicate pending invitation for ${invite.invitee_email} in school ${invite.school_id}.` });
    } else {
      invitationEmails.set(key, true);
    }
  }

  return { ...plan, warnings, errors };
}
